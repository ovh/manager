# manager-pm — Hybrid Yarn + PNPM Orchestration

> Incrementally adopt PNPM inside a Yarn-root monorepo without breaking existing workflows.
> This package ships a small CLI (`manager-pm`) and a couple of helper scripts used from
> root `package.json` to operate on a *merged view* of apps across both ecosystems.

---

## Why this structure?

To **avoid failures when dependencies are not yet installed**, the `bin/manager-pm.js`
exposes only commands that are **safe when the workspace is already connected/installed**:
`build`, `test`, `lint`, `start`, and their `full-*` variants.

Everything that may run during bootstrap time (e.g., `preinstall`, `postinstall`, or
one-off maintenance like adding/removing an app to PNPM) lives in **standalone Node scripts**
with **zero external deps**. This guarantees that running them will not crash just because
`node_modules` is missing.

---

## Commands & scripts

### CLI (installed context only)

```
manager-pm --type pnpm --action <action> [--app <name|path>] [--region EU] [--container]
```

Supported actions:

- `build` — Build one app (merged Yarn ∪ PNPM view). Requires `--app`.
- `test` — Test one app. Requires `--app`.
- `lint` — Lint one app. Requires `--app`.
- `start` — Open an interactive starter.
- `full-build` — Build all apps across Yarn + PNPM catalogs.
- `full-test` — Run tests across all apps.
- `full-lint` — Lint across all apps.

Examples:

```bash
# full graph
yarn pm:build
yarn pm:test
yarn pm:lint:tsx

# per app
manager-pm --type pnpm --action build --app web
manager-pm --type pnpm --action test  --app @scope/zimbra
manager-pm --type pnpm --action lint  --app apps/billing
```

### Bootstrap & maintenance scripts (zero-dep)

These scripts are called directly by the root `package.json`:

```jsonc
{
  "scripts": {
    "preinstall": "node ./packages/manager-tools/manager-pm/src/manager-pm-preinstall.js",
    "postinstall": "node ./packages/manager-tools/manager-pm/src/manager-pm-postinstall.js",
    "pm:add:app": "node ./packages/manager-tools/manager-pm/src/manager-pm-add-app.js",
    "pm:remove:app": "node ./packages/manager-tools/manager-pm/src/manager-pm-remove-app.js",
    "pm:build": "manager-pm --type pnpm --action full-build",
    "pm:test": "manager-pm --type pnpm --action full-test",
    "pm:lint:tsx": "manager-pm --type pnpm --action full-lint",
    "pm:start": "manager-pm --type pnpm --action start"
  }
}
```

#### `pm:add:app`

Adds an app to the PNPM catalog and wiring (workspace, overrides/linking, etc.).

```bash
# preferred form
yarn pm:add:app --app web

# also supports a positional argument
node ./packages/manager-tools/manager-pm/src/manager-pm-add-app.js web

# options
yarn pm:add:app --app web --dry-run
yarn pm:add:app --app packages/apps/web --force
```

#### `pm:remove:app`

Removes an app from the PNPM catalog and unwires related config.

```bash
yarn pm:remove:app --app web
node ./packages/manager-tools/manager-pm/src/manager-pm-remove-app.js web

# options
yarn pm:remove:app --app web --dry-run
yarn pm:remove:app --app packages/apps/web --force
```

---

## Implementation details

- **Single source of truth**: the helper scripts call your already-implemented utilities
  `addAppToPnpm(app, opts)` and `removeAppFromPnpm(app, opts)`. To stay robust without
  extra deps, the scripts try a list of likely internal modules and pick the first that
  exports the requested function.

- **Candidate modules** (relative to `packages/manager-tools/manager-pm/src/`):

  - `./kernel/pnpm/pnpm-apps-manager.js`
  - `./kernel/pnpm/pnpm-apps-registry.js`
  - `./kernel/pnpm/pnpm-workspace-manager.js`
  - `./kernel/pnpm/pnpm-migration-manager.js`
  - `./kernel/pnpm/pnpm-catalog-manager.js`
  - `./kernel/pnpm/pnpm-tasks-manager.js`

  If your functions live elsewhere, either **re-export** them from one of the files above
  or **edit the `CANDIDATE_MODULES` array** in the scripts.

- **Logger**: if `./kernel/commons/log-manager.js` is available, it will be used.
  Otherwise the scripts fall back to `console` so they can run even before installs.

- **Options** passed through to your utilities:

  - `dryRun` (boolean) — compute changes without writing.
  - `force` (boolean) — ignore certain safety checks (your util decides how to use it).
  - `logger` — a logger instance (either your logger or the fallback).

- **Diagnostics**: set `MANAGER_PM_TRACE_IMPORTS=1` to print which internal modules were
  attempted during dynamic resolution of `addAppToPnpm`/`removeAppFromPnpm`.

---

## Examples end-to-end

```bash
# Add an app to the PNPM catalog (with log output)
yarn pm:add:app --app web

# Dry-run a removal to preview changes
MANAGER_PM_TRACE_IMPORTS=1 yarn pm:remove:app --app web --dry-run

# Then build everything across the merged view
yarn pm:build
```

---

## Exit codes

- `0` — success
- `1` — user error (missing `--app`) or unexpected failure
- Other codes — propagate from underlying utilities if they throw with `process.exitCode`

---

## Notes

- These wrappers are intentionally **minimal** and **ESM-only** to match the rest
  of your tooling.
- They avoid any 3rd‑party CLI library so they remain usable **before** dependencies
  are installed (e.g., during `preinstall` / `postinstall`).
- The main `manager-pm` CLI (in `bin/`) continues to use Commander in the **installed**
  environment to provide a richer UX for day-to-day tasks.
