import "/node_modules/.cache/sb-vite/deps/chunk-BI6SF4IK.js?v=25ee29f1";
import {
  require_core_events
} from "/node_modules/.cache/sb-vite/deps/chunk-D5X3I32I.js?v=25ee29f1";
import "/node_modules/.cache/sb-vite/deps/chunk-6JVAWBCK.js?v=25ee29f1";
import {
  scope
} from "/node_modules/.cache/sb-vite/deps/chunk-53B3XB6V.js?v=25ee29f1";
import {
  require_preview_api
} from "/node_modules/.cache/sb-vite/deps/chunk-SAH4R37F.js?v=25ee29f1";
import {
  __toESM
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/@storybook/addon-links/dist/chunk-JT3VIYBO.mjs
var ADDON_ID = "storybook/links";
var PARAM_KEY = "links";
var constants_default = { NAVIGATE: `${ADDON_ID}/navigate`, REQUEST: `${ADDON_ID}/request`, RECEIVE: `${ADDON_ID}/receive` };

// ../../node_modules/@storybook/addon-links/dist/chunk-DXNAW7Q2.mjs
var import_preview_api = __toESM(require_preview_api(), 1);
var import_core_events = __toESM(require_core_events(), 1);
var { document, HTMLElement } = scope;
var navigate = (params) => import_preview_api.addons.getChannel().emit(import_core_events.SELECT_STORY, params);
var linksListener = (e) => {
  let { target } = e;
  if (!(target instanceof HTMLElement))
    return;
  let element = target, { sbKind: kind, sbStory: story } = element.dataset;
  (kind || story) && (e.preventDefault(), navigate({ kind, story }));
};
var hasListener = false;
var on = () => {
  hasListener || (hasListener = true, document.addEventListener("click", linksListener));
};
var off = () => {
  hasListener && (hasListener = false, document.removeEventListener("click", linksListener));
};
var withLinks = (0, import_preview_api.makeDecorator)({ name: "withLinks", parameterName: PARAM_KEY, wrapper: (getStory, context) => (on(), import_preview_api.addons.getChannel().once(import_core_events.STORY_CHANGED, off), getStory(context)) });

// ../../node_modules/@storybook/addon-links/dist/preview.mjs
var decorators = [withLinks];
export {
  decorators
};
//# sourceMappingURL=@storybook_addon-links_preview.js.map
