import "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/@storybook/addon-docs/dist/preview.mjs
var parameters = { docs: { renderer: async () => {
  let { DocsRenderer } = await import("/node_modules/.cache/sb-vite/deps/DocsRenderer-3PUGWF3O-R7J4RAXM.js?v=25ee29f1");
  return new DocsRenderer();
} } };
export {
  parameters
};
//# sourceMappingURL=@storybook_addon-essentials_docs_preview.js.map
