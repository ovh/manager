import {
  H,
  Host,
  h,
  proxyCustomElement
} from "/node_modules/.cache/sb-vite/deps/chunk-QZD7DNHB.js?v=25ee29f1";
import {
  __rest
} from "/node_modules/.cache/sb-vite/deps/chunk-OHK2DJ23.js?v=25ee29f1";
import {
  require_react_dom
} from "/node_modules/.cache/sb-vite/deps/chunk-ZHCUIEE5.js?v=25ee29f1";
import {
  require_react
} from "/node_modules/.cache/sb-vite/deps/chunk-UXJYJ7WW.js?v=25ee29f1";
import {
  __toESM
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/@ovhcloud/ods-components/tile/react/dist/esm/react-component-lib/createComponent.js
var import_react2 = __toESM(require_react());

// ../../node_modules/@ovhcloud/ods-components/tile/react/dist/esm/react-component-lib/utils/index.js
var import_react = __toESM(require_react());

// ../../node_modules/@ovhcloud/ods-components/tile/react/dist/esm/react-component-lib/utils/case.js
var dashToPascalCase = (str) => str.toLowerCase().split("-").map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1)).join("");
var camelToDashCase = (str) => str.replace(/([A-Z])/g, (m) => `-${m[0].toLowerCase()}`);

// ../../node_modules/@ovhcloud/ods-components/tile/react/dist/esm/react-component-lib/utils/attachProps.js
var attachProps = (node, newProps, oldProps = {}) => {
  if (node instanceof Element) {
    const className = getClassName(node.classList, newProps, oldProps);
    if (className !== "") {
      node.className = className;
    }
    Object.keys(newProps).forEach((name) => {
      if (name === "children" || name === "style" || name === "ref" || name === "class" || name === "className" || name === "forwardedRef") {
        return;
      }
      if (name.indexOf("on") === 0 && name[2] === name[2].toUpperCase()) {
        const eventName = name.substring(2);
        const eventNameLc = eventName[0].toLowerCase() + eventName.substring(1);
        if (!isCoveredByReact(eventNameLc)) {
          syncEvent(node, eventNameLc, newProps[name]);
        }
      } else {
        node[name] = newProps[name];
        const propType = typeof newProps[name];
        if (propType === "string") {
          node.setAttribute(camelToDashCase(name), newProps[name]);
        }
      }
    });
  }
};
var getClassName = (classList, newProps, oldProps) => {
  const newClassProp = newProps.className || newProps.class;
  const oldClassProp = oldProps.className || oldProps.class;
  const currentClasses = arrayToMap(classList);
  const incomingPropClasses = arrayToMap(newClassProp ? newClassProp.split(" ") : []);
  const oldPropClasses = arrayToMap(oldClassProp ? oldClassProp.split(" ") : []);
  const finalClassNames = [];
  currentClasses.forEach((currentClass) => {
    if (incomingPropClasses.has(currentClass)) {
      finalClassNames.push(currentClass);
      incomingPropClasses.delete(currentClass);
    } else if (!oldPropClasses.has(currentClass)) {
      finalClassNames.push(currentClass);
    }
  });
  incomingPropClasses.forEach((s) => finalClassNames.push(s));
  return finalClassNames.join(" ");
};
var isCoveredByReact = (eventNameSuffix) => {
  if (typeof document === "undefined") {
    return true;
  } else {
    const eventName = "on" + eventNameSuffix;
    let isSupported = eventName in document;
    if (!isSupported) {
      const element = document.createElement("div");
      element.setAttribute(eventName, "return;");
      isSupported = typeof element[eventName] === "function";
    }
    return isSupported;
  }
};
var syncEvent = (node, eventName, newEventHandler) => {
  const eventStore = node.__events || (node.__events = {});
  const oldEventHandler = eventStore[eventName];
  if (oldEventHandler) {
    node.removeEventListener(eventName, oldEventHandler);
  }
  node.addEventListener(eventName, eventStore[eventName] = function handler(e) {
    if (newEventHandler) {
      newEventHandler.call(this, e);
    }
  });
};
var arrayToMap = (arr) => {
  const map = /* @__PURE__ */ new Map();
  arr.forEach((s) => map.set(s, s));
  return map;
};

// ../../node_modules/@ovhcloud/ods-components/tile/react/dist/esm/react-component-lib/utils/index.js
var setRef = (ref, value) => {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref != null) {
    ref.current = value;
  }
};
var mergeRefs = (...refs) => {
  return (value) => {
    refs.forEach((ref) => {
      setRef(ref, value);
    });
  };
};
var createForwardRef = (ReactComponent, displayName) => {
  const forwardRef = (props, ref) => {
    return import_react.default.createElement(ReactComponent, Object.assign({}, props, { forwardedRef: ref }));
  };
  forwardRef.displayName = displayName;
  return import_react.default.forwardRef(forwardRef);
};

// ../../node_modules/@ovhcloud/ods-components/tile/react/dist/esm/react-component-lib/createComponent.js
var createReactComponent = (tagName, ReactComponentContext, manipulatePropsFunction, defineCustomElement3) => {
  if (defineCustomElement3 !== void 0) {
    defineCustomElement3();
  }
  const displayName = dashToPascalCase(tagName);
  const ReactComponent = class extends import_react2.default.Component {
    constructor(props) {
      super(props);
      this.setComponentElRef = (element) => {
        this.componentEl = element;
      };
    }
    componentDidMount() {
      this.componentDidUpdate(this.props);
    }
    componentDidUpdate(prevProps) {
      attachProps(this.componentEl, this.props, prevProps);
    }
    render() {
      const _a = this.props, { children, forwardedRef, style, className, ref } = _a, cProps = __rest(_a, ["children", "forwardedRef", "style", "className", "ref"]);
      let propsToPass = Object.keys(cProps).reduce((acc, name) => {
        if (name.indexOf("on") === 0 && name[2] === name[2].toUpperCase()) {
          const eventName = name.substring(2).toLowerCase();
          if (typeof document !== "undefined" && isCoveredByReact(eventName)) {
            acc[name] = cProps[name];
          }
        } else {
          acc[name] = cProps[name];
        }
        return acc;
      }, {});
      if (manipulatePropsFunction) {
        propsToPass = manipulatePropsFunction(this.props, propsToPass);
      }
      const newProps = Object.assign(Object.assign({}, propsToPass), { ref: mergeRefs(forwardedRef, this.setComponentElRef), style });
      return (0, import_react2.createElement)(tagName, newProps, children);
    }
    static get displayName() {
      return displayName;
    }
  };
  if (ReactComponentContext) {
    ReactComponent.contextType = ReactComponentContext;
  }
  return createForwardRef(ReactComponent, displayName);
};

// ../../node_modules/@ovhcloud/ods-components/tile/react/dist/esm/react-component-lib/createOverlayComponent.js
var import_react3 = __toESM(require_react());
var import_react_dom = __toESM(require_react_dom());

// ../../node_modules/@ovhcloud/ods-component-tile/custom-elements/osds-tile.js
var ODS_TILE_SIZE;
(function(ODS_TILE_SIZE2) {
  ODS_TILE_SIZE2["sm"] = "sm";
  ODS_TILE_SIZE2["md"] = "md";
})(ODS_TILE_SIZE || (ODS_TILE_SIZE = {}));
var ODS_TILE_SIZES = Object.freeze(Object.values(ODS_TILE_SIZE));
var ODS_TILE_VARIANT;
(function(ODS_TILE_VARIANT2) {
  ODS_TILE_VARIANT2["flat"] = "flat";
  ODS_TILE_VARIANT2["stroked"] = "stroked";
  ODS_TILE_VARIANT2["ghost"] = "ghost";
  ODS_TILE_VARIANT2["hollow"] = "hollow";
})(ODS_TILE_VARIANT || (ODS_TILE_VARIANT = {}));
var ODS_TILE_VARIANTS = Object.freeze(Object.values(ODS_TILE_VARIANT));
var ODS_THEME_COLOR_HUE;
(function(ODS_THEME_COLOR_HUE2) {
  ODS_THEME_COLOR_HUE2["_000"] = "000";
  ODS_THEME_COLOR_HUE2["_050"] = "050";
  ODS_THEME_COLOR_HUE2["_075"] = "075";
  ODS_THEME_COLOR_HUE2["_100"] = "100";
  ODS_THEME_COLOR_HUE2["_200"] = "200";
  ODS_THEME_COLOR_HUE2["_300"] = "300";
  ODS_THEME_COLOR_HUE2["_400"] = "400";
  ODS_THEME_COLOR_HUE2["_500"] = "500";
  ODS_THEME_COLOR_HUE2["_600"] = "600";
  ODS_THEME_COLOR_HUE2["_700"] = "700";
  ODS_THEME_COLOR_HUE2["_800"] = "800";
  ODS_THEME_COLOR_HUE2["_900"] = "900";
  ODS_THEME_COLOR_HUE2["_1000"] = "1000";
})(ODS_THEME_COLOR_HUE || (ODS_THEME_COLOR_HUE = {}));
Object.freeze(Object.values(ODS_THEME_COLOR_HUE));
var ODS_THEME_COLOR_INTENT;
(function(ODS_THEME_COLOR_INTENT2) {
  ODS_THEME_COLOR_INTENT2["accent"] = "accent";
  ODS_THEME_COLOR_INTENT2["default"] = "default";
  ODS_THEME_COLOR_INTENT2["error"] = "error";
  ODS_THEME_COLOR_INTENT2["info"] = "info";
  ODS_THEME_COLOR_INTENT2["primary"] = "primary";
  ODS_THEME_COLOR_INTENT2["promotion"] = "promotion";
  ODS_THEME_COLOR_INTENT2["success"] = "success";
  ODS_THEME_COLOR_INTENT2["text"] = "text";
  ODS_THEME_COLOR_INTENT2["warning"] = "warning";
})(ODS_THEME_COLOR_INTENT || (ODS_THEME_COLOR_INTENT = {}));
Object.freeze(Object.values(ODS_THEME_COLOR_INTENT));
var ODS_THEME_SIZE;
(function(ODS_THEME_SIZE2) {
  ODS_THEME_SIZE2["_100"] = "100";
  ODS_THEME_SIZE2["_200"] = "200";
  ODS_THEME_SIZE2["_300"] = "300";
  ODS_THEME_SIZE2["_400"] = "400";
  ODS_THEME_SIZE2["_500"] = "500";
  ODS_THEME_SIZE2["_600"] = "600";
  ODS_THEME_SIZE2["_700"] = "700";
  ODS_THEME_SIZE2["_800"] = "800";
  ODS_THEME_SIZE2["_900"] = "900";
})(ODS_THEME_SIZE || (ODS_THEME_SIZE = {}));
Object.freeze(Object.values(ODS_THEME_SIZE));
var ODS_THEME_TYPOGRAPHY_LEVEL;
(function(ODS_THEME_TYPOGRAPHY_LEVEL2) {
  ODS_THEME_TYPOGRAPHY_LEVEL2["body"] = "body";
  ODS_THEME_TYPOGRAPHY_LEVEL2["button"] = "button";
  ODS_THEME_TYPOGRAPHY_LEVEL2["caption"] = "caption";
  ODS_THEME_TYPOGRAPHY_LEVEL2["heading"] = "heading";
  ODS_THEME_TYPOGRAPHY_LEVEL2["subheading"] = "subheading";
})(ODS_THEME_TYPOGRAPHY_LEVEL || (ODS_THEME_TYPOGRAPHY_LEVEL = {}));
Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_LEVEL));
var ODS_THEME_TYPOGRAPHY_SIZE;
(function(ODS_THEME_TYPOGRAPHY_SIZE2) {
  ODS_THEME_TYPOGRAPHY_SIZE2["_100"] = "100";
  ODS_THEME_TYPOGRAPHY_SIZE2["_200"] = "200";
  ODS_THEME_TYPOGRAPHY_SIZE2["_300"] = "300";
  ODS_THEME_TYPOGRAPHY_SIZE2["_400"] = "400";
  ODS_THEME_TYPOGRAPHY_SIZE2["_500"] = "500";
  ODS_THEME_TYPOGRAPHY_SIZE2["_600"] = "600";
  ODS_THEME_TYPOGRAPHY_SIZE2["_700"] = "700";
  ODS_THEME_TYPOGRAPHY_SIZE2["_800"] = "800";
})(ODS_THEME_TYPOGRAPHY_SIZE || (ODS_THEME_TYPOGRAPHY_SIZE = {}));
Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_SIZE));
var DEFAULT_ATTRIBUTE = Object.freeze({
  checked: false,
  checking: false,
  color: ODS_THEME_COLOR_INTENT.default,
  disabled: false,
  inline: false,
  hoverable: false,
  hasFocus: false,
  loading: false,
  rounded: true,
  size: ODS_TILE_SIZE.md,
  variant: ODS_TILE_VARIANT.stroked
});
var odsDefaultConfig = {
  id: Date.now(),
  logging: {
    active: false,
    color: true
  },
  asset: {
    path: ""
  }
};
function getOdsWindow() {
  if (typeof window !== "undefined") {
    const win2 = window;
    win2.winId = win2.winId ? win2.winId : Date.now();
    return win2;
  }
  return void 0;
}
var OdsLogger = class {
  constructor(context, prefix) {
    this.id = Math.floor(Math.random() * 1e7);
    this.prefixColor = "color: white;background:#004fd6;font-weight: bold; font-size:10px; padding:2px 6px; border-radius: 5px 0px 0px 5px";
    this.contextColor = "color: black;background:#d4e0e7;font-weight: bold; font-size:10px; padding:2px 6px; border-radius: 0px 5px 5px 0px";
    this.prefix = "ODS";
    this.context = "";
    this.prefix = prefix ? prefix : this.prefix;
    this.context = context;
  }
  get log() {
    return this.getConsole("log");
  }
  get warn() {
    return this.getConsole("warn");
  }
  get error() {
    return this.getConsole("error");
  }
  get info() {
    return this.getConsole("info");
  }
  get debug() {
    return this.getConsole("debug");
  }
  get trace() {
    return this.getConsole("trace");
  }
  getConsole(method) {
    if (this.logging) {
      if (this.color) {
        return console[method].bind(null, `${this.prefix ? "%c" : "%s"}${this.prefix} %c${this.context}`, this.prefix ? this.prefixColor : "", this.contextColor);
      }
      return console[method].bind(null, `[${this.prefix}${this.prefix ? "|" : ""}${this.context}]`);
    } else {
      return () => {
      };
    }
  }
  get logging() {
    var _a, _b, _c;
    const win2 = getOdsWindow();
    const active = (_c = (_b = (_a = win2 === null || win2 === void 0 ? void 0 : win2.ods) === null || _a === void 0 ? void 0 : _a.config) === null || _b === void 0 ? void 0 : _b.logging) === null || _c === void 0 ? void 0 : _c.active;
    return active === void 0 ? odsDefaultConfig.logging.active : active;
  }
  get color() {
    var _a, _b, _c;
    const win2 = getOdsWindow();
    const color = (_c = (_b = (_a = win2 === null || win2 === void 0 ? void 0 : win2.ods) === null || _a === void 0 ? void 0 : _a.config) === null || _b === void 0 ? void 0 : _b.logging) === null || _c === void 0 ? void 0 : _c.color;
    return color === void 0 ? odsDefaultConfig.logging.color : color;
  }
};
var VERSION = "9.0.3";
var OdsExternalLogger = class extends OdsLogger {
  constructor(context, prefix) {
    super(context, prefix);
    this.prefixColor = "color: white;background:#403f3e;font-weight: bold; font-size:10px; padding:2px 6px; border-radius: 5px 0px 0px 5px";
    this.contextColor = "color: black;background:#d4e0e7;font-weight: bold; font-size:10px; padding:2px 6px; border-radius: 0px 5px 5px 0px";
    this.prefix = "CUSTOM";
  }
};
var Ods = class _Ods {
  constructor(config) {
    this.config = config;
    this.version = VERSION;
    this.genericLogger = new OdsLogger("ODS", "OVHcloud Design System");
    const winA = window;
    winA.gg = "winA";
    this.config = config;
    this.instanceId = _Ods._instanceId++;
    this.genericLogger.info("Hi! You are using OVHcloud Design System components, feel free to check out https://go/odsdoc/", {
      id: this.instanceId,
      version: this.version
    });
    const odsEvent = new CustomEvent("odsInitialized", {
      detail: {
        version: VERSION,
        instance: this,
        config
      },
      bubbles: true,
      cancelable: true,
      composed: false
    });
    document.dispatchEvent(odsEvent);
  }
  /**
   * @deprecated use `Ods.instance()`
   */
  static configure() {
    return this.instance();
  }
  /**
   * get or create the ODS instance.
   * The singleton is retrieved if exist
   */
  static instance(config = odsDefaultConfig) {
    var _a, _b;
    if (!this._instance) {
      const win2 = getOdsWindow();
      if (((_a = win2 === null || win2 === void 0 ? void 0 : win2.ods) === null || _a === void 0 ? void 0 : _a.versions) && ((_b = win2 === null || win2 === void 0 ? void 0 : win2.ods) === null || _b === void 0 ? void 0 : _b.versions[VERSION])) {
        this._instance = win2.ods.versions[VERSION];
      } else {
        this._instance = new _Ods(config);
      }
    }
    return this._instance;
  }
  /**
   * set your custom i18n callback function that is processing translations.
   * the callback has to return the translated string processed by your translation system.
   * @param hook - function that will receive the values to translate
   */
  i18n(hook) {
    this.i18nHook = hook;
    return this;
  }
  getI18n() {
    return this.i18nHook;
  }
  /**
   * set the default asset path where to find the different assets of `ODS`.
   * @param path - path like `my-ods-svg/`
   */
  assetPath(path) {
    this.config.asset.path = path;
    return this;
  }
  /**
   * get all the configuration of `ODS`
   */
  getConfig() {
    return this.config;
  }
  /**
   * enable or not the logging for the `ODS` instance
   * @param enable - your boolean
   */
  logging(enable) {
    this.config.logging.active = enable;
    return this;
  }
  isLoggingActive() {
    return this.config.logging.active;
  }
  get logger() {
    return OdsExternalLogger;
  }
};
Ods._instanceId = 0;
function initializeProperties(win2, baseConfig) {
  if (!win2.ods) {
    win2.ods = {
      setupId: Date.now(),
      // with our own object reference
      config: baseConfig
    };
  }
  if (!win2.ods.versions) {
    win2.ods.versions = {};
  }
  win2.ods.setupId = win2.ods.setupId || Date.now();
  return win2;
}
function applyLoggingConf(odsConf) {
  odsConf.logging = odsConf.logging || odsDefaultConfig.logging;
  const formatLogging = (odsConf2) => {
    var _a, _b;
    return {
      active: typeof ((_a = odsConf2 === null || odsConf2 === void 0 ? void 0 : odsConf2.logging) === null || _a === void 0 ? void 0 : _a.active) !== "boolean" ? odsDefaultConfig.logging.active : odsConf2.logging.active,
      color: typeof ((_b = odsConf2 === null || odsConf2 === void 0 ? void 0 : odsConf2.logging) === null || _b === void 0 ? void 0 : _b.color) !== "boolean" ? odsDefaultConfig.logging.color : odsConf2.logging.color
    };
  };
  const formatted = formatLogging(odsConf);
  odsConf.logging.active = formatted.active;
  odsConf.logging.color = formatted.color;
}
function applyAssetConf(odsConf) {
  odsConf.asset = odsConf.asset || odsDefaultConfig.asset;
  odsConf.asset.path = odsConf.asset.path ? odsConf.asset.path : odsDefaultConfig.asset.path;
}
function odsSetup() {
  const win2 = getOdsWindow();
  if (win2) {
    const configObjectRef = Object.assign(Object.assign({}, odsDefaultConfig), { id: Date.now() });
    const winFilled = initializeProperties(win2, configObjectRef);
    let config;
    const odsConf = winFilled.ods.config;
    if (odsConf) {
      applyLoggingConf(odsConf);
      applyAssetConf(odsConf);
      config = odsConf;
    } else {
      config = configObjectRef;
    }
    if (!winFilled.ods.versions[VERSION]) {
      winFilled.ods.versions[VERSION] = Ods.instance(config);
    }
    if (!winFilled.ods.latest || winFilled.ods.latest && VERSION > winFilled.ods.latest.version) {
      winFilled.ods.latest = winFilled.ods.versions[VERSION];
    }
  }
}
var win = getOdsWindow();
if (win)
  win.odsSetup = odsSetup;
var ODS_COUNTRY_ISO_CODE;
(function(ODS_COUNTRY_ISO_CODE2) {
  ODS_COUNTRY_ISO_CODE2["AR"] = "ar";
  ODS_COUNTRY_ISO_CODE2["AS"] = "as";
  ODS_COUNTRY_ISO_CODE2["AT"] = "at";
  ODS_COUNTRY_ISO_CODE2["AU"] = "au";
  ODS_COUNTRY_ISO_CODE2["AW"] = "aw";
  ODS_COUNTRY_ISO_CODE2["AX"] = "ax";
  ODS_COUNTRY_ISO_CODE2["AZ"] = "az";
  ODS_COUNTRY_ISO_CODE2["BA"] = "ba";
  ODS_COUNTRY_ISO_CODE2["BB"] = "bb";
  ODS_COUNTRY_ISO_CODE2["BD"] = "bd";
  ODS_COUNTRY_ISO_CODE2["BE"] = "be";
  ODS_COUNTRY_ISO_CODE2["BF"] = "bf";
  ODS_COUNTRY_ISO_CODE2["BG"] = "bg";
  ODS_COUNTRY_ISO_CODE2["BH"] = "bh";
  ODS_COUNTRY_ISO_CODE2["BI"] = "bi";
  ODS_COUNTRY_ISO_CODE2["BJ"] = "bj";
  ODS_COUNTRY_ISO_CODE2["BL"] = "bl";
  ODS_COUNTRY_ISO_CODE2["BM"] = "bm";
  ODS_COUNTRY_ISO_CODE2["BN"] = "bn";
  ODS_COUNTRY_ISO_CODE2["BO"] = "bo";
  ODS_COUNTRY_ISO_CODE2["BQ"] = "bq";
  ODS_COUNTRY_ISO_CODE2["BR"] = "br";
  ODS_COUNTRY_ISO_CODE2["BS"] = "bs";
  ODS_COUNTRY_ISO_CODE2["BT"] = "bt";
  ODS_COUNTRY_ISO_CODE2["BW"] = "bw";
  ODS_COUNTRY_ISO_CODE2["BY"] = "by";
  ODS_COUNTRY_ISO_CODE2["BZ"] = "bz";
  ODS_COUNTRY_ISO_CODE2["CA"] = "ca";
  ODS_COUNTRY_ISO_CODE2["CC"] = "cc";
  ODS_COUNTRY_ISO_CODE2["CD"] = "cd";
  ODS_COUNTRY_ISO_CODE2["CF"] = "cf";
  ODS_COUNTRY_ISO_CODE2["CG"] = "cg";
  ODS_COUNTRY_ISO_CODE2["CH"] = "ch";
  ODS_COUNTRY_ISO_CODE2["CI"] = "ci";
  ODS_COUNTRY_ISO_CODE2["CK"] = "ck";
  ODS_COUNTRY_ISO_CODE2["CL"] = "cl";
  ODS_COUNTRY_ISO_CODE2["CM"] = "cm";
  ODS_COUNTRY_ISO_CODE2["CN"] = "cn";
  ODS_COUNTRY_ISO_CODE2["CO"] = "co";
  ODS_COUNTRY_ISO_CODE2["CR"] = "cr";
  ODS_COUNTRY_ISO_CODE2["CU"] = "cu";
  ODS_COUNTRY_ISO_CODE2["CV"] = "cv";
  ODS_COUNTRY_ISO_CODE2["CW"] = "cw";
  ODS_COUNTRY_ISO_CODE2["CX"] = "cx";
  ODS_COUNTRY_ISO_CODE2["CY"] = "cy";
  ODS_COUNTRY_ISO_CODE2["CZ"] = "cz";
  ODS_COUNTRY_ISO_CODE2["DE"] = "de";
  ODS_COUNTRY_ISO_CODE2["DJ"] = "dj";
  ODS_COUNTRY_ISO_CODE2["DK"] = "dk";
  ODS_COUNTRY_ISO_CODE2["DM"] = "dm";
  ODS_COUNTRY_ISO_CODE2["DO"] = "do";
  ODS_COUNTRY_ISO_CODE2["DZ"] = "dz";
  ODS_COUNTRY_ISO_CODE2["EC"] = "ec";
  ODS_COUNTRY_ISO_CODE2["EE"] = "ee";
  ODS_COUNTRY_ISO_CODE2["EG"] = "eg";
  ODS_COUNTRY_ISO_CODE2["EH"] = "eh";
  ODS_COUNTRY_ISO_CODE2["ER"] = "er";
  ODS_COUNTRY_ISO_CODE2["ES"] = "es";
  ODS_COUNTRY_ISO_CODE2["ET"] = "et";
  ODS_COUNTRY_ISO_CODE2["EU"] = "eu";
  ODS_COUNTRY_ISO_CODE2["FI"] = "fi";
  ODS_COUNTRY_ISO_CODE2["FJ"] = "fj";
  ODS_COUNTRY_ISO_CODE2["FK"] = "fk";
  ODS_COUNTRY_ISO_CODE2["FM"] = "fm";
  ODS_COUNTRY_ISO_CODE2["FO"] = "fo";
  ODS_COUNTRY_ISO_CODE2["FR"] = "fr";
  ODS_COUNTRY_ISO_CODE2["GA"] = "ga";
  ODS_COUNTRY_ISO_CODE2["GB"] = "gb";
  ODS_COUNTRY_ISO_CODE2["GD"] = "gd";
  ODS_COUNTRY_ISO_CODE2["GE"] = "ge";
  ODS_COUNTRY_ISO_CODE2["GF"] = "gf";
  ODS_COUNTRY_ISO_CODE2["GG"] = "gg";
  ODS_COUNTRY_ISO_CODE2["GH"] = "gh";
  ODS_COUNTRY_ISO_CODE2["GI"] = "gi";
  ODS_COUNTRY_ISO_CODE2["GL"] = "gl";
  ODS_COUNTRY_ISO_CODE2["GM"] = "gm";
  ODS_COUNTRY_ISO_CODE2["GN"] = "gn";
  ODS_COUNTRY_ISO_CODE2["GP"] = "gp";
  ODS_COUNTRY_ISO_CODE2["GQ"] = "gq";
  ODS_COUNTRY_ISO_CODE2["GR"] = "gr";
  ODS_COUNTRY_ISO_CODE2["GS"] = "gs";
  ODS_COUNTRY_ISO_CODE2["GT"] = "gt";
  ODS_COUNTRY_ISO_CODE2["GU"] = "gu";
  ODS_COUNTRY_ISO_CODE2["GW"] = "gw";
  ODS_COUNTRY_ISO_CODE2["GY"] = "gy";
  ODS_COUNTRY_ISO_CODE2["HK"] = "hk";
  ODS_COUNTRY_ISO_CODE2["HN"] = "hn";
  ODS_COUNTRY_ISO_CODE2["HR"] = "hr";
  ODS_COUNTRY_ISO_CODE2["HT"] = "ht";
  ODS_COUNTRY_ISO_CODE2["HU"] = "hu";
  ODS_COUNTRY_ISO_CODE2["ID"] = "id";
  ODS_COUNTRY_ISO_CODE2["IE"] = "ie";
  ODS_COUNTRY_ISO_CODE2["IL"] = "il";
  ODS_COUNTRY_ISO_CODE2["IM"] = "im";
  ODS_COUNTRY_ISO_CODE2["IN"] = "in";
  ODS_COUNTRY_ISO_CODE2["IO"] = "io";
  ODS_COUNTRY_ISO_CODE2["IQ"] = "iq";
  ODS_COUNTRY_ISO_CODE2["IR"] = "ir";
  ODS_COUNTRY_ISO_CODE2["IS"] = "is";
  ODS_COUNTRY_ISO_CODE2["IT"] = "it";
  ODS_COUNTRY_ISO_CODE2["JE"] = "je";
  ODS_COUNTRY_ISO_CODE2["JM"] = "jm";
  ODS_COUNTRY_ISO_CODE2["JO"] = "jo";
  ODS_COUNTRY_ISO_CODE2["JP"] = "jp";
  ODS_COUNTRY_ISO_CODE2["KE"] = "ke";
  ODS_COUNTRY_ISO_CODE2["KN"] = "kn";
  ODS_COUNTRY_ISO_CODE2["KP"] = "kp";
  ODS_COUNTRY_ISO_CODE2["KR"] = "kr";
  ODS_COUNTRY_ISO_CODE2["KW"] = "kw";
  ODS_COUNTRY_ISO_CODE2["KY"] = "ky";
  ODS_COUNTRY_ISO_CODE2["KZ"] = "kz";
  ODS_COUNTRY_ISO_CODE2["LA"] = "la";
  ODS_COUNTRY_ISO_CODE2["LB"] = "lb";
  ODS_COUNTRY_ISO_CODE2["LC"] = "lc";
  ODS_COUNTRY_ISO_CODE2["LI"] = "li";
  ODS_COUNTRY_ISO_CODE2["LR"] = "lr";
  ODS_COUNTRY_ISO_CODE2["LS"] = "ls";
  ODS_COUNTRY_ISO_CODE2["LT"] = "lt";
  ODS_COUNTRY_ISO_CODE2["LU"] = "lu";
  ODS_COUNTRY_ISO_CODE2["LV"] = "lv";
  ODS_COUNTRY_ISO_CODE2["LY"] = "ly";
  ODS_COUNTRY_ISO_CODE2["MA"] = "ma";
  ODS_COUNTRY_ISO_CODE2["MC"] = "mc";
  ODS_COUNTRY_ISO_CODE2["MD"] = "md";
  ODS_COUNTRY_ISO_CODE2["ME"] = "me";
  ODS_COUNTRY_ISO_CODE2["MF"] = "mf";
  ODS_COUNTRY_ISO_CODE2["MG"] = "mg";
  ODS_COUNTRY_ISO_CODE2["MH"] = "mh";
  ODS_COUNTRY_ISO_CODE2["MK"] = "mk";
  ODS_COUNTRY_ISO_CODE2["ML"] = "ml";
  ODS_COUNTRY_ISO_CODE2["MM"] = "mm";
  ODS_COUNTRY_ISO_CODE2["MN"] = "mn";
  ODS_COUNTRY_ISO_CODE2["MO"] = "mo";
  ODS_COUNTRY_ISO_CODE2["MP"] = "mp";
  ODS_COUNTRY_ISO_CODE2["MQ"] = "mq";
  ODS_COUNTRY_ISO_CODE2["MR"] = "mr";
  ODS_COUNTRY_ISO_CODE2["MS"] = "ms";
  ODS_COUNTRY_ISO_CODE2["MT"] = "mt";
  ODS_COUNTRY_ISO_CODE2["MU"] = "mu";
  ODS_COUNTRY_ISO_CODE2["MV"] = "mv";
  ODS_COUNTRY_ISO_CODE2["MW"] = "mw";
  ODS_COUNTRY_ISO_CODE2["MX"] = "mx";
  ODS_COUNTRY_ISO_CODE2["MY"] = "my";
  ODS_COUNTRY_ISO_CODE2["MZ"] = "mz";
  ODS_COUNTRY_ISO_CODE2["NA"] = "na";
  ODS_COUNTRY_ISO_CODE2["NC"] = "nc";
  ODS_COUNTRY_ISO_CODE2["NE"] = "ne";
  ODS_COUNTRY_ISO_CODE2["NF"] = "nf";
  ODS_COUNTRY_ISO_CODE2["NG"] = "ng";
  ODS_COUNTRY_ISO_CODE2["NI"] = "ni";
  ODS_COUNTRY_ISO_CODE2["NL"] = "nl";
  ODS_COUNTRY_ISO_CODE2["NO"] = "no";
  ODS_COUNTRY_ISO_CODE2["NP"] = "np";
  ODS_COUNTRY_ISO_CODE2["NR"] = "nr";
  ODS_COUNTRY_ISO_CODE2["NU"] = "nu";
  ODS_COUNTRY_ISO_CODE2["NZ"] = "nz";
  ODS_COUNTRY_ISO_CODE2["OM"] = "om";
  ODS_COUNTRY_ISO_CODE2["PA"] = "pa";
  ODS_COUNTRY_ISO_CODE2["PF"] = "pf";
  ODS_COUNTRY_ISO_CODE2["PG"] = "pg";
  ODS_COUNTRY_ISO_CODE2["PH"] = "ph";
  ODS_COUNTRY_ISO_CODE2["PK"] = "pk";
  ODS_COUNTRY_ISO_CODE2["PL"] = "pl";
  ODS_COUNTRY_ISO_CODE2["PM"] = "pm";
  ODS_COUNTRY_ISO_CODE2["PN"] = "pn";
  ODS_COUNTRY_ISO_CODE2["PR"] = "pr";
  ODS_COUNTRY_ISO_CODE2["PS"] = "ps";
  ODS_COUNTRY_ISO_CODE2["PT"] = "pt";
  ODS_COUNTRY_ISO_CODE2["PW"] = "pw";
  ODS_COUNTRY_ISO_CODE2["PY"] = "py";
  ODS_COUNTRY_ISO_CODE2["QA"] = "qa";
  ODS_COUNTRY_ISO_CODE2["RE"] = "re";
  ODS_COUNTRY_ISO_CODE2["RO"] = "ro";
  ODS_COUNTRY_ISO_CODE2["RS"] = "rs";
  ODS_COUNTRY_ISO_CODE2["RU"] = "ru";
  ODS_COUNTRY_ISO_CODE2["RW"] = "rw";
  ODS_COUNTRY_ISO_CODE2["SA"] = "sa";
  ODS_COUNTRY_ISO_CODE2["SB"] = "sb";
  ODS_COUNTRY_ISO_CODE2["SC"] = "sc";
  ODS_COUNTRY_ISO_CODE2["SD"] = "sd";
  ODS_COUNTRY_ISO_CODE2["SE"] = "se";
  ODS_COUNTRY_ISO_CODE2["SG"] = "sg";
  ODS_COUNTRY_ISO_CODE2["SH"] = "sh";
  ODS_COUNTRY_ISO_CODE2["SI"] = "si";
  ODS_COUNTRY_ISO_CODE2["SJ"] = "sj";
  ODS_COUNTRY_ISO_CODE2["SK"] = "sk";
  ODS_COUNTRY_ISO_CODE2["SL"] = "sl";
  ODS_COUNTRY_ISO_CODE2["SM"] = "sm";
  ODS_COUNTRY_ISO_CODE2["SN"] = "sn";
  ODS_COUNTRY_ISO_CODE2["SO"] = "so";
  ODS_COUNTRY_ISO_CODE2["SR"] = "sr";
  ODS_COUNTRY_ISO_CODE2["SS"] = "ss";
  ODS_COUNTRY_ISO_CODE2["ST"] = "st";
  ODS_COUNTRY_ISO_CODE2["SV"] = "sv";
  ODS_COUNTRY_ISO_CODE2["SX"] = "sx";
  ODS_COUNTRY_ISO_CODE2["SY"] = "sy";
  ODS_COUNTRY_ISO_CODE2["SZ"] = "sz";
  ODS_COUNTRY_ISO_CODE2["TC"] = "tc";
  ODS_COUNTRY_ISO_CODE2["TD"] = "td";
  ODS_COUNTRY_ISO_CODE2["TF"] = "tf";
  ODS_COUNTRY_ISO_CODE2["TG"] = "tg";
  ODS_COUNTRY_ISO_CODE2["TH"] = "th";
  ODS_COUNTRY_ISO_CODE2["TJ"] = "tj";
  ODS_COUNTRY_ISO_CODE2["TK"] = "tk";
  ODS_COUNTRY_ISO_CODE2["TL"] = "tl";
  ODS_COUNTRY_ISO_CODE2["TM"] = "tm";
  ODS_COUNTRY_ISO_CODE2["TN"] = "tn";
  ODS_COUNTRY_ISO_CODE2["TO"] = "to";
  ODS_COUNTRY_ISO_CODE2["TR"] = "tr";
  ODS_COUNTRY_ISO_CODE2["TT"] = "tt";
  ODS_COUNTRY_ISO_CODE2["TV"] = "tv";
  ODS_COUNTRY_ISO_CODE2["TW"] = "tw";
  ODS_COUNTRY_ISO_CODE2["TZ"] = "tz";
  ODS_COUNTRY_ISO_CODE2["UA"] = "ua";
  ODS_COUNTRY_ISO_CODE2["UG"] = "ug";
  ODS_COUNTRY_ISO_CODE2["UM"] = "um";
  ODS_COUNTRY_ISO_CODE2["UN"] = "un";
  ODS_COUNTRY_ISO_CODE2["UNIA"] = "unia";
  ODS_COUNTRY_ISO_CODE2["US"] = "us";
  ODS_COUNTRY_ISO_CODE2["UY"] = "uy";
  ODS_COUNTRY_ISO_CODE2["UZ"] = "uz";
  ODS_COUNTRY_ISO_CODE2["VA"] = "va";
  ODS_COUNTRY_ISO_CODE2["VC"] = "vc";
  ODS_COUNTRY_ISO_CODE2["VE"] = "ve";
  ODS_COUNTRY_ISO_CODE2["VG"] = "vg";
  ODS_COUNTRY_ISO_CODE2["VI"] = "vi";
  ODS_COUNTRY_ISO_CODE2["VN"] = "vn";
  ODS_COUNTRY_ISO_CODE2["VU"] = "vu";
  ODS_COUNTRY_ISO_CODE2["WF"] = "wf";
  ODS_COUNTRY_ISO_CODE2["WS"] = "ws";
  ODS_COUNTRY_ISO_CODE2["XK"] = "xk";
  ODS_COUNTRY_ISO_CODE2["YE"] = "ye";
  ODS_COUNTRY_ISO_CODE2["YT"] = "yt";
  ODS_COUNTRY_ISO_CODE2["ZA"] = "za";
  ODS_COUNTRY_ISO_CODE2["ZM"] = "zm";
})(ODS_COUNTRY_ISO_CODE || (ODS_COUNTRY_ISO_CODE = {}));
Object.keys(ODS_COUNTRY_ISO_CODE).map((key) => ODS_COUNTRY_ISO_CODE[key]);
function odsIsTermInEnum(term, set) {
  return Object.values(set).includes(term);
}
function OdsWarnComponentEnumAttribute(params) {
  if (!odsIsTermInEnum(params.attribute, params.attributeValues)) {
    params.logger.warn(`The ${params.attributeName} attribute must have a value from [${Object.values(params.attributeValues).join(", ")}]`);
  }
}
function OdsWarnComponentRangeAttribute(params) {
  if (params.attribute && (params.attribute > params.max || params.attribute < params.min)) {
    params.logger.warn(`The value attribute must be in bounds of [${[params.min, params.max].join(", ")}]`);
  }
}
function OdsWarnComponentAttribute(params, required = false) {
  if (required && !params.attribute) {
    return params.logger.warn(`Attribute ${params.attributeName} is required.`);
  }
  if (typeof params.attribute === "number") {
    return OdsWarnComponentRangeAttribute(params);
  }
  return OdsWarnComponentEnumAttribute(params);
}
var OlesIpsumGeneration;
(function(OlesIpsumGeneration2) {
  OlesIpsumGeneration2["paragraphs"] = "paragraphs";
  OlesIpsumGeneration2["sentences"] = "sentences";
  OlesIpsumGeneration2["words"] = "words";
})(OlesIpsumGeneration || (OlesIpsumGeneration = {}));
Object.keys(OlesIpsumGeneration).map((key) => OlesIpsumGeneration[key]);
var OdsHTMLAnchorElementRel;
(function(OdsHTMLAnchorElementRel2) {
  OdsHTMLAnchorElementRel2["alternate"] = "alternate";
  OdsHTMLAnchorElementRel2["author"] = "author";
  OdsHTMLAnchorElementRel2["bookmark"] = "bookmark";
  OdsHTMLAnchorElementRel2["external"] = "external";
  OdsHTMLAnchorElementRel2["help"] = "help";
  OdsHTMLAnchorElementRel2["license"] = "license";
  OdsHTMLAnchorElementRel2["me"] = "me";
  OdsHTMLAnchorElementRel2["next"] = "next";
  OdsHTMLAnchorElementRel2["nofollow"] = "nofollow";
  OdsHTMLAnchorElementRel2["noopener"] = "noopener";
  OdsHTMLAnchorElementRel2["noreferrer"] = "noreferrer";
  OdsHTMLAnchorElementRel2["opener"] = "opener";
  OdsHTMLAnchorElementRel2["prev"] = "prev";
  OdsHTMLAnchorElementRel2["search"] = "search";
  OdsHTMLAnchorElementRel2["tag"] = "tag";
})(OdsHTMLAnchorElementRel || (OdsHTMLAnchorElementRel = {}));
Object.keys(OdsHTMLAnchorElementRel).map((key) => OdsHTMLAnchorElementRel[key]);
var OdsHTMLAnchorElementTarget;
(function(OdsHTMLAnchorElementTarget2) {
  OdsHTMLAnchorElementTarget2["_blank"] = "_blank";
  OdsHTMLAnchorElementTarget2["_self"] = "_self";
  OdsHTMLAnchorElementTarget2["_parent"] = "_parent";
  OdsHTMLAnchorElementTarget2["_top"] = "_top";
})(OdsHTMLAnchorElementTarget || (OdsHTMLAnchorElementTarget = {}));
Object.keys(OdsHTMLAnchorElementTarget).map((key) => OdsHTMLAnchorElementTarget[key]);
var OdsTileController = class {
  constructor(component) {
    this.logger = new OdsLogger("OsdsTileController");
    this.component = component;
  }
  /**
   * validating that the color, the size and the variant have correct values
   * and warn the user if not
   */
  validateAttributes() {
    const logger = this.logger;
    OdsWarnComponentAttribute({
      logger,
      attributeValues: ODS_THEME_COLOR_INTENT,
      attributeName: "color",
      attribute: this.component.color
    });
    OdsWarnComponentAttribute({
      logger,
      attributeValues: ODS_TILE_SIZE,
      attributeName: "size",
      attribute: this.component.size
    });
    OdsWarnComponentAttribute({
      logger,
      attributeValues: ODS_TILE_VARIANT,
      attributeName: "variant",
      attribute: this.component.variant
    });
  }
  handleClick() {
    this.logger.log("[tile]", "clicked");
  }
};
var osdsTileCss = ':host{border:solid var(--ods-size-inset-02);box-sizing:border-box;flex-direction:row}:host(:host(:not([inline]))){width:100%;display:grid;grid-template-columns:auto 1fr auto}:host([inline]){display:inline-flex;width:var(--width)}:host(:not([checking])[disabled]){opacity:0.5}:host([disabled]){cursor:not-allowed}:host([disabled]) *{pointer-events:none}:host([hoverable]:not([disabled])){cursor:pointer}:host([rounded]){border-radius:var(--ods-size-border-radius-02)}slot[name=start],slot[name=end],.tile__centered-text{display:inline-flex}::slotted([slot=start]),::slotted([slot=end]){display:inherit}::slotted([slot=start]):empty,::slotted([slot=end]):empty{display:none}slot[name=start]{justify-content:flex-start}slot[name=end]{justify-content:flex-end}.tile__centered-text{justify-content:center}:host([checking]){overflow:visible;position:relative}:host([checking]):after{content:"";position:absolute;left:-2px;top:-2px;background-size:400%;width:calc(100% + 4px);height:calc(100% + 4px);z-index:-1;animation:steam 3s linear infinite}:host([checking]):after{filter:blur(5px)}@keyframes steam{0%{background-position:0 0}50%{background-position:100% 0}100%{background-position:0 0}}:host{border-color:transparent}:host([disabled]){opacity:0.5}:host(:not([variant]):not([color]),[variant=default]:not([color])){border-color:var(--ods-color-default-200);background-color:var(--ods-color-default-000)}:host(:not([variant])[color^=default],[variant=default][color^=default]){border-color:var(--ods-color-default-200);background-color:var(--ods-color-default-000)}:host(:not([variant])[color^=primary],[variant=default][color^=primary]){border-color:var(--ods-color-primary-200);background-color:var(--ods-color-primary-000)}:host(:not([variant])[color^=text],[variant=default][color^=text]){border-color:var(--ods-color-text-200);background-color:var(--ods-color-text-000)}:host(:not([variant])[color^=accent],[variant=default][color^=accent]){border-color:var(--ods-color-accent-200);background-color:var(--ods-color-accent-000)}:host(:not([variant])[color^=error],[variant=default][color^=error]){border-color:var(--ods-color-error-200);background-color:var(--ods-color-error-000)}:host(:not([variant])[color^=warning],[variant=default][color^=warning]){border-color:var(--ods-color-warning-200);background-color:var(--ods-color-warning-000)}:host(:not([variant])[color^=success],[variant=default][color^=success]){border-color:var(--ods-color-success-200);background-color:var(--ods-color-success-000)}:host(:not([variant])[color^=info],[variant=default][color^=info]){border-color:var(--ods-color-info-200);background-color:var(--ods-color-info-000)}:host(:not([variant])[color^=promotion],[variant=default][color^=promotion]){border-color:var(--ods-color-promotion-200);background-color:var(--ods-color-promotion-000)}:host(:not([variant])[hoverable]:not([disabled]):not([color]):hover,[variant=default][hoverable]:not([disabled]):not([color]):hover){background-color:var(--ods-color-default-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=default]:hover,[variant=default][hoverable]:not([disabled])[color^=default]:hover){background-color:var(--ods-color-default-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=primary]:hover,[variant=default][hoverable]:not([disabled])[color^=primary]:hover){background-color:var(--ods-color-primary-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=text]:hover,[variant=default][hoverable]:not([disabled])[color^=text]:hover){background-color:var(--ods-color-text-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=accent]:hover,[variant=default][hoverable]:not([disabled])[color^=accent]:hover){background-color:var(--ods-color-accent-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=error]:hover,[variant=default][hoverable]:not([disabled])[color^=error]:hover){background-color:var(--ods-color-error-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=warning]:hover,[variant=default][hoverable]:not([disabled])[color^=warning]:hover){background-color:var(--ods-color-warning-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=success]:hover,[variant=default][hoverable]:not([disabled])[color^=success]:hover){background-color:var(--ods-color-success-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=info]:hover,[variant=default][hoverable]:not([disabled])[color^=info]:hover){background-color:var(--ods-color-info-100)}:host(:not([variant])[hoverable]:not([disabled])[color^=promotion]:hover,[variant=default][hoverable]:not([disabled])[color^=promotion]:hover){background-color:var(--ods-color-promotion-100)}:host(:not([variant])[hoverable]:not([disabled]):not([color]):active,[variant=default][hoverable]:not([disabled]):not([color]):active){background-color:var(--ods-color-default-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=default]:active,[variant=default][hoverable]:not([disabled])[color^=default]:active){background-color:var(--ods-color-default-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=primary]:active,[variant=default][hoverable]:not([disabled])[color^=primary]:active){background-color:var(--ods-color-primary-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=text]:active,[variant=default][hoverable]:not([disabled])[color^=text]:active){background-color:var(--ods-color-text-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=accent]:active,[variant=default][hoverable]:not([disabled])[color^=accent]:active){background-color:var(--ods-color-accent-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=error]:active,[variant=default][hoverable]:not([disabled])[color^=error]:active){background-color:var(--ods-color-error-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=warning]:active,[variant=default][hoverable]:not([disabled])[color^=warning]:active){background-color:var(--ods-color-warning-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=success]:active,[variant=default][hoverable]:not([disabled])[color^=success]:active){background-color:var(--ods-color-success-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=info]:active,[variant=default][hoverable]:not([disabled])[color^=info]:active){background-color:var(--ods-color-info-200)}:host(:not([variant])[hoverable]:not([disabled])[color^=promotion]:active,[variant=default][hoverable]:not([disabled])[color^=promotion]:active){background-color:var(--ods-color-promotion-200)}:host(:not([variant])[checked]:not([color]),[variant=default][checked]:not([color])),:host(:not([variant])[checked]:not([color]):hover,[variant=default][checked]:not([color]):hover){border-color:var(--ods-color-default-500)}:host(:not([variant])[checked][color^=default],[variant=default][checked][color^=default]),:host(:not([variant])[checked][color^=default]:hover,[variant=default][checked][color^=default]:hover){border-color:var(--ods-color-default-500)}:host(:not([variant])[checked][color^=primary],[variant=default][checked][color^=primary]),:host(:not([variant])[checked][color^=primary]:hover,[variant=default][checked][color^=primary]:hover){border-color:var(--ods-color-primary-500)}:host(:not([variant])[checked][color^=text],[variant=default][checked][color^=text]),:host(:not([variant])[checked][color^=text]:hover,[variant=default][checked][color^=text]:hover){border-color:var(--ods-color-text-500)}:host(:not([variant])[checked][color^=accent],[variant=default][checked][color^=accent]),:host(:not([variant])[checked][color^=accent]:hover,[variant=default][checked][color^=accent]:hover){border-color:var(--ods-color-accent-500)}:host(:not([variant])[checked][color^=error],[variant=default][checked][color^=error]),:host(:not([variant])[checked][color^=error]:hover,[variant=default][checked][color^=error]:hover){border-color:var(--ods-color-error-500)}:host(:not([variant])[checked][color^=warning],[variant=default][checked][color^=warning]),:host(:not([variant])[checked][color^=warning]:hover,[variant=default][checked][color^=warning]:hover){border-color:var(--ods-color-warning-500)}:host(:not([variant])[checked][color^=success],[variant=default][checked][color^=success]),:host(:not([variant])[checked][color^=success]:hover,[variant=default][checked][color^=success]:hover){border-color:var(--ods-color-success-500)}:host(:not([variant])[checked][color^=info],[variant=default][checked][color^=info]),:host(:not([variant])[checked][color^=info]:hover,[variant=default][checked][color^=info]:hover){border-color:var(--ods-color-info-500)}:host(:not([variant])[checked][color^=promotion],[variant=default][checked][color^=promotion]),:host(:not([variant])[checked][color^=promotion]:hover,[variant=default][checked][color^=promotion]:hover){border-color:var(--ods-color-promotion-500)}:host(:not([variant])[checking]:not([color]),[variant=default][checking]:not([color])):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host(:not([variant])[checking][color^=default],[variant=default][checking][color^=default]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host(:not([variant])[checking][color^=primary],[variant=default][checking][color^=primary]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-primary-500), var(--ods-color-primary-100), var(--ods-color-primary-500), var(--ods-color-primary-100))}:host(:not([variant])[checking][color^=text],[variant=default][checking][color^=text]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-text-500), var(--ods-color-text-100), var(--ods-color-text-500), var(--ods-color-text-100))}:host(:not([variant])[checking][color^=accent],[variant=default][checking][color^=accent]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-accent-500), var(--ods-color-accent-100), var(--ods-color-accent-500), var(--ods-color-accent-100))}:host(:not([variant])[checking][color^=error],[variant=default][checking][color^=error]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-error-500), var(--ods-color-error-100), var(--ods-color-error-500), var(--ods-color-error-100))}:host(:not([variant])[checking][color^=warning],[variant=default][checking][color^=warning]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-warning-500), var(--ods-color-warning-100), var(--ods-color-warning-500), var(--ods-color-warning-100))}:host(:not([variant])[checking][color^=success],[variant=default][checking][color^=success]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-success-500), var(--ods-color-success-100), var(--ods-color-success-500), var(--ods-color-success-100))}:host(:not([variant])[checking][color^=info],[variant=default][checking][color^=info]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-info-500), var(--ods-color-info-100), var(--ods-color-info-500), var(--ods-color-info-100))}:host(:not([variant])[checking][color^=promotion],[variant=default][checking][color^=promotion]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-promotion-500), var(--ods-color-promotion-100), var(--ods-color-promotion-500), var(--ods-color-promotion-100))}:host([variant=stroked]:not([color])){border-color:var(--ods-color-default-200);background-color:var(--ods-color-default-000)}:host([variant=stroked][color^=default]){border-color:var(--ods-color-default-200);background-color:var(--ods-color-default-000)}:host([variant=stroked][color^=primary]){border-color:var(--ods-color-primary-200);background-color:var(--ods-color-primary-000)}:host([variant=stroked][color^=text]){border-color:var(--ods-color-text-200);background-color:var(--ods-color-text-000)}:host([variant=stroked][color^=accent]){border-color:var(--ods-color-accent-200);background-color:var(--ods-color-accent-000)}:host([variant=stroked][color^=error]){border-color:var(--ods-color-error-200);background-color:var(--ods-color-error-000)}:host([variant=stroked][color^=warning]){border-color:var(--ods-color-warning-200);background-color:var(--ods-color-warning-000)}:host([variant=stroked][color^=success]){border-color:var(--ods-color-success-200);background-color:var(--ods-color-success-000)}:host([variant=stroked][color^=info]){border-color:var(--ods-color-info-200);background-color:var(--ods-color-info-000)}:host([variant=stroked][color^=promotion]){border-color:var(--ods-color-promotion-200);background-color:var(--ods-color-promotion-000)}:host([variant=stroked][hoverable]:not([disabled]):not([color]):hover){background-color:var(--ods-color-default-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=default]:hover){background-color:var(--ods-color-default-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=primary]:hover){background-color:var(--ods-color-primary-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=text]:hover){background-color:var(--ods-color-text-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=accent]:hover){background-color:var(--ods-color-accent-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=error]:hover){background-color:var(--ods-color-error-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=warning]:hover){background-color:var(--ods-color-warning-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=success]:hover){background-color:var(--ods-color-success-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=info]:hover){background-color:var(--ods-color-info-100)}:host([variant=stroked][hoverable]:not([disabled])[color^=promotion]:hover){background-color:var(--ods-color-promotion-100)}:host([variant=stroked][hoverable]:not([disabled]):not([color]):active){background-color:var(--ods-color-default-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=default]:active){background-color:var(--ods-color-default-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=primary]:active){background-color:var(--ods-color-primary-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=text]:active){background-color:var(--ods-color-text-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=accent]:active){background-color:var(--ods-color-accent-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=error]:active){background-color:var(--ods-color-error-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=warning]:active){background-color:var(--ods-color-warning-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=success]:active){background-color:var(--ods-color-success-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=info]:active){background-color:var(--ods-color-info-200)}:host([variant=stroked][hoverable]:not([disabled])[color^=promotion]:active){background-color:var(--ods-color-promotion-200)}:host([variant=stroked][checked]:not([color])),:host([variant=stroked][checked]:not([color]):hover){border-color:var(--ods-color-default-500)}:host([variant=stroked][checked][color^=default]),:host([variant=stroked][checked][color^=default]:hover){border-color:var(--ods-color-default-500)}:host([variant=stroked][checked][color^=primary]),:host([variant=stroked][checked][color^=primary]:hover){border-color:var(--ods-color-primary-500)}:host([variant=stroked][checked][color^=text]),:host([variant=stroked][checked][color^=text]:hover){border-color:var(--ods-color-text-500)}:host([variant=stroked][checked][color^=accent]),:host([variant=stroked][checked][color^=accent]:hover){border-color:var(--ods-color-accent-500)}:host([variant=stroked][checked][color^=error]),:host([variant=stroked][checked][color^=error]:hover){border-color:var(--ods-color-error-500)}:host([variant=stroked][checked][color^=warning]),:host([variant=stroked][checked][color^=warning]:hover){border-color:var(--ods-color-warning-500)}:host([variant=stroked][checked][color^=success]),:host([variant=stroked][checked][color^=success]:hover){border-color:var(--ods-color-success-500)}:host([variant=stroked][checked][color^=info]),:host([variant=stroked][checked][color^=info]:hover){border-color:var(--ods-color-info-500)}:host([variant=stroked][checked][color^=promotion]),:host([variant=stroked][checked][color^=promotion]:hover){border-color:var(--ods-color-promotion-500)}:host([variant=stroked][checking]:not([color])):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host([variant=stroked][checking][color^=default]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host([variant=stroked][checking][color^=primary]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-primary-500), var(--ods-color-primary-100), var(--ods-color-primary-500), var(--ods-color-primary-100))}:host([variant=stroked][checking][color^=text]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-text-500), var(--ods-color-text-100), var(--ods-color-text-500), var(--ods-color-text-100))}:host([variant=stroked][checking][color^=accent]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-accent-500), var(--ods-color-accent-100), var(--ods-color-accent-500), var(--ods-color-accent-100))}:host([variant=stroked][checking][color^=error]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-error-500), var(--ods-color-error-100), var(--ods-color-error-500), var(--ods-color-error-100))}:host([variant=stroked][checking][color^=warning]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-warning-500), var(--ods-color-warning-100), var(--ods-color-warning-500), var(--ods-color-warning-100))}:host([variant=stroked][checking][color^=success]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-success-500), var(--ods-color-success-100), var(--ods-color-success-500), var(--ods-color-success-100))}:host([variant=stroked][checking][color^=info]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-info-500), var(--ods-color-info-100), var(--ods-color-info-500), var(--ods-color-info-100))}:host([variant=stroked][checking][color^=promotion]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-promotion-500), var(--ods-color-promotion-100), var(--ods-color-promotion-500), var(--ods-color-promotion-100))}:host([variant=flat]:not([color])){border-color:var(--ods-color-default-000);background-color:var(--ods-color-default-000)}:host([variant=flat][color^=default]){border-color:var(--ods-color-default-000);background-color:var(--ods-color-default-000)}:host([variant=flat][color^=primary]){border-color:var(--ods-color-primary-000);background-color:var(--ods-color-primary-000)}:host([variant=flat][color^=text]){border-color:var(--ods-color-text-000);background-color:var(--ods-color-text-000)}:host([variant=flat][color^=accent]){border-color:var(--ods-color-accent-000);background-color:var(--ods-color-accent-000)}:host([variant=flat][color^=error]){border-color:var(--ods-color-error-000);background-color:var(--ods-color-error-000)}:host([variant=flat][color^=warning]){border-color:var(--ods-color-warning-000);background-color:var(--ods-color-warning-000)}:host([variant=flat][color^=success]){border-color:var(--ods-color-success-000);background-color:var(--ods-color-success-000)}:host([variant=flat][color^=info]){border-color:var(--ods-color-info-000);background-color:var(--ods-color-info-000)}:host([variant=flat][color^=promotion]){border-color:var(--ods-color-promotion-000);background-color:var(--ods-color-promotion-000)}:host([variant=flat][hoverable]:not([disabled]):not([color]):hover){border-color:var(--ods-color-default-100);background-color:var(--ods-color-default-100)}:host([variant=flat][hoverable]:not([disabled])[color^=default]:hover){border-color:var(--ods-color-default-100);background-color:var(--ods-color-default-100)}:host([variant=flat][hoverable]:not([disabled])[color^=primary]:hover){border-color:var(--ods-color-primary-100);background-color:var(--ods-color-primary-100)}:host([variant=flat][hoverable]:not([disabled])[color^=text]:hover){border-color:var(--ods-color-text-100);background-color:var(--ods-color-text-100)}:host([variant=flat][hoverable]:not([disabled])[color^=accent]:hover){border-color:var(--ods-color-accent-100);background-color:var(--ods-color-accent-100)}:host([variant=flat][hoverable]:not([disabled])[color^=error]:hover){border-color:var(--ods-color-error-100);background-color:var(--ods-color-error-100)}:host([variant=flat][hoverable]:not([disabled])[color^=warning]:hover){border-color:var(--ods-color-warning-100);background-color:var(--ods-color-warning-100)}:host([variant=flat][hoverable]:not([disabled])[color^=success]:hover){border-color:var(--ods-color-success-100);background-color:var(--ods-color-success-100)}:host([variant=flat][hoverable]:not([disabled])[color^=info]:hover){border-color:var(--ods-color-info-100);background-color:var(--ods-color-info-100)}:host([variant=flat][hoverable]:not([disabled])[color^=promotion]:hover){border-color:var(--ods-color-promotion-100);background-color:var(--ods-color-promotion-100)}:host([variant=flat][hoverable]:not([disabled]):not([color]):active){border-color:var(--ods-color-default-200);background-color:var(--ods-color-default-200)}:host([variant=flat][hoverable]:not([disabled])[color^=default]:active){border-color:var(--ods-color-default-200);background-color:var(--ods-color-default-200)}:host([variant=flat][hoverable]:not([disabled])[color^=primary]:active){border-color:var(--ods-color-primary-200);background-color:var(--ods-color-primary-200)}:host([variant=flat][hoverable]:not([disabled])[color^=text]:active){border-color:var(--ods-color-text-200);background-color:var(--ods-color-text-200)}:host([variant=flat][hoverable]:not([disabled])[color^=accent]:active){border-color:var(--ods-color-accent-200);background-color:var(--ods-color-accent-200)}:host([variant=flat][hoverable]:not([disabled])[color^=error]:active){border-color:var(--ods-color-error-200);background-color:var(--ods-color-error-200)}:host([variant=flat][hoverable]:not([disabled])[color^=warning]:active){border-color:var(--ods-color-warning-200);background-color:var(--ods-color-warning-200)}:host([variant=flat][hoverable]:not([disabled])[color^=success]:active){border-color:var(--ods-color-success-200);background-color:var(--ods-color-success-200)}:host([variant=flat][hoverable]:not([disabled])[color^=info]:active){border-color:var(--ods-color-info-200);background-color:var(--ods-color-info-200)}:host([variant=flat][hoverable]:not([disabled])[color^=promotion]:active){border-color:var(--ods-color-promotion-200);background-color:var(--ods-color-promotion-200)}:host([variant=flat][checking]:not([color])):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host([variant=flat][checking][color^=default]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host([variant=flat][checking][color^=primary]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-primary-500), var(--ods-color-primary-100), var(--ods-color-primary-500), var(--ods-color-primary-100))}:host([variant=flat][checking][color^=text]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-text-500), var(--ods-color-text-100), var(--ods-color-text-500), var(--ods-color-text-100))}:host([variant=flat][checking][color^=accent]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-accent-500), var(--ods-color-accent-100), var(--ods-color-accent-500), var(--ods-color-accent-100))}:host([variant=flat][checking][color^=error]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-error-500), var(--ods-color-error-100), var(--ods-color-error-500), var(--ods-color-error-100))}:host([variant=flat][checking][color^=warning]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-warning-500), var(--ods-color-warning-100), var(--ods-color-warning-500), var(--ods-color-warning-100))}:host([variant=flat][checking][color^=success]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-success-500), var(--ods-color-success-100), var(--ods-color-success-500), var(--ods-color-success-100))}:host([variant=flat][checking][color^=info]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-info-500), var(--ods-color-info-100), var(--ods-color-info-500), var(--ods-color-info-100))}:host([variant=flat][checking][color^=promotion]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-promotion-500), var(--ods-color-promotion-100), var(--ods-color-promotion-500), var(--ods-color-promotion-100))}:host([variant=ghost]:not([color])){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=default]){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=primary]){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=text]){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=accent]){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=error]){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=warning]){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=success]){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=info]){border-color:transparent;background-color:transparent}:host([variant=ghost][color^=promotion]){border-color:transparent;background-color:transparent}:host([variant=ghost][hoverable]:not([disabled]):not([color]):hover){border-color:var(--ods-color-default-100);background-color:var(--ods-color-default-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=default]:hover){border-color:var(--ods-color-default-100);background-color:var(--ods-color-default-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=primary]:hover){border-color:var(--ods-color-primary-100);background-color:var(--ods-color-primary-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=text]:hover){border-color:var(--ods-color-text-100);background-color:var(--ods-color-text-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=accent]:hover){border-color:var(--ods-color-accent-100);background-color:var(--ods-color-accent-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=error]:hover){border-color:var(--ods-color-error-100);background-color:var(--ods-color-error-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=warning]:hover){border-color:var(--ods-color-warning-100);background-color:var(--ods-color-warning-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=success]:hover){border-color:var(--ods-color-success-100);background-color:var(--ods-color-success-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=info]:hover){border-color:var(--ods-color-info-100);background-color:var(--ods-color-info-100)}:host([variant=ghost][hoverable]:not([disabled])[color^=promotion]:hover){border-color:var(--ods-color-promotion-100);background-color:var(--ods-color-promotion-100)}:host([variant=ghost][hoverable]:not([disabled]):not([color]):active){border-color:var(--ods-color-default-200);background-color:var(--ods-color-default-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=default]:active){border-color:var(--ods-color-default-200);background-color:var(--ods-color-default-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=primary]:active){border-color:var(--ods-color-primary-200);background-color:var(--ods-color-primary-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=text]:active){border-color:var(--ods-color-text-200);background-color:var(--ods-color-text-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=accent]:active){border-color:var(--ods-color-accent-200);background-color:var(--ods-color-accent-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=error]:active){border-color:var(--ods-color-error-200);background-color:var(--ods-color-error-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=warning]:active){border-color:var(--ods-color-warning-200);background-color:var(--ods-color-warning-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=success]:active){border-color:var(--ods-color-success-200);background-color:var(--ods-color-success-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=info]:active){border-color:var(--ods-color-info-200);background-color:var(--ods-color-info-200)}:host([variant=ghost][hoverable]:not([disabled])[color^=promotion]:active){border-color:var(--ods-color-promotion-200);background-color:var(--ods-color-promotion-200)}:host([variant=ghost][checked]:not([color])),:host([variant=ghost][checked]:not([color]):hover){border-color:var(--ods-color-default-500)}:host([variant=ghost][checked][color^=default]),:host([variant=ghost][checked][color^=default]:hover){border-color:var(--ods-color-default-500)}:host([variant=ghost][checked][color^=primary]),:host([variant=ghost][checked][color^=primary]:hover){border-color:var(--ods-color-primary-500)}:host([variant=ghost][checked][color^=text]),:host([variant=ghost][checked][color^=text]:hover){border-color:var(--ods-color-text-500)}:host([variant=ghost][checked][color^=accent]),:host([variant=ghost][checked][color^=accent]:hover){border-color:var(--ods-color-accent-500)}:host([variant=ghost][checked][color^=error]),:host([variant=ghost][checked][color^=error]:hover){border-color:var(--ods-color-error-500)}:host([variant=ghost][checked][color^=warning]),:host([variant=ghost][checked][color^=warning]:hover){border-color:var(--ods-color-warning-500)}:host([variant=ghost][checked][color^=success]),:host([variant=ghost][checked][color^=success]:hover){border-color:var(--ods-color-success-500)}:host([variant=ghost][checked][color^=info]),:host([variant=ghost][checked][color^=info]:hover){border-color:var(--ods-color-info-500)}:host([variant=ghost][checked][color^=promotion]),:host([variant=ghost][checked][color^=promotion]:hover){border-color:var(--ods-color-promotion-500)}:host([variant=ghost][checking]:not([color])):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host([variant=ghost][checking][color^=default]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host([variant=ghost][checking][color^=primary]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-primary-500), var(--ods-color-primary-100), var(--ods-color-primary-500), var(--ods-color-primary-100))}:host([variant=ghost][checking][color^=text]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-text-500), var(--ods-color-text-100), var(--ods-color-text-500), var(--ods-color-text-100))}:host([variant=ghost][checking][color^=accent]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-accent-500), var(--ods-color-accent-100), var(--ods-color-accent-500), var(--ods-color-accent-100))}:host([variant=ghost][checking][color^=error]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-error-500), var(--ods-color-error-100), var(--ods-color-error-500), var(--ods-color-error-100))}:host([variant=ghost][checking][color^=warning]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-warning-500), var(--ods-color-warning-100), var(--ods-color-warning-500), var(--ods-color-warning-100))}:host([variant=ghost][checking][color^=success]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-success-500), var(--ods-color-success-100), var(--ods-color-success-500), var(--ods-color-success-100))}:host([variant=ghost][checking][color^=info]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-info-500), var(--ods-color-info-100), var(--ods-color-info-500), var(--ods-color-info-100))}:host([variant=ghost][checking][color^=promotion]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-promotion-500), var(--ods-color-promotion-100), var(--ods-color-promotion-500), var(--ods-color-promotion-100))}:host([variant=hollow]:not([color])){border-color:var(--ods-color-default-200);background-color:transparent}:host([variant=hollow][color^=default]){border-color:var(--ods-color-default-200);background-color:transparent}:host([variant=hollow][color^=primary]){border-color:var(--ods-color-primary-200);background-color:transparent}:host([variant=hollow][color^=text]){border-color:var(--ods-color-text-200);background-color:transparent}:host([variant=hollow][color^=accent]){border-color:var(--ods-color-accent-200);background-color:transparent}:host([variant=hollow][color^=error]){border-color:var(--ods-color-error-200);background-color:transparent}:host([variant=hollow][color^=warning]){border-color:var(--ods-color-warning-200);background-color:transparent}:host([variant=hollow][color^=success]){border-color:var(--ods-color-success-200);background-color:transparent}:host([variant=hollow][color^=info]){border-color:var(--ods-color-info-200);background-color:transparent}:host([variant=hollow][color^=promotion]){border-color:var(--ods-color-promotion-200);background-color:transparent}:host([variant=hollow][hoverable]:not([disabled]):not([color]):hover){background-color:transparent;border-color:var(--ods-color-default-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=default]:hover){background-color:transparent;border-color:var(--ods-color-default-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=primary]:hover){background-color:transparent;border-color:var(--ods-color-primary-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=text]:hover){background-color:transparent;border-color:var(--ods-color-text-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=accent]:hover){background-color:transparent;border-color:var(--ods-color-accent-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=error]:hover){background-color:transparent;border-color:var(--ods-color-error-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=warning]:hover){background-color:transparent;border-color:var(--ods-color-warning-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=success]:hover){background-color:transparent;border-color:var(--ods-color-success-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=info]:hover){background-color:transparent;border-color:var(--ods-color-info-100)}:host([variant=hollow][hoverable]:not([disabled])[color^=promotion]:hover){background-color:transparent;border-color:var(--ods-color-promotion-100)}:host([variant=hollow][hoverable]:not([disabled]):not([color]):active){background-color:transparent;border-color:var(--ods-color-default-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=default]:active){background-color:transparent;border-color:var(--ods-color-default-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=primary]:active){background-color:transparent;border-color:var(--ods-color-primary-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=text]:active){background-color:transparent;border-color:var(--ods-color-text-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=accent]:active){background-color:transparent;border-color:var(--ods-color-accent-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=error]:active){background-color:transparent;border-color:var(--ods-color-error-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=warning]:active){background-color:transparent;border-color:var(--ods-color-warning-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=success]:active){background-color:transparent;border-color:var(--ods-color-success-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=info]:active){background-color:transparent;border-color:var(--ods-color-info-200)}:host([variant=hollow][hoverable]:not([disabled])[color^=promotion]:active){background-color:transparent;border-color:var(--ods-color-promotion-200)}:host([variant=hollow][checked]:not([color])),:host([variant=hollow][checked]:not([color]):hover){border-color:var(--ods-color-default-500)}:host([variant=hollow][checked][color^=default]),:host([variant=hollow][checked][color^=default]:hover){border-color:var(--ods-color-default-500)}:host([variant=hollow][checked][color^=primary]),:host([variant=hollow][checked][color^=primary]:hover){border-color:var(--ods-color-primary-500)}:host([variant=hollow][checked][color^=text]),:host([variant=hollow][checked][color^=text]:hover){border-color:var(--ods-color-text-500)}:host([variant=hollow][checked][color^=accent]),:host([variant=hollow][checked][color^=accent]:hover){border-color:var(--ods-color-accent-500)}:host([variant=hollow][checked][color^=error]),:host([variant=hollow][checked][color^=error]:hover){border-color:var(--ods-color-error-500)}:host([variant=hollow][checked][color^=warning]),:host([variant=hollow][checked][color^=warning]:hover){border-color:var(--ods-color-warning-500)}:host([variant=hollow][checked][color^=success]),:host([variant=hollow][checked][color^=success]:hover){border-color:var(--ods-color-success-500)}:host([variant=hollow][checked][color^=info]),:host([variant=hollow][checked][color^=info]:hover){border-color:var(--ods-color-info-500)}:host([variant=hollow][checked][color^=promotion]),:host([variant=hollow][checked][color^=promotion]:hover){border-color:var(--ods-color-promotion-500)}:host([variant=hollow][checking]:not([color])):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host([variant=hollow][checking][color^=default]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-default-500), var(--ods-color-default-100), var(--ods-color-default-500), var(--ods-color-default-100))}:host([variant=hollow][checking][color^=primary]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-primary-500), var(--ods-color-primary-100), var(--ods-color-primary-500), var(--ods-color-primary-100))}:host([variant=hollow][checking][color^=text]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-text-500), var(--ods-color-text-100), var(--ods-color-text-500), var(--ods-color-text-100))}:host([variant=hollow][checking][color^=accent]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-accent-500), var(--ods-color-accent-100), var(--ods-color-accent-500), var(--ods-color-accent-100))}:host([variant=hollow][checking][color^=error]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-error-500), var(--ods-color-error-100), var(--ods-color-error-500), var(--ods-color-error-100))}:host([variant=hollow][checking][color^=warning]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-warning-500), var(--ods-color-warning-100), var(--ods-color-warning-500), var(--ods-color-warning-100))}:host([variant=hollow][checking][color^=success]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-success-500), var(--ods-color-success-100), var(--ods-color-success-500), var(--ods-color-success-100))}:host([variant=hollow][checking][color^=info]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-info-500), var(--ods-color-info-100), var(--ods-color-info-500), var(--ods-color-info-100))}:host([variant=hollow][checking][color^=promotion]):after{background-image:linear-gradient(transparent, transparent), linear-gradient(45deg, var(--ods-color-promotion-500), var(--ods-color-promotion-100), var(--ods-color-promotion-500), var(--ods-color-promotion-100))}:host([size=sm]){padding:var(--ods-size-tile-sm-padding)}:host([size=md]){padding:var(--ods-size-tile-md-padding)}:host([size=md]){font-family:var(--ods-typography-body-400-font-family);font-size:var(--ods-typography-body-400-font-size);font-style:var(--ods-typography-body-400-font-style);font-weight:var(--ods-typography-body-400-font-weight);letter-spacing:var(--ods-typography-body-400-letter-spacing);line-height:var(--ods-typography-body-400-line-height)}:host([size=sm]){font-family:var(--ods-typography-body-400-font-family);font-size:var(--ods-typography-body-400-font-size);font-style:var(--ods-typography-body-400-font-style);font-weight:var(--ods-typography-body-400-font-weight);letter-spacing:var(--ods-typography-body-400-letter-spacing);line-height:var(--ods-typography-body-400-line-height)}';
var OsdsTile$1 = proxyCustomElement(class extends H {
  constructor() {
    super();
    this.__registerHost();
    this.__attachShadow();
    this.controller = new OdsTileController(this);
    this.checked = DEFAULT_ATTRIBUTE.checked;
    this.checking = DEFAULT_ATTRIBUTE.checking;
    this.color = DEFAULT_ATTRIBUTE.color;
    this.disabled = DEFAULT_ATTRIBUTE.disabled;
    this.hasFocus = DEFAULT_ATTRIBUTE.hasFocus;
    this.hoverable = DEFAULT_ATTRIBUTE.hoverable;
    this.inline = DEFAULT_ATTRIBUTE.inline;
    this.loading = DEFAULT_ATTRIBUTE.loading;
    this.rounded = DEFAULT_ATTRIBUTE.rounded;
    this.size = DEFAULT_ATTRIBUTE.size;
    this.variant = DEFAULT_ATTRIBUTE.variant;
  }
  /** @see OdsTileBehavior.beforeRender */
  beforeRender() {
    this.controller.validateAttributes();
  }
  componentWillRender() {
    this.beforeRender();
  }
  render() {
    return h(Host, Object.assign({}, {
      onClick: () => this.controller.handleClick()
    }), h("slot", { name: "start" }), h("span", { class: "tile__centered-text" }, h("slot", null)), h("slot", { name: "end" }));
  }
  get el() {
    return this;
  }
  static get style() {
    return osdsTileCss;
  }
}, [1, "osds-tile", {
  "checked": [516],
  "checking": [516],
  "color": [513],
  "disabled": [516],
  "hasFocus": [1540, "has-focus"],
  "hoverable": [516],
  "inline": [1540],
  "loading": [516],
  "rounded": [516],
  "size": [513],
  "variant": [513]
}]);
function defineCustomElement$1() {
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["osds-tile"];
  components.forEach((tagName) => {
    switch (tagName) {
      case "osds-tile":
        if (!customElements.get(tagName)) {
          customElements.define(tagName, OsdsTile$1);
        }
        break;
    }
  });
}
var defineCustomElement2 = defineCustomElement$1;

// ../../node_modules/@ovhcloud/ods-components/tile/react/dist/esm/index.js
var OsdsTile = createReactComponent("osds-tile", void 0, void 0, defineCustomElement2);
export {
  OsdsTile
};
/*! Bundled license information:

@ovhcloud/ods-components/tile/react/dist/esm/react-component-lib/utils/attachProps.js:
  (**
   * Checks if an event is supported in the current execution environment.
   * @license Modernizr 3.0.0pre (Custom Build) | MIT
   *)
*/
//# sourceMappingURL=@ovhcloud_ods-components_tile_react.js.map
