import "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/@ovhcloud/ods-common-theming/dist/esm/constants/ods-theme-color-hue.js
var ODS_THEME_COLOR_HUE;
(function(ODS_THEME_COLOR_HUE2) {
  ODS_THEME_COLOR_HUE2["_000"] = "000";
  ODS_THEME_COLOR_HUE2["_050"] = "050";
  ODS_THEME_COLOR_HUE2["_075"] = "075";
  ODS_THEME_COLOR_HUE2["_100"] = "100";
  ODS_THEME_COLOR_HUE2["_200"] = "200";
  ODS_THEME_COLOR_HUE2["_300"] = "300";
  ODS_THEME_COLOR_HUE2["_400"] = "400";
  ODS_THEME_COLOR_HUE2["_500"] = "500";
  ODS_THEME_COLOR_HUE2["_600"] = "600";
  ODS_THEME_COLOR_HUE2["_700"] = "700";
  ODS_THEME_COLOR_HUE2["_800"] = "800";
  ODS_THEME_COLOR_HUE2["_900"] = "900";
  ODS_THEME_COLOR_HUE2["_1000"] = "1000";
})(ODS_THEME_COLOR_HUE || (ODS_THEME_COLOR_HUE = {}));
var ODS_THEME_COLOR_HUES = Object.freeze(Object.values(ODS_THEME_COLOR_HUE));

// ../../node_modules/@ovhcloud/ods-common-theming/dist/esm/constants/ods-theme-color-intent.js
var ODS_THEME_COLOR_INTENT;
(function(ODS_THEME_COLOR_INTENT2) {
  ODS_THEME_COLOR_INTENT2["accent"] = "accent";
  ODS_THEME_COLOR_INTENT2["default"] = "default";
  ODS_THEME_COLOR_INTENT2["error"] = "error";
  ODS_THEME_COLOR_INTENT2["info"] = "info";
  ODS_THEME_COLOR_INTENT2["primary"] = "primary";
  ODS_THEME_COLOR_INTENT2["promotion"] = "promotion";
  ODS_THEME_COLOR_INTENT2["success"] = "success";
  ODS_THEME_COLOR_INTENT2["text"] = "text";
  ODS_THEME_COLOR_INTENT2["warning"] = "warning";
})(ODS_THEME_COLOR_INTENT || (ODS_THEME_COLOR_INTENT = {}));
var ODS_THEME_COLOR_INTENTS = Object.freeze(Object.values(ODS_THEME_COLOR_INTENT));

// ../../node_modules/@ovhcloud/ods-common-theming/dist/esm/constants/ods-theme-size.js
var ODS_THEME_SIZE;
(function(ODS_THEME_SIZE2) {
  ODS_THEME_SIZE2["_100"] = "100";
  ODS_THEME_SIZE2["_200"] = "200";
  ODS_THEME_SIZE2["_300"] = "300";
  ODS_THEME_SIZE2["_400"] = "400";
  ODS_THEME_SIZE2["_500"] = "500";
  ODS_THEME_SIZE2["_600"] = "600";
  ODS_THEME_SIZE2["_700"] = "700";
  ODS_THEME_SIZE2["_800"] = "800";
  ODS_THEME_SIZE2["_900"] = "900";
})(ODS_THEME_SIZE || (ODS_THEME_SIZE = {}));
var ODS_THEME_SIZES = Object.freeze(Object.values(ODS_THEME_SIZE));

// ../../node_modules/@ovhcloud/ods-common-theming/dist/esm/constants/ods-theme-typography-level.js
var ODS_THEME_TYPOGRAPHY_LEVEL;
(function(ODS_THEME_TYPOGRAPHY_LEVEL2) {
  ODS_THEME_TYPOGRAPHY_LEVEL2["body"] = "body";
  ODS_THEME_TYPOGRAPHY_LEVEL2["button"] = "button";
  ODS_THEME_TYPOGRAPHY_LEVEL2["caption"] = "caption";
  ODS_THEME_TYPOGRAPHY_LEVEL2["heading"] = "heading";
  ODS_THEME_TYPOGRAPHY_LEVEL2["subheading"] = "subheading";
})(ODS_THEME_TYPOGRAPHY_LEVEL || (ODS_THEME_TYPOGRAPHY_LEVEL = {}));
var ODS_THEME_TYPOGRAPHY_LEVELS = Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_LEVEL));

// ../../node_modules/@ovhcloud/ods-common-theming/dist/esm/constants/ods-theme-typography-size.js
var ODS_THEME_TYPOGRAPHY_SIZE;
(function(ODS_THEME_TYPOGRAPHY_SIZE2) {
  ODS_THEME_TYPOGRAPHY_SIZE2["_100"] = "100";
  ODS_THEME_TYPOGRAPHY_SIZE2["_200"] = "200";
  ODS_THEME_TYPOGRAPHY_SIZE2["_300"] = "300";
  ODS_THEME_TYPOGRAPHY_SIZE2["_400"] = "400";
  ODS_THEME_TYPOGRAPHY_SIZE2["_500"] = "500";
  ODS_THEME_TYPOGRAPHY_SIZE2["_600"] = "600";
  ODS_THEME_TYPOGRAPHY_SIZE2["_700"] = "700";
  ODS_THEME_TYPOGRAPHY_SIZE2["_800"] = "800";
})(ODS_THEME_TYPOGRAPHY_SIZE || (ODS_THEME_TYPOGRAPHY_SIZE = {}));
var ODS_THEME_TYPOGRAPHY_SIZES = Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_SIZE));

// ../../node_modules/@ovhcloud/ods-common-theming/dist/esm/helpers/ods-generate-color-variable.js
function odsGenerateColorVariable(intent, hue, contrasted = false) {
  return `--ods-color-${intent}-${hue}${contrasted ? "-contrasted" : ""}`;
}
export {
  ODS_THEME_COLOR_HUE,
  ODS_THEME_COLOR_HUES,
  ODS_THEME_COLOR_INTENT,
  ODS_THEME_COLOR_INTENTS,
  ODS_THEME_SIZE,
  ODS_THEME_SIZES,
  ODS_THEME_TYPOGRAPHY_LEVEL,
  ODS_THEME_TYPOGRAPHY_LEVELS,
  ODS_THEME_TYPOGRAPHY_SIZE,
  ODS_THEME_TYPOGRAPHY_SIZES,
  odsGenerateColorVariable
};
//# sourceMappingURL=@ovhcloud_ods-common-theming.js.map
