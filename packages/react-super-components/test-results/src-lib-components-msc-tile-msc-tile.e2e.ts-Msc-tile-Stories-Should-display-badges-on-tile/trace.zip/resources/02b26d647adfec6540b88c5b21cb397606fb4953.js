import {
  require_baseFor
} from "/node_modules/.cache/sb-vite/deps/chunk-KCXX5TFJ.js?v=25ee29f1";
import {
  require_keys
} from "/node_modules/.cache/sb-vite/deps/chunk-GOM2JPMS.js?v=25ee29f1";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/lodash/_baseForOwn.js
var require_baseForOwn = __commonJS({
  "../../node_modules/lodash/_baseForOwn.js"(exports, module) {
    var baseFor = require_baseFor();
    var keys = require_keys();
    function baseForOwn(object, iteratee) {
      return object && baseFor(object, iteratee, keys);
    }
    module.exports = baseForOwn;
  }
});

export {
  require_baseForOwn
};
//# sourceMappingURL=chunk-YZPJFT5Z.js.map
