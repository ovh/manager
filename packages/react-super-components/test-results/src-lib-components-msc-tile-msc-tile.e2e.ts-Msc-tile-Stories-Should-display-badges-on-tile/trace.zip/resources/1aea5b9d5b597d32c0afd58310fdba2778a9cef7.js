const importers = {
        './src/lib/components/msc-tile/msc-tile.stories.tsx': async () => import("/src/lib/components/msc-tile/msc-tile.stories.tsx")
    };

    export async function importFn(path) {
        return importers[path]();
    };importFn.__docgenInfo={"description":"","methods":[],"displayName":"importFn"}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIiJdLCJzb3VyY2VzQ29udGVudCI6W251bGxdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSJ9