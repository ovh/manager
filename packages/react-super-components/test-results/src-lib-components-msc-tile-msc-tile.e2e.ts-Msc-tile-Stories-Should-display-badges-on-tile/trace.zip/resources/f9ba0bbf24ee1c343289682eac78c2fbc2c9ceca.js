import {
  require_getNative
} from "/node_modules/.cache/sb-vite/deps/chunk-M3IR5ED6.js?v=25ee29f1";
import {
  require_root
} from "/node_modules/.cache/sb-vite/deps/chunk-C4UOHIYN.js?v=25ee29f1";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/lodash/_Set.js
var require_Set = __commonJS({
  "../../node_modules/lodash/_Set.js"(exports, module) {
    var getNative = require_getNative();
    var root = require_root();
    var Set = getNative(root, "Set");
    module.exports = Set;
  }
});

export {
  require_Set
};
//# sourceMappingURL=chunk-HXGZ2D24.js.map
