import {
  require_isObject
} from "/node_modules/.cache/sb-vite/deps/chunk-KJ34U6VP.js?v=25ee29f1";
import {
  require_baseGetTag
} from "/node_modules/.cache/sb-vite/deps/chunk-C4UOHIYN.js?v=25ee29f1";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/lodash/isFunction.js
var require_isFunction = __commonJS({
  "../../node_modules/lodash/isFunction.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isObject = require_isObject();
    var asyncTag = "[object AsyncFunction]";
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var proxyTag = "[object Proxy]";
    function isFunction(value) {
      if (!isObject(value)) {
        return false;
      }
      var tag = baseGetTag(value);
      return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
    }
    module.exports = isFunction;
  }
});

export {
  require_isFunction
};
//# sourceMappingURL=chunk-7NTJ6FWT.js.map
