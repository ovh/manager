import {
  require_getPrototype
} from "/node_modules/.cache/sb-vite/deps/chunk-YYQ5MWTJ.js?v=25ee29f1";
import {
  require_isObjectLike
} from "/node_modules/.cache/sb-vite/deps/chunk-M6YJEBVE.js?v=25ee29f1";
import {
  require_baseGetTag
} from "/node_modules/.cache/sb-vite/deps/chunk-C4UOHIYN.js?v=25ee29f1";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/lodash/isPlainObject.js
var require_isPlainObject = __commonJS({
  "../../node_modules/lodash/isPlainObject.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var getPrototype = require_getPrototype();
    var isObjectLike = require_isObjectLike();
    var objectTag = "[object Object]";
    var funcProto = Function.prototype;
    var objectProto = Object.prototype;
    var funcToString = funcProto.toString;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var objectCtorString = funcToString.call(Object);
    function isPlainObject(value) {
      if (!isObjectLike(value) || baseGetTag(value) != objectTag) {
        return false;
      }
      var proto = getPrototype(value);
      if (proto === null) {
        return true;
      }
      var Ctor = hasOwnProperty.call(proto, "constructor") && proto.constructor;
      return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString.call(Ctor) == objectCtorString;
    }
    module.exports = isPlainObject;
  }
});

export {
  require_isPlainObject
};
//# sourceMappingURL=chunk-IFCWBQ2D.js.map
