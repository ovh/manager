import {
  require_isArray
} from "/node_modules/.cache/sb-vite/deps/chunk-4BXE4NE3.js?v=25ee29f1";
import {
  require_isObjectLike
} from "/node_modules/.cache/sb-vite/deps/chunk-M6YJEBVE.js?v=25ee29f1";
import {
  require_baseGetTag
} from "/node_modules/.cache/sb-vite/deps/chunk-C4UOHIYN.js?v=25ee29f1";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/lodash/isString.js
var require_isString = __commonJS({
  "../../node_modules/lodash/isString.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isArray = require_isArray();
    var isObjectLike = require_isObjectLike();
    var stringTag = "[object String]";
    function isString(value) {
      return typeof value == "string" || !isArray(value) && isObjectLike(value) && baseGetTag(value) == stringTag;
    }
    module.exports = isString;
  }
});

export {
  require_isString
};
//# sourceMappingURL=chunk-RUVEYYRW.js.map
