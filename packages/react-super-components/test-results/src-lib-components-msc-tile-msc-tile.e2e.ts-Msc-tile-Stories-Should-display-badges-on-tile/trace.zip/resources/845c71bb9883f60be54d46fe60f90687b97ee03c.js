import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/lib/components/msc-tile/msc-tile.stories.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=25ee29f1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.stories.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import ScTile from "/src/lib/components/msc-tile/msc-tile.tsx?t=1699892184326";
const locale = {};
const defaultLocale = {};
const localeList = {};
export const defaultProps = {
  category: "NAS",
  tileTitle: "Titre du produit",
  tileDescription: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  href: "https://ovh.com",
  imgSrc: "https://www.ovhcloud.com/sites/default/files/styles/offer_range_card/public/2021-06/1886_AI_Notebook1_Hero_600x400.png",
  imgAlt: "offer",
  dataTracking: "home::dashboard::test"
};
const meta = {
  title: "Atoms/MscTile",
  decorators: [(Story) => /* @__PURE__ */ jsxDEV("div", { className: "columns-3", children: /* @__PURE__ */ jsxDEV(Story, {}, void 0, false, {
    fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.stories.tsx",
    lineNumber: 20,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.stories.tsx",
    lineNumber: 19,
    columnNumber: 25
  }, this)],
  component: ScTile,
  argTypes: {
    category: {
      description: "Top label of the tile",
      control: "text"
    },
    tileTitle: {
      control: "text",
      description: "Title of the tile"
    },
    tileDescription: {
      control: "text",
      description: "Description of the tile"
    },
    href: {
      control: "text",
      description: "URL of the tile and link"
    },
    isExternalHref: {
      control: "boolean",
      description: "Change the icon of the link to indicate if the link is internal or external",
      table: {
        defaultValue: {
          summary: false
        }
      }
    },
    imgSrc: {
      control: "text",
      description: "URL of the image to display in the header of the tile"
    },
    imgAlt: {
      control: "text",
      description: "Alternative label of the image"
    },
    badges: {
      description: "Display examples of badges in the story (in the actual code there is a badge slot)"
    },
    footer: {
      description: "Display an example of footer containing a button in the tile (in the actual code there is a footer slot)"
    },
    locale: {
      description: "Locale of the labels",
      control: "select",
      options: localeList,
      table: {
        defaultValue: {
          summary: defaultLocale
        }
      }
    },
    dataTracking: {
      description: "Tracking label sent when the tile or the link is clicked"
    }
  },
  args: defaultProps
};
export default meta;
const Template = (args) => /* @__PURE__ */ jsxDEV(ScTile, { ...args }, void 0, false, {
  fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.stories.tsx",
  lineNumber: 82,
  columnNumber: 66
}, this);
_c = Template;
export const Primary = Template.bind({});
Primary.args = {
  ...defaultProps
};
export const WithFooter = Template.bind({});
WithFooter.args = {
  ...defaultProps,
  footer: /* @__PURE__ */ jsxDEV("button", { color: "primary", className: "mb-1", children: "Commander" }, void 0, false, {
    fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.stories.tsx",
    lineNumber: 92,
    columnNumber: 11
  }, this)
};
export const WithBadges = Template.bind({});
WithBadges.args = {
  ...defaultProps,
  badges: [{
    text: "Cloud computing",
    color: "primary"
  }]
};
defaultProps.parameters = {
  ...defaultProps.parameters,
  docs: {
    ...defaultProps.parameters?.docs,
    source: {
      originalSource: `{
  category: 'NAS',
  tileTitle: 'Titre du produit',
  tileDescription: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  href: 'https://ovh.com',
  imgSrc: 'https://www.ovhcloud.com/sites/default/files/styles/offer_range_card/public/2021-06/1886_AI_Notebook1_Hero_600x400.png',
  imgAlt: 'offer',
  dataTracking: 'home::dashboard::test'
}`,
      ...defaultProps.parameters?.docs?.source
    }
  }
};
Primary.parameters = {
  ...Primary.parameters,
  docs: {
    ...Primary.parameters?.docs,
    source: {
      originalSource: "(args: MscTileProps) => <ScTile {...args} />",
      ...Primary.parameters?.docs?.source
    }
  }
};
WithFooter.parameters = {
  ...WithFooter.parameters,
  docs: {
    ...WithFooter.parameters?.docs,
    source: {
      originalSource: "(args: MscTileProps) => <ScTile {...args} />",
      ...WithFooter.parameters?.docs?.source
    }
  }
};
WithBadges.parameters = {
  ...WithBadges.parameters,
  docs: {
    ...WithBadges.parameters?.docs,
    source: {
      originalSource: "(args: MscTileProps) => <ScTile {...args} />",
      ...WithBadges.parameters?.docs?.source
    }
  }
};
var _c;
$RefreshReg$(_c, "Template");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.stories.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
;export const __namedExportsOrder = ["defaultProps","Primary","WithFooter","WithBadges"];