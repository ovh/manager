import {
  require_baseForOwn
} from "/node_modules/.cache/sb-vite/deps/chunk-YZPJFT5Z.js?v=25ee29f1";
import {
  require_baseIteratee
} from "/node_modules/.cache/sb-vite/deps/chunk-7P5IBE47.js?v=25ee29f1";
import {
  require_baseAssignValue
} from "/node_modules/.cache/sb-vite/deps/chunk-CWZDQPQ4.js?v=25ee29f1";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/lodash/mapValues.js
var require_mapValues = __commonJS({
  "../../node_modules/lodash/mapValues.js"(exports, module) {
    var baseAssignValue = require_baseAssignValue();
    var baseForOwn = require_baseForOwn();
    var baseIteratee = require_baseIteratee();
    function mapValues(object, iteratee) {
      var result = {};
      iteratee = baseIteratee(iteratee, 3);
      baseForOwn(object, function(value, key, object2) {
        baseAssignValue(result, key, iteratee(value, key, object2));
      });
      return result;
    }
    module.exports = mapValues;
  }
});

export {
  require_mapValues
};
//# sourceMappingURL=chunk-Q4MSS5IK.js.map
