import {
  renderElement,
  unmountElement
} from "/node_modules/.cache/sb-vite/deps/chunk-KRDZVWSL.js?v=25ee29f1";
import {
  scope
} from "/node_modules/.cache/sb-vite/deps/chunk-53B3XB6V.js?v=25ee29f1";
import {
  require_react
} from "/node_modules/.cache/sb-vite/deps/chunk-UXJYJ7WW.js?v=25ee29f1";
import {
  __toESM
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/@storybook/react/dist/chunk-JWY6Y6NU.mjs
var import_react = __toESM(require_react(), 1);
var { FRAMEWORK_OPTIONS } = scope;
var render = (args, context) => {
  let { id, component: Component2 } = context;
  if (!Component2)
    throw new Error(`Unable to render story ${id} as the component annotation is missing from the default export`);
  return import_react.default.createElement(Component2, { ...args });
};
var ErrorBoundary = class extends import_react.Component {
  constructor() {
    super(...arguments);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidMount() {
    let { hasError } = this.state, { showMain } = this.props;
    hasError || showMain();
  }
  componentDidCatch(err) {
    let { showException } = this.props;
    showException(err);
  }
  render() {
    let { hasError } = this.state, { children } = this.props;
    return hasError ? null : children;
  }
};
var Wrapper = (FRAMEWORK_OPTIONS == null ? void 0 : FRAMEWORK_OPTIONS.strictMode) ? import_react.StrictMode : import_react.Fragment;
async function renderToCanvas({ storyContext, unboundStoryFn, showMain, showException, forceRemount }, canvasElement) {
  let content = import_react.default.createElement(ErrorBoundary, { showMain, showException }, import_react.default.createElement(unboundStoryFn, { ...storyContext })), element = Wrapper ? import_react.default.createElement(Wrapper, null, content) : content;
  return forceRemount && unmountElement(canvasElement), await renderElement(element, canvasElement), () => unmountElement(canvasElement);
}

export {
  render,
  renderToCanvas
};
//# sourceMappingURL=chunk-R6WOT6AK.js.map
