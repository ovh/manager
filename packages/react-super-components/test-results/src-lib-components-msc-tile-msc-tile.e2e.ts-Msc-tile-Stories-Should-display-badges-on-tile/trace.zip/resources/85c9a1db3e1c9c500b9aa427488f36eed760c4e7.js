import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/browser-assert/lib/assert.js
var require_assert = __commonJS({
  "../../node_modules/browser-assert/lib/assert.js"(exports, module) {
    function assert(expr, message) {
      if (!Boolean(expr)) {
        throw new Error(message || "unknown assertion error");
      }
    }
    module.exports = assert;
  }
});

export {
  require_assert
};
//# sourceMappingURL=chunk-F5AJQ3NS.js.map
