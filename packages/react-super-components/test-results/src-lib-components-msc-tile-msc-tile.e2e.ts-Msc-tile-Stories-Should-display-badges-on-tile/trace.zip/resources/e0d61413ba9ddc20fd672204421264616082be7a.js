import "/src/lib/tailwind/theme.css?t=1699892263633";
import "/@fs/Users/lbueno/Documents/manager/node_modules/@ovhcloud/ods-theme-blue-jeans/dist/index.css";
const preview = {
  parameters: {
    actions: { argTypesRegex: "^on[A-Z].*" },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/
      }
    }
  }
};
export default preview;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByZXZpZXcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBQcmV2aWV3IH0gZnJvbSAnQHN0b3J5Ym9vay9yZWFjdCdcbmltcG9ydCAnLi4vc3JjL2xpYi90YWlsd2luZC90aGVtZS5jc3MnXG5pbXBvcnQgJ0BvdmhjbG91ZC9vZHMtdGhlbWUtYmx1ZS1qZWFucy9kaXN0L2luZGV4LmNzcyc7XG5cbmNvbnN0IHByZXZpZXc6IFByZXZpZXcgPSB7XG4gIHBhcmFtZXRlcnM6IHtcbiAgICBhY3Rpb25zOiB7IGFyZ1R5cGVzUmVnZXg6ICdeb25bQS1aXS4qJyB9LFxuICAgIGNvbnRyb2xzOiB7XG4gICAgICBtYXRjaGVyczoge1xuICAgICAgICBjb2xvcjogLyhiYWNrZ3JvdW5kfGNvbG9yKSQvaSxcbiAgICAgICAgZGF0ZTogL0RhdGUkLyxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn1cblxuZXhwb3J0IGRlZmF1bHQgcHJldmlld1xuIl0sIm1hcHBpbmdzIjoiQUFDQSxPQUFPO0FBQ1AsT0FBTztBQUVQLE1BQU0sVUFBbUI7QUFBQSxFQUN2QixZQUFZO0FBQUEsSUFDVixTQUFTLEVBQUUsZUFBZSxhQUFhO0FBQUEsSUFDdkMsVUFBVTtBQUFBLE1BQ1IsVUFBVTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBRUEsZUFBZTsiLCJuYW1lcyI6W119