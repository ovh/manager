import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/lib/components/msc-tile/msc-tile.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.cache/sb-vite/deps/react_jsx-dev-runtime.js?v=25ee29f1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ODS_THEME_COLOR_INTENT } from "/node_modules/.cache/sb-vite/deps/@ovhcloud_ods-common-theming.js?v=25ee29f1";
import { OsdsText } from "/node_modules/.cache/sb-vite/deps/@ovhcloud_ods-components_text_react.js?v=25ee29f1";
import { OsdsChip } from "/node_modules/.cache/sb-vite/deps/@ovhcloud_ods-components_chip_react.js?v=25ee29f1";
import { OsdsTile } from "/node_modules/.cache/sb-vite/deps/@ovhcloud_ods-components_tile_react.js?v=25ee29f1";
import { OsdsLink } from "/node_modules/.cache/sb-vite/deps/@ovhcloud_ods-components_link_react.js?v=25ee29f1";
import { OsdsIcon } from "/node_modules/.cache/sb-vite/deps/@ovhcloud_ods-components_icon_react.js?v=25ee29f1";
import { ODS_ICON_NAME, ODS_ICON_SIZE } from "/node_modules/.cache/sb-vite/deps/@ovhcloud_ods-components_icon.js?v=25ee29f1";
import { ODS_TEXT_LEVEL, ODS_TEXT_SIZE } from "/node_modules/.cache/sb-vite/deps/@ovhcloud_ods-components_text.js?v=25ee29f1";
const ScTile = ({
  href,
  isExternalHref,
  category,
  imgSrc,
  imgAlt,
  tileDescription,
  tileTitle,
  dataTracking,
  badges,
  footer
}) => {
  const localeStrings = {
    see_more_label: "See more"
  };
  const hasFooterContent = 0;
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(OsdsTile, { className: "msc-ods-tile", color: ODS_THEME_COLOR_INTENT.primary, rounded: true, inline: true, children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
    imgSrc && /* @__PURE__ */ jsxDEV("img", { className: "max-w-full m-3 w-32 h-32", src: imgSrc, alt: imgAlt }, void 0, false, {
      fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
      lineNumber: 46,
      columnNumber: 22
    }, this),
    /* @__PURE__ */ jsxDEV(OsdsText, { className: "tile-type", level: ODS_TEXT_LEVEL.heading, size: ODS_TEXT_SIZE._200, color: ODS_THEME_COLOR_INTENT.primary, children: [
      category,
      /* @__PURE__ */ jsxDEV("span", { className: "tile-badge-list", children: badges?.map((b) => /* @__PURE__ */ jsxDEV(OsdsChip, { children: b.text }, b.text, false, {
        fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
        lineNumber: 49,
        columnNumber: 65
      }, this)) }, void 0, false, {
        fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
        lineNumber: 49,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
      lineNumber: 47,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(OsdsText, { className: "tile-title", level: ODS_TEXT_LEVEL.heading, size: ODS_TEXT_SIZE._400, color: ODS_THEME_COLOR_INTENT.text, children: tileTitle }, void 0, false, {
      fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
      lineNumber: 52,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(OsdsText, { className: "tile-description", level: ODS_TEXT_LEVEL.body, size: ODS_TEXT_SIZE._400, color: ODS_THEME_COLOR_INTENT.default, children: tileDescription }, void 0, false, {
      fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
      lineNumber: 55,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(OsdsLink, { tabIndex: hasFooterContent ? 0 : -1, "data-tracking": dataTracking, color: ODS_THEME_COLOR_INTENT.primary, href, children: [
      localeStrings?.see_more_label,
      /* @__PURE__ */ jsxDEV(OsdsIcon, { slot: "end", className: "link-icon", "aria-hidden": "true", size: ODS_ICON_SIZE.xxs, name: isExternalHref ? ODS_ICON_NAME.EXTERNAL_LINK : ODS_ICON_NAME.ARROW_RIGHT, color: ODS_THEME_COLOR_INTENT.primary }, void 0, false, {
        fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
        lineNumber: 60,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
      lineNumber: 58,
      columnNumber: 11
    }, this),
    footer
  ] }, void 0, true, {
    fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
    lineNumber: 45,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
    lineNumber: 44,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx",
    lineNumber: 43,
    columnNumber: 10
  }, this);
};
_c = ScTile;
export default ScTile;
var _c;
$RefreshReg$(_c, "ScTile");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/lbueno/Documents/manager/packages/react-super-components/src/lib/components/msc-tile/msc-tile.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
try {
    // @ts-ignore
    msctile.displayName = "msctile";
    // @ts-ignore
    msctile.__docgenInfo = { "description": "", "displayName": "msctile", "props": { "href": { "defaultValue": null, "description": "", "name": "href", "required": false, "type": { "name": "string" } }, "isExternalHref": { "defaultValue": null, "description": "", "name": "isExternalHref", "required": false, "type": { "name": "boolean" } }, "imgSrc": { "defaultValue": null, "description": "", "name": "imgSrc", "required": false, "type": { "name": "string" } }, "imgAlt": { "defaultValue": null, "description": "", "name": "imgAlt", "required": false, "type": { "name": "string" } }, "category": { "defaultValue": null, "description": "", "name": "category", "required": true, "type": { "name": "string" } }, "tileTitle": { "defaultValue": null, "description": "", "name": "tileTitle", "required": true, "type": { "name": "string" } }, "tileDescription": { "defaultValue": null, "description": "", "name": "tileDescription", "required": true, "type": { "name": "string" } }, "dataTracking": { "defaultValue": null, "description": "", "name": "dataTracking", "required": false, "type": { "name": "string" } }, "locale": { "defaultValue": null, "description": "", "name": "locale", "required": false, "type": { "name": "any" } }, "badges": { "defaultValue": null, "description": "", "name": "badges", "required": false, "type": { "name": "Badge[]" } }, "footer": { "defaultValue": null, "description": "", "name": "footer", "required": false, "type": { "name": "ReactElement<any, string | JSXElementConstructor<any>>" } } } };
}
catch (__react_docgen_typescript_loader_error) { }
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0RxQjtBQWhEckI7QUFBdUM7QUFBOEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVyRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQXFCQTtBQUFnQjtBQUNkQTtBQUNBQztBQUNBQztBQUNBQztBQUNBQztBQUNBQztBQUNBQztBQUNBQztBQUNBQztBQUVZO0FBQ1o7QUFBc0I7QUFBa0I7QUFDeEM7QUFDQTtBQUlTTDtBQUFVO0FBQUE7QUFBQTtBQUFBO0FBQW1FO0FBTzNFRDtBQUFBQTtBQUNxRDtBQUFBO0FBQUE7QUFBQTtBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFrRztBQVBwRztBQUFBO0FBQUE7QUFBQTtBQVFBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFPQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBT0E7QUFPR087QUFBZUM7QUFDaEI7QUFBQTtBQUFBO0FBQUE7QUFNd0M7QUFiMUM7QUFBQTtBQUFBO0FBQUE7QUFlQTtBQUNDQztBQTVDSDtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFtREo7QUFBQ0M7QUFFRDtBQUFxQjtBQUFBQyIsIm5hbWVzIjpbImhyZWYiLCJpc0V4dGVybmFsSHJlZiIsImNhdGVnb3J5IiwiaW1nU3JjIiwiaW1nQWx0IiwidGlsZURlc2NyaXB0aW9uIiwidGlsZVRpdGxlIiwiZGF0YVRyYWNraW5nIiwiYmFkZ2VzIiwibG9jYWxlU3RyaW5ncyIsInNlZV9tb3JlX2xhYmVsIiwiZm9vdGVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJtc2MtdGlsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgT0RTX1RIRU1FX0NPTE9SX0lOVEVOVCB9IGZyb20gJ0BvdmhjbG91ZC9vZHMtY29tbW9uLXRoZW1pbmcnXG4vLyBpbXBvcnQgeyBMb2NhbGUsIGRlZmF1bHRMb2NhbGUgfSBmcm9tICdAb3ZoY2xvdWQvbXNjLXV0aWxzJztcbmltcG9ydCB7IE9zZHNUZXh0IH0gZnJvbSAnQG92aGNsb3VkL29kcy1jb21wb25lbnRzL3RleHQvcmVhY3QnXG5pbXBvcnQgeyBPc2RzQ2hpcCB9IGZyb20gJ0BvdmhjbG91ZC9vZHMtY29tcG9uZW50cy9jaGlwL3JlYWN0J1xuaW1wb3J0IHsgT3Nkc1RpbGUgfSBmcm9tICdAb3ZoY2xvdWQvb2RzLWNvbXBvbmVudHMvdGlsZS9yZWFjdCdcbmltcG9ydCB7IE9zZHNMaW5rIH0gZnJvbSAnQG92aGNsb3VkL29kcy1jb21wb25lbnRzL2xpbmsvcmVhY3QnXG5pbXBvcnQgeyBPc2RzSWNvbiB9IGZyb20gJ0BvdmhjbG91ZC9vZHMtY29tcG9uZW50cy9pY29uL3JlYWN0J1xuXG5pbXBvcnQgeyBPRFNfSUNPTl9OQU1FLCBPRFNfSUNPTl9TSVpFIH0gZnJvbSAnQG92aGNsb3VkL29kcy1jb21wb25lbnRzL2ljb24nXG5pbXBvcnQgeyBPRFNfVEVYVF9MRVZFTCwgT0RTX1RFWFRfU0laRSB9IGZyb20gJ0BvdmhjbG91ZC9vZHMtY29tcG9uZW50cy90ZXh0J1xuXG5pbnRlcmZhY2UgQmFkZ2Uge1xuICB0ZXh0OiBzdHJpbmdcbiAgY29sb3I6IHN0cmluZ1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE1zY1RpbGVQcm9wcyB7XG4gIGhyZWY/OiBzdHJpbmdcbiAgaXNFeHRlcm5hbEhyZWY/OiBib29sZWFuXG4gIGltZ1NyYz86IHN0cmluZ1xuICBpbWdBbHQ/OiBzdHJpbmdcbiAgY2F0ZWdvcnk6IHN0cmluZ1xuICB0aWxlVGl0bGU6IHN0cmluZ1xuICB0aWxlRGVzY3JpcHRpb246IHN0cmluZ1xuICBkYXRhVHJhY2tpbmc/OiBzdHJpbmdcbiAgbG9jYWxlPzogYW55XG4gIGJhZGdlcz86IEJhZGdlW11cbiAgZm9vdGVyPzogUmVhY3QuUmVhY3RFbGVtZW50XG59XG5cbmNvbnN0IFNjVGlsZSA9ICh7XG4gIGhyZWYsXG4gIGlzRXh0ZXJuYWxIcmVmLFxuICBjYXRlZ29yeSxcbiAgaW1nU3JjLFxuICBpbWdBbHQsXG4gIHRpbGVEZXNjcmlwdGlvbixcbiAgdGlsZVRpdGxlLFxuICBkYXRhVHJhY2tpbmcsXG4gIGJhZGdlcyxcbiAgZm9vdGVyXG59OiBNc2NUaWxlUHJvcHMpID0+IHtcbiAgY29uc3QgbG9jYWxlU3RyaW5ncyA9IHsgc2VlX21vcmVfbGFiZWw6ICdTZWUgbW9yZScgfVxuICBjb25zdCBoYXNGb290ZXJDb250ZW50ID0gMFxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8T3Nkc1RpbGUgY2xhc3NOYW1lPVwibXNjLW9kcy10aWxlXCIgY29sb3I9e09EU19USEVNRV9DT0xPUl9JTlRFTlQucHJpbWFyeX0gcm91bmRlZCBpbmxpbmU+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgIHtpbWdTcmMgJiYgPGltZyBjbGFzc05hbWU9XCJtYXgtdy1mdWxsIG0tMyB3LTMyIGgtMzJcIiBzcmM9e2ltZ1NyY30gYWx0PXtpbWdBbHR9IC8+fVxuICAgICAgICAgIDxPc2RzVGV4dFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGlsZS10eXBlXCJcbiAgICAgICAgICAgIGxldmVsPXtPRFNfVEVYVF9MRVZFTC5oZWFkaW5nfVxuICAgICAgICAgICAgc2l6ZT17T0RTX1RFWFRfU0laRS5fMjAwfVxuICAgICAgICAgICAgY29sb3I9e09EU19USEVNRV9DT0xPUl9JTlRFTlQucHJpbWFyeX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7Y2F0ZWdvcnl9XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0aWxlLWJhZGdlLWxpc3RcIj57YmFkZ2VzPy5tYXAoKGIpID0+IDxPc2RzQ2hpcCBrZXk9e2IudGV4dH0+e2IudGV4dH08L09zZHNDaGlwPil9PC9zcGFuPlxuICAgICAgICAgIDwvT3Nkc1RleHQ+XG5cbiAgICAgICAgICA8T3Nkc1RleHRcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRpbGUtdGl0bGVcIlxuICAgICAgICAgICAgbGV2ZWw9e09EU19URVhUX0xFVkVMLmhlYWRpbmd9XG4gICAgICAgICAgICBzaXplPXtPRFNfVEVYVF9TSVpFLl80MDB9XG4gICAgICAgICAgICBjb2xvcj17T0RTX1RIRU1FX0NPTE9SX0lOVEVOVC50ZXh0fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt0aWxlVGl0bGV9XG4gICAgICAgICAgPC9Pc2RzVGV4dD5cbiAgICAgICAgICA8T3Nkc1RleHRcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRpbGUtZGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgbGV2ZWw9e09EU19URVhUX0xFVkVMLmJvZHl9XG4gICAgICAgICAgICBzaXplPXtPRFNfVEVYVF9TSVpFLl80MDB9XG4gICAgICAgICAgICBjb2xvcj17T0RTX1RIRU1FX0NPTE9SX0lOVEVOVC5kZWZhdWx0fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt0aWxlRGVzY3JpcHRpb259XG4gICAgICAgICAgPC9Pc2RzVGV4dD5cbiAgICAgICAgICA8T3Nkc0xpbmtcbiAgICAgICAgICAgIHRhYkluZGV4PXtoYXNGb290ZXJDb250ZW50ID8gMCA6IC0xfVxuICAgICAgICAgICAgZGF0YS10cmFja2luZz17ZGF0YVRyYWNraW5nfVxuICAgICAgICAgICAgY29sb3I9e09EU19USEVNRV9DT0xPUl9JTlRFTlQucHJpbWFyeX1cbiAgICAgICAgICAgIGhyZWY9e2hyZWZ9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2xvY2FsZVN0cmluZ3M/LnNlZV9tb3JlX2xhYmVsfVxuICAgICAgICAgICAgPE9zZHNJY29uXG4gICAgICAgICAgICAgIHNsb3Q9XCJlbmRcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJsaW5rLWljb25cIlxuICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgICBzaXplPXtPRFNfSUNPTl9TSVpFLnh4c31cbiAgICAgICAgICAgICAgbmFtZT17aXNFeHRlcm5hbEhyZWYgPyBPRFNfSUNPTl9OQU1FLkVYVEVSTkFMX0xJTksgOiBPRFNfSUNPTl9OQU1FLkFSUk9XX1JJR0hUfVxuICAgICAgICAgICAgICBjb2xvcj17T0RTX1RIRU1FX0NPTE9SX0lOVEVOVC5wcmltYXJ5fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L09zZHNMaW5rPlxuICAgICAgICAgIHtmb290ZXJ9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9Pc2RzVGlsZT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBTY1RpbGVcbiJdLCJmaWxlIjoiL1VzZXJzL2xidWVuby9Eb2N1bWVudHMvbWFuYWdlci9wYWNrYWdlcy9yZWFjdC1zdXBlci1jb21wb25lbnRzL3NyYy9saWIvY29tcG9uZW50cy9tc2MtdGlsZS9tc2MtdGlsZS50c3gifQ==