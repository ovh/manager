import {
  require_overArg
} from "/node_modules/.cache/sb-vite/deps/chunk-R7DWCQNX.js?v=25ee29f1";
import {
  __commonJS
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/lodash/_getPrototype.js
var require_getPrototype = __commonJS({
  "../../node_modules/lodash/_getPrototype.js"(exports, module) {
    var overArg = require_overArg();
    var getPrototype = overArg(Object.getPrototypeOf, Object);
    module.exports = getPrototype;
  }
});

export {
  require_getPrototype
};
//# sourceMappingURL=chunk-YYQ5MWTJ.js.map
