// node_modules/@storybook/addon-styling/dist/preview.mjs
var e = "theme";
var r = { globals: { [e]: "" } };
var a = r;

export {
  a
};
//# sourceMappingURL=chunk-V4OO36GZ.js.map
