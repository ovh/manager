import {
  H,
  Host,
  h,
  proxyCustomElement
} from "/node_modules/.cache/sb-vite/deps/chunk-QZD7DNHB.js?v=25ee29f1";
import {
  __rest
} from "/node_modules/.cache/sb-vite/deps/chunk-OHK2DJ23.js?v=25ee29f1";
import {
  require_react_dom
} from "/node_modules/.cache/sb-vite/deps/chunk-ZHCUIEE5.js?v=25ee29f1";
import {
  require_react
} from "/node_modules/.cache/sb-vite/deps/chunk-UXJYJ7WW.js?v=25ee29f1";
import {
  __toESM
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/@ovhcloud/ods-components/link/react/dist/esm/react-component-lib/createComponent.js
var import_react2 = __toESM(require_react());

// ../../node_modules/@ovhcloud/ods-components/link/react/dist/esm/react-component-lib/utils/index.js
var import_react = __toESM(require_react());

// ../../node_modules/@ovhcloud/ods-components/link/react/dist/esm/react-component-lib/utils/case.js
var dashToPascalCase = (str) => str.toLowerCase().split("-").map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1)).join("");
var camelToDashCase = (str) => str.replace(/([A-Z])/g, (m) => `-${m[0].toLowerCase()}`);

// ../../node_modules/@ovhcloud/ods-components/link/react/dist/esm/react-component-lib/utils/attachProps.js
var attachProps = (node, newProps, oldProps = {}) => {
  if (node instanceof Element) {
    const className = getClassName(node.classList, newProps, oldProps);
    if (className !== "") {
      node.className = className;
    }
    Object.keys(newProps).forEach((name) => {
      if (name === "children" || name === "style" || name === "ref" || name === "class" || name === "className" || name === "forwardedRef") {
        return;
      }
      if (name.indexOf("on") === 0 && name[2] === name[2].toUpperCase()) {
        const eventName = name.substring(2);
        const eventNameLc = eventName[0].toLowerCase() + eventName.substring(1);
        if (!isCoveredByReact(eventNameLc)) {
          syncEvent(node, eventNameLc, newProps[name]);
        }
      } else {
        node[name] = newProps[name];
        const propType = typeof newProps[name];
        if (propType === "string") {
          node.setAttribute(camelToDashCase(name), newProps[name]);
        }
      }
    });
  }
};
var getClassName = (classList, newProps, oldProps) => {
  const newClassProp = newProps.className || newProps.class;
  const oldClassProp = oldProps.className || oldProps.class;
  const currentClasses = arrayToMap(classList);
  const incomingPropClasses = arrayToMap(newClassProp ? newClassProp.split(" ") : []);
  const oldPropClasses = arrayToMap(oldClassProp ? oldClassProp.split(" ") : []);
  const finalClassNames = [];
  currentClasses.forEach((currentClass) => {
    if (incomingPropClasses.has(currentClass)) {
      finalClassNames.push(currentClass);
      incomingPropClasses.delete(currentClass);
    } else if (!oldPropClasses.has(currentClass)) {
      finalClassNames.push(currentClass);
    }
  });
  incomingPropClasses.forEach((s) => finalClassNames.push(s));
  return finalClassNames.join(" ");
};
var isCoveredByReact = (eventNameSuffix) => {
  if (typeof document === "undefined") {
    return true;
  } else {
    const eventName = "on" + eventNameSuffix;
    let isSupported = eventName in document;
    if (!isSupported) {
      const element = document.createElement("div");
      element.setAttribute(eventName, "return;");
      isSupported = typeof element[eventName] === "function";
    }
    return isSupported;
  }
};
var syncEvent = (node, eventName, newEventHandler) => {
  const eventStore = node.__events || (node.__events = {});
  const oldEventHandler = eventStore[eventName];
  if (oldEventHandler) {
    node.removeEventListener(eventName, oldEventHandler);
  }
  node.addEventListener(eventName, eventStore[eventName] = function handler(e) {
    if (newEventHandler) {
      newEventHandler.call(this, e);
    }
  });
};
var arrayToMap = (arr) => {
  const map = /* @__PURE__ */ new Map();
  arr.forEach((s) => map.set(s, s));
  return map;
};

// ../../node_modules/@ovhcloud/ods-components/link/react/dist/esm/react-component-lib/utils/index.js
var setRef = (ref, value) => {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref != null) {
    ref.current = value;
  }
};
var mergeRefs = (...refs) => {
  return (value) => {
    refs.forEach((ref) => {
      setRef(ref, value);
    });
  };
};
var createForwardRef = (ReactComponent, displayName) => {
  const forwardRef = (props, ref) => {
    return import_react.default.createElement(ReactComponent, Object.assign({}, props, { forwardedRef: ref }));
  };
  forwardRef.displayName = displayName;
  return import_react.default.forwardRef(forwardRef);
};

// ../../node_modules/@ovhcloud/ods-components/link/react/dist/esm/react-component-lib/createComponent.js
var createReactComponent = (tagName, ReactComponentContext, manipulatePropsFunction, defineCustomElement3) => {
  if (defineCustomElement3 !== void 0) {
    defineCustomElement3();
  }
  const displayName = dashToPascalCase(tagName);
  const ReactComponent = class extends import_react2.default.Component {
    constructor(props) {
      super(props);
      this.setComponentElRef = (element) => {
        this.componentEl = element;
      };
    }
    componentDidMount() {
      this.componentDidUpdate(this.props);
    }
    componentDidUpdate(prevProps) {
      attachProps(this.componentEl, this.props, prevProps);
    }
    render() {
      const _a = this.props, { children, forwardedRef, style, className, ref } = _a, cProps = __rest(_a, ["children", "forwardedRef", "style", "className", "ref"]);
      let propsToPass = Object.keys(cProps).reduce((acc, name) => {
        if (name.indexOf("on") === 0 && name[2] === name[2].toUpperCase()) {
          const eventName = name.substring(2).toLowerCase();
          if (typeof document !== "undefined" && isCoveredByReact(eventName)) {
            acc[name] = cProps[name];
          }
        } else {
          acc[name] = cProps[name];
        }
        return acc;
      }, {});
      if (manipulatePropsFunction) {
        propsToPass = manipulatePropsFunction(this.props, propsToPass);
      }
      const newProps = Object.assign(Object.assign({}, propsToPass), { ref: mergeRefs(forwardedRef, this.setComponentElRef), style });
      return (0, import_react2.createElement)(tagName, newProps, children);
    }
    static get displayName() {
      return displayName;
    }
  };
  if (ReactComponentContext) {
    ReactComponent.contextType = ReactComponentContext;
  }
  return createForwardRef(ReactComponent, displayName);
};

// ../../node_modules/@ovhcloud/ods-components/link/react/dist/esm/react-component-lib/createOverlayComponent.js
var import_react3 = __toESM(require_react());
var import_react_dom = __toESM(require_react_dom());

// ../../node_modules/@ovhcloud/ods-component-link/custom-elements/osds-link.js
var ODS_THEME_COLOR_HUE;
(function(ODS_THEME_COLOR_HUE2) {
  ODS_THEME_COLOR_HUE2["_000"] = "000";
  ODS_THEME_COLOR_HUE2["_050"] = "050";
  ODS_THEME_COLOR_HUE2["_075"] = "075";
  ODS_THEME_COLOR_HUE2["_100"] = "100";
  ODS_THEME_COLOR_HUE2["_200"] = "200";
  ODS_THEME_COLOR_HUE2["_300"] = "300";
  ODS_THEME_COLOR_HUE2["_400"] = "400";
  ODS_THEME_COLOR_HUE2["_500"] = "500";
  ODS_THEME_COLOR_HUE2["_600"] = "600";
  ODS_THEME_COLOR_HUE2["_700"] = "700";
  ODS_THEME_COLOR_HUE2["_800"] = "800";
  ODS_THEME_COLOR_HUE2["_900"] = "900";
  ODS_THEME_COLOR_HUE2["_1000"] = "1000";
})(ODS_THEME_COLOR_HUE || (ODS_THEME_COLOR_HUE = {}));
Object.freeze(Object.values(ODS_THEME_COLOR_HUE));
var ODS_THEME_COLOR_INTENT;
(function(ODS_THEME_COLOR_INTENT2) {
  ODS_THEME_COLOR_INTENT2["accent"] = "accent";
  ODS_THEME_COLOR_INTENT2["default"] = "default";
  ODS_THEME_COLOR_INTENT2["error"] = "error";
  ODS_THEME_COLOR_INTENT2["info"] = "info";
  ODS_THEME_COLOR_INTENT2["primary"] = "primary";
  ODS_THEME_COLOR_INTENT2["promotion"] = "promotion";
  ODS_THEME_COLOR_INTENT2["success"] = "success";
  ODS_THEME_COLOR_INTENT2["text"] = "text";
  ODS_THEME_COLOR_INTENT2["warning"] = "warning";
})(ODS_THEME_COLOR_INTENT || (ODS_THEME_COLOR_INTENT = {}));
Object.freeze(Object.values(ODS_THEME_COLOR_INTENT));
var ODS_THEME_SIZE;
(function(ODS_THEME_SIZE2) {
  ODS_THEME_SIZE2["_100"] = "100";
  ODS_THEME_SIZE2["_200"] = "200";
  ODS_THEME_SIZE2["_300"] = "300";
  ODS_THEME_SIZE2["_400"] = "400";
  ODS_THEME_SIZE2["_500"] = "500";
  ODS_THEME_SIZE2["_600"] = "600";
  ODS_THEME_SIZE2["_700"] = "700";
  ODS_THEME_SIZE2["_800"] = "800";
  ODS_THEME_SIZE2["_900"] = "900";
})(ODS_THEME_SIZE || (ODS_THEME_SIZE = {}));
Object.freeze(Object.values(ODS_THEME_SIZE));
var ODS_THEME_TYPOGRAPHY_LEVEL;
(function(ODS_THEME_TYPOGRAPHY_LEVEL2) {
  ODS_THEME_TYPOGRAPHY_LEVEL2["body"] = "body";
  ODS_THEME_TYPOGRAPHY_LEVEL2["button"] = "button";
  ODS_THEME_TYPOGRAPHY_LEVEL2["caption"] = "caption";
  ODS_THEME_TYPOGRAPHY_LEVEL2["heading"] = "heading";
  ODS_THEME_TYPOGRAPHY_LEVEL2["subheading"] = "subheading";
})(ODS_THEME_TYPOGRAPHY_LEVEL || (ODS_THEME_TYPOGRAPHY_LEVEL = {}));
Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_LEVEL));
var ODS_THEME_TYPOGRAPHY_SIZE;
(function(ODS_THEME_TYPOGRAPHY_SIZE2) {
  ODS_THEME_TYPOGRAPHY_SIZE2["_100"] = "100";
  ODS_THEME_TYPOGRAPHY_SIZE2["_200"] = "200";
  ODS_THEME_TYPOGRAPHY_SIZE2["_300"] = "300";
  ODS_THEME_TYPOGRAPHY_SIZE2["_400"] = "400";
  ODS_THEME_TYPOGRAPHY_SIZE2["_500"] = "500";
  ODS_THEME_TYPOGRAPHY_SIZE2["_600"] = "600";
  ODS_THEME_TYPOGRAPHY_SIZE2["_700"] = "700";
  ODS_THEME_TYPOGRAPHY_SIZE2["_800"] = "800";
})(ODS_THEME_TYPOGRAPHY_SIZE || (ODS_THEME_TYPOGRAPHY_SIZE = {}));
Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_SIZE));
var DEFAULT_ATTRIBUTE = Object.freeze({
  color: ODS_THEME_COLOR_INTENT.default,
  contrasted: false,
  disabled: false,
  download: void 0,
  href: void 0,
  referrerpolicy: void 0,
  rel: void 0,
  target: void 0,
  type: void 0
});
var odsDefaultConfig = {
  id: Date.now(),
  logging: {
    active: false,
    color: true
  },
  asset: {
    path: ""
  }
};
function getOdsWindow() {
  if (typeof window !== "undefined") {
    const win2 = window;
    win2.winId = win2.winId ? win2.winId : Date.now();
    return win2;
  }
  return void 0;
}
var OdsLogger = class {
  constructor(context, prefix) {
    this.id = Math.floor(Math.random() * 1e7);
    this.prefixColor = "color: white;background:#004fd6;font-weight: bold; font-size:10px; padding:2px 6px; border-radius: 5px 0px 0px 5px";
    this.contextColor = "color: black;background:#d4e0e7;font-weight: bold; font-size:10px; padding:2px 6px; border-radius: 0px 5px 5px 0px";
    this.prefix = "ODS";
    this.context = "";
    this.prefix = prefix ? prefix : this.prefix;
    this.context = context;
  }
  get log() {
    return this.getConsole("log");
  }
  get warn() {
    return this.getConsole("warn");
  }
  get error() {
    return this.getConsole("error");
  }
  get info() {
    return this.getConsole("info");
  }
  get debug() {
    return this.getConsole("debug");
  }
  get trace() {
    return this.getConsole("trace");
  }
  getConsole(method) {
    if (this.logging) {
      if (this.color) {
        return console[method].bind(null, `${this.prefix ? "%c" : "%s"}${this.prefix} %c${this.context}`, this.prefix ? this.prefixColor : "", this.contextColor);
      }
      return console[method].bind(null, `[${this.prefix}${this.prefix ? "|" : ""}${this.context}]`);
    } else {
      return () => {
      };
    }
  }
  get logging() {
    var _a, _b, _c;
    const win2 = getOdsWindow();
    const active = (_c = (_b = (_a = win2 === null || win2 === void 0 ? void 0 : win2.ods) === null || _a === void 0 ? void 0 : _a.config) === null || _b === void 0 ? void 0 : _b.logging) === null || _c === void 0 ? void 0 : _c.active;
    return active === void 0 ? odsDefaultConfig.logging.active : active;
  }
  get color() {
    var _a, _b, _c;
    const win2 = getOdsWindow();
    const color = (_c = (_b = (_a = win2 === null || win2 === void 0 ? void 0 : win2.ods) === null || _a === void 0 ? void 0 : _a.config) === null || _b === void 0 ? void 0 : _b.logging) === null || _c === void 0 ? void 0 : _c.color;
    return color === void 0 ? odsDefaultConfig.logging.color : color;
  }
};
var VERSION = "9.0.3";
var OdsExternalLogger = class extends OdsLogger {
  constructor(context, prefix) {
    super(context, prefix);
    this.prefixColor = "color: white;background:#403f3e;font-weight: bold; font-size:10px; padding:2px 6px; border-radius: 5px 0px 0px 5px";
    this.contextColor = "color: black;background:#d4e0e7;font-weight: bold; font-size:10px; padding:2px 6px; border-radius: 0px 5px 5px 0px";
    this.prefix = "CUSTOM";
  }
};
var Ods = class _Ods {
  constructor(config) {
    this.config = config;
    this.version = VERSION;
    this.genericLogger = new OdsLogger("ODS", "OVHcloud Design System");
    const winA = window;
    winA.gg = "winA";
    this.config = config;
    this.instanceId = _Ods._instanceId++;
    this.genericLogger.info("Hi! You are using OVHcloud Design System components, feel free to check out https://go/odsdoc/", {
      id: this.instanceId,
      version: this.version
    });
    const odsEvent = new CustomEvent("odsInitialized", {
      detail: {
        version: VERSION,
        instance: this,
        config
      },
      bubbles: true,
      cancelable: true,
      composed: false
    });
    document.dispatchEvent(odsEvent);
  }
  /**
   * @deprecated use `Ods.instance()`
   */
  static configure() {
    return this.instance();
  }
  /**
   * get or create the ODS instance.
   * The singleton is retrieved if exist
   */
  static instance(config = odsDefaultConfig) {
    var _a, _b;
    if (!this._instance) {
      const win2 = getOdsWindow();
      if (((_a = win2 === null || win2 === void 0 ? void 0 : win2.ods) === null || _a === void 0 ? void 0 : _a.versions) && ((_b = win2 === null || win2 === void 0 ? void 0 : win2.ods) === null || _b === void 0 ? void 0 : _b.versions[VERSION])) {
        this._instance = win2.ods.versions[VERSION];
      } else {
        this._instance = new _Ods(config);
      }
    }
    return this._instance;
  }
  /**
   * set your custom i18n callback function that is processing translations.
   * the callback has to return the translated string processed by your translation system.
   * @param hook - function that will receive the values to translate
   */
  i18n(hook) {
    this.i18nHook = hook;
    return this;
  }
  getI18n() {
    return this.i18nHook;
  }
  /**
   * set the default asset path where to find the different assets of `ODS`.
   * @param path - path like `my-ods-svg/`
   */
  assetPath(path) {
    this.config.asset.path = path;
    return this;
  }
  /**
   * get all the configuration of `ODS`
   */
  getConfig() {
    return this.config;
  }
  /**
   * enable or not the logging for the `ODS` instance
   * @param enable - your boolean
   */
  logging(enable) {
    this.config.logging.active = enable;
    return this;
  }
  isLoggingActive() {
    return this.config.logging.active;
  }
  get logger() {
    return OdsExternalLogger;
  }
};
Ods._instanceId = 0;
function initializeProperties(win2, baseConfig) {
  if (!win2.ods) {
    win2.ods = {
      setupId: Date.now(),
      // with our own object reference
      config: baseConfig
    };
  }
  if (!win2.ods.versions) {
    win2.ods.versions = {};
  }
  win2.ods.setupId = win2.ods.setupId || Date.now();
  return win2;
}
function applyLoggingConf(odsConf) {
  odsConf.logging = odsConf.logging || odsDefaultConfig.logging;
  const formatLogging = (odsConf2) => {
    var _a, _b;
    return {
      active: typeof ((_a = odsConf2 === null || odsConf2 === void 0 ? void 0 : odsConf2.logging) === null || _a === void 0 ? void 0 : _a.active) !== "boolean" ? odsDefaultConfig.logging.active : odsConf2.logging.active,
      color: typeof ((_b = odsConf2 === null || odsConf2 === void 0 ? void 0 : odsConf2.logging) === null || _b === void 0 ? void 0 : _b.color) !== "boolean" ? odsDefaultConfig.logging.color : odsConf2.logging.color
    };
  };
  const formatted = formatLogging(odsConf);
  odsConf.logging.active = formatted.active;
  odsConf.logging.color = formatted.color;
}
function applyAssetConf(odsConf) {
  odsConf.asset = odsConf.asset || odsDefaultConfig.asset;
  odsConf.asset.path = odsConf.asset.path ? odsConf.asset.path : odsDefaultConfig.asset.path;
}
function odsSetup() {
  const win2 = getOdsWindow();
  if (win2) {
    const configObjectRef = Object.assign(Object.assign({}, odsDefaultConfig), { id: Date.now() });
    const winFilled = initializeProperties(win2, configObjectRef);
    let config;
    const odsConf = winFilled.ods.config;
    if (odsConf) {
      applyLoggingConf(odsConf);
      applyAssetConf(odsConf);
      config = odsConf;
    } else {
      config = configObjectRef;
    }
    if (!winFilled.ods.versions[VERSION]) {
      winFilled.ods.versions[VERSION] = Ods.instance(config);
    }
    if (!winFilled.ods.latest || winFilled.ods.latest && VERSION > winFilled.ods.latest.version) {
      winFilled.ods.latest = winFilled.ods.versions[VERSION];
    }
  }
}
var win = getOdsWindow();
if (win)
  win.odsSetup = odsSetup;
var ODS_COUNTRY_ISO_CODE;
(function(ODS_COUNTRY_ISO_CODE2) {
  ODS_COUNTRY_ISO_CODE2["AR"] = "ar";
  ODS_COUNTRY_ISO_CODE2["AS"] = "as";
  ODS_COUNTRY_ISO_CODE2["AT"] = "at";
  ODS_COUNTRY_ISO_CODE2["AU"] = "au";
  ODS_COUNTRY_ISO_CODE2["AW"] = "aw";
  ODS_COUNTRY_ISO_CODE2["AX"] = "ax";
  ODS_COUNTRY_ISO_CODE2["AZ"] = "az";
  ODS_COUNTRY_ISO_CODE2["BA"] = "ba";
  ODS_COUNTRY_ISO_CODE2["BB"] = "bb";
  ODS_COUNTRY_ISO_CODE2["BD"] = "bd";
  ODS_COUNTRY_ISO_CODE2["BE"] = "be";
  ODS_COUNTRY_ISO_CODE2["BF"] = "bf";
  ODS_COUNTRY_ISO_CODE2["BG"] = "bg";
  ODS_COUNTRY_ISO_CODE2["BH"] = "bh";
  ODS_COUNTRY_ISO_CODE2["BI"] = "bi";
  ODS_COUNTRY_ISO_CODE2["BJ"] = "bj";
  ODS_COUNTRY_ISO_CODE2["BL"] = "bl";
  ODS_COUNTRY_ISO_CODE2["BM"] = "bm";
  ODS_COUNTRY_ISO_CODE2["BN"] = "bn";
  ODS_COUNTRY_ISO_CODE2["BO"] = "bo";
  ODS_COUNTRY_ISO_CODE2["BQ"] = "bq";
  ODS_COUNTRY_ISO_CODE2["BR"] = "br";
  ODS_COUNTRY_ISO_CODE2["BS"] = "bs";
  ODS_COUNTRY_ISO_CODE2["BT"] = "bt";
  ODS_COUNTRY_ISO_CODE2["BW"] = "bw";
  ODS_COUNTRY_ISO_CODE2["BY"] = "by";
  ODS_COUNTRY_ISO_CODE2["BZ"] = "bz";
  ODS_COUNTRY_ISO_CODE2["CA"] = "ca";
  ODS_COUNTRY_ISO_CODE2["CC"] = "cc";
  ODS_COUNTRY_ISO_CODE2["CD"] = "cd";
  ODS_COUNTRY_ISO_CODE2["CF"] = "cf";
  ODS_COUNTRY_ISO_CODE2["CG"] = "cg";
  ODS_COUNTRY_ISO_CODE2["CH"] = "ch";
  ODS_COUNTRY_ISO_CODE2["CI"] = "ci";
  ODS_COUNTRY_ISO_CODE2["CK"] = "ck";
  ODS_COUNTRY_ISO_CODE2["CL"] = "cl";
  ODS_COUNTRY_ISO_CODE2["CM"] = "cm";
  ODS_COUNTRY_ISO_CODE2["CN"] = "cn";
  ODS_COUNTRY_ISO_CODE2["CO"] = "co";
  ODS_COUNTRY_ISO_CODE2["CR"] = "cr";
  ODS_COUNTRY_ISO_CODE2["CU"] = "cu";
  ODS_COUNTRY_ISO_CODE2["CV"] = "cv";
  ODS_COUNTRY_ISO_CODE2["CW"] = "cw";
  ODS_COUNTRY_ISO_CODE2["CX"] = "cx";
  ODS_COUNTRY_ISO_CODE2["CY"] = "cy";
  ODS_COUNTRY_ISO_CODE2["CZ"] = "cz";
  ODS_COUNTRY_ISO_CODE2["DE"] = "de";
  ODS_COUNTRY_ISO_CODE2["DJ"] = "dj";
  ODS_COUNTRY_ISO_CODE2["DK"] = "dk";
  ODS_COUNTRY_ISO_CODE2["DM"] = "dm";
  ODS_COUNTRY_ISO_CODE2["DO"] = "do";
  ODS_COUNTRY_ISO_CODE2["DZ"] = "dz";
  ODS_COUNTRY_ISO_CODE2["EC"] = "ec";
  ODS_COUNTRY_ISO_CODE2["EE"] = "ee";
  ODS_COUNTRY_ISO_CODE2["EG"] = "eg";
  ODS_COUNTRY_ISO_CODE2["EH"] = "eh";
  ODS_COUNTRY_ISO_CODE2["ER"] = "er";
  ODS_COUNTRY_ISO_CODE2["ES"] = "es";
  ODS_COUNTRY_ISO_CODE2["ET"] = "et";
  ODS_COUNTRY_ISO_CODE2["EU"] = "eu";
  ODS_COUNTRY_ISO_CODE2["FI"] = "fi";
  ODS_COUNTRY_ISO_CODE2["FJ"] = "fj";
  ODS_COUNTRY_ISO_CODE2["FK"] = "fk";
  ODS_COUNTRY_ISO_CODE2["FM"] = "fm";
  ODS_COUNTRY_ISO_CODE2["FO"] = "fo";
  ODS_COUNTRY_ISO_CODE2["FR"] = "fr";
  ODS_COUNTRY_ISO_CODE2["GA"] = "ga";
  ODS_COUNTRY_ISO_CODE2["GB"] = "gb";
  ODS_COUNTRY_ISO_CODE2["GD"] = "gd";
  ODS_COUNTRY_ISO_CODE2["GE"] = "ge";
  ODS_COUNTRY_ISO_CODE2["GF"] = "gf";
  ODS_COUNTRY_ISO_CODE2["GG"] = "gg";
  ODS_COUNTRY_ISO_CODE2["GH"] = "gh";
  ODS_COUNTRY_ISO_CODE2["GI"] = "gi";
  ODS_COUNTRY_ISO_CODE2["GL"] = "gl";
  ODS_COUNTRY_ISO_CODE2["GM"] = "gm";
  ODS_COUNTRY_ISO_CODE2["GN"] = "gn";
  ODS_COUNTRY_ISO_CODE2["GP"] = "gp";
  ODS_COUNTRY_ISO_CODE2["GQ"] = "gq";
  ODS_COUNTRY_ISO_CODE2["GR"] = "gr";
  ODS_COUNTRY_ISO_CODE2["GS"] = "gs";
  ODS_COUNTRY_ISO_CODE2["GT"] = "gt";
  ODS_COUNTRY_ISO_CODE2["GU"] = "gu";
  ODS_COUNTRY_ISO_CODE2["GW"] = "gw";
  ODS_COUNTRY_ISO_CODE2["GY"] = "gy";
  ODS_COUNTRY_ISO_CODE2["HK"] = "hk";
  ODS_COUNTRY_ISO_CODE2["HN"] = "hn";
  ODS_COUNTRY_ISO_CODE2["HR"] = "hr";
  ODS_COUNTRY_ISO_CODE2["HT"] = "ht";
  ODS_COUNTRY_ISO_CODE2["HU"] = "hu";
  ODS_COUNTRY_ISO_CODE2["ID"] = "id";
  ODS_COUNTRY_ISO_CODE2["IE"] = "ie";
  ODS_COUNTRY_ISO_CODE2["IL"] = "il";
  ODS_COUNTRY_ISO_CODE2["IM"] = "im";
  ODS_COUNTRY_ISO_CODE2["IN"] = "in";
  ODS_COUNTRY_ISO_CODE2["IO"] = "io";
  ODS_COUNTRY_ISO_CODE2["IQ"] = "iq";
  ODS_COUNTRY_ISO_CODE2["IR"] = "ir";
  ODS_COUNTRY_ISO_CODE2["IS"] = "is";
  ODS_COUNTRY_ISO_CODE2["IT"] = "it";
  ODS_COUNTRY_ISO_CODE2["JE"] = "je";
  ODS_COUNTRY_ISO_CODE2["JM"] = "jm";
  ODS_COUNTRY_ISO_CODE2["JO"] = "jo";
  ODS_COUNTRY_ISO_CODE2["JP"] = "jp";
  ODS_COUNTRY_ISO_CODE2["KE"] = "ke";
  ODS_COUNTRY_ISO_CODE2["KN"] = "kn";
  ODS_COUNTRY_ISO_CODE2["KP"] = "kp";
  ODS_COUNTRY_ISO_CODE2["KR"] = "kr";
  ODS_COUNTRY_ISO_CODE2["KW"] = "kw";
  ODS_COUNTRY_ISO_CODE2["KY"] = "ky";
  ODS_COUNTRY_ISO_CODE2["KZ"] = "kz";
  ODS_COUNTRY_ISO_CODE2["LA"] = "la";
  ODS_COUNTRY_ISO_CODE2["LB"] = "lb";
  ODS_COUNTRY_ISO_CODE2["LC"] = "lc";
  ODS_COUNTRY_ISO_CODE2["LI"] = "li";
  ODS_COUNTRY_ISO_CODE2["LR"] = "lr";
  ODS_COUNTRY_ISO_CODE2["LS"] = "ls";
  ODS_COUNTRY_ISO_CODE2["LT"] = "lt";
  ODS_COUNTRY_ISO_CODE2["LU"] = "lu";
  ODS_COUNTRY_ISO_CODE2["LV"] = "lv";
  ODS_COUNTRY_ISO_CODE2["LY"] = "ly";
  ODS_COUNTRY_ISO_CODE2["MA"] = "ma";
  ODS_COUNTRY_ISO_CODE2["MC"] = "mc";
  ODS_COUNTRY_ISO_CODE2["MD"] = "md";
  ODS_COUNTRY_ISO_CODE2["ME"] = "me";
  ODS_COUNTRY_ISO_CODE2["MF"] = "mf";
  ODS_COUNTRY_ISO_CODE2["MG"] = "mg";
  ODS_COUNTRY_ISO_CODE2["MH"] = "mh";
  ODS_COUNTRY_ISO_CODE2["MK"] = "mk";
  ODS_COUNTRY_ISO_CODE2["ML"] = "ml";
  ODS_COUNTRY_ISO_CODE2["MM"] = "mm";
  ODS_COUNTRY_ISO_CODE2["MN"] = "mn";
  ODS_COUNTRY_ISO_CODE2["MO"] = "mo";
  ODS_COUNTRY_ISO_CODE2["MP"] = "mp";
  ODS_COUNTRY_ISO_CODE2["MQ"] = "mq";
  ODS_COUNTRY_ISO_CODE2["MR"] = "mr";
  ODS_COUNTRY_ISO_CODE2["MS"] = "ms";
  ODS_COUNTRY_ISO_CODE2["MT"] = "mt";
  ODS_COUNTRY_ISO_CODE2["MU"] = "mu";
  ODS_COUNTRY_ISO_CODE2["MV"] = "mv";
  ODS_COUNTRY_ISO_CODE2["MW"] = "mw";
  ODS_COUNTRY_ISO_CODE2["MX"] = "mx";
  ODS_COUNTRY_ISO_CODE2["MY"] = "my";
  ODS_COUNTRY_ISO_CODE2["MZ"] = "mz";
  ODS_COUNTRY_ISO_CODE2["NA"] = "na";
  ODS_COUNTRY_ISO_CODE2["NC"] = "nc";
  ODS_COUNTRY_ISO_CODE2["NE"] = "ne";
  ODS_COUNTRY_ISO_CODE2["NF"] = "nf";
  ODS_COUNTRY_ISO_CODE2["NG"] = "ng";
  ODS_COUNTRY_ISO_CODE2["NI"] = "ni";
  ODS_COUNTRY_ISO_CODE2["NL"] = "nl";
  ODS_COUNTRY_ISO_CODE2["NO"] = "no";
  ODS_COUNTRY_ISO_CODE2["NP"] = "np";
  ODS_COUNTRY_ISO_CODE2["NR"] = "nr";
  ODS_COUNTRY_ISO_CODE2["NU"] = "nu";
  ODS_COUNTRY_ISO_CODE2["NZ"] = "nz";
  ODS_COUNTRY_ISO_CODE2["OM"] = "om";
  ODS_COUNTRY_ISO_CODE2["PA"] = "pa";
  ODS_COUNTRY_ISO_CODE2["PF"] = "pf";
  ODS_COUNTRY_ISO_CODE2["PG"] = "pg";
  ODS_COUNTRY_ISO_CODE2["PH"] = "ph";
  ODS_COUNTRY_ISO_CODE2["PK"] = "pk";
  ODS_COUNTRY_ISO_CODE2["PL"] = "pl";
  ODS_COUNTRY_ISO_CODE2["PM"] = "pm";
  ODS_COUNTRY_ISO_CODE2["PN"] = "pn";
  ODS_COUNTRY_ISO_CODE2["PR"] = "pr";
  ODS_COUNTRY_ISO_CODE2["PS"] = "ps";
  ODS_COUNTRY_ISO_CODE2["PT"] = "pt";
  ODS_COUNTRY_ISO_CODE2["PW"] = "pw";
  ODS_COUNTRY_ISO_CODE2["PY"] = "py";
  ODS_COUNTRY_ISO_CODE2["QA"] = "qa";
  ODS_COUNTRY_ISO_CODE2["RE"] = "re";
  ODS_COUNTRY_ISO_CODE2["RO"] = "ro";
  ODS_COUNTRY_ISO_CODE2["RS"] = "rs";
  ODS_COUNTRY_ISO_CODE2["RU"] = "ru";
  ODS_COUNTRY_ISO_CODE2["RW"] = "rw";
  ODS_COUNTRY_ISO_CODE2["SA"] = "sa";
  ODS_COUNTRY_ISO_CODE2["SB"] = "sb";
  ODS_COUNTRY_ISO_CODE2["SC"] = "sc";
  ODS_COUNTRY_ISO_CODE2["SD"] = "sd";
  ODS_COUNTRY_ISO_CODE2["SE"] = "se";
  ODS_COUNTRY_ISO_CODE2["SG"] = "sg";
  ODS_COUNTRY_ISO_CODE2["SH"] = "sh";
  ODS_COUNTRY_ISO_CODE2["SI"] = "si";
  ODS_COUNTRY_ISO_CODE2["SJ"] = "sj";
  ODS_COUNTRY_ISO_CODE2["SK"] = "sk";
  ODS_COUNTRY_ISO_CODE2["SL"] = "sl";
  ODS_COUNTRY_ISO_CODE2["SM"] = "sm";
  ODS_COUNTRY_ISO_CODE2["SN"] = "sn";
  ODS_COUNTRY_ISO_CODE2["SO"] = "so";
  ODS_COUNTRY_ISO_CODE2["SR"] = "sr";
  ODS_COUNTRY_ISO_CODE2["SS"] = "ss";
  ODS_COUNTRY_ISO_CODE2["ST"] = "st";
  ODS_COUNTRY_ISO_CODE2["SV"] = "sv";
  ODS_COUNTRY_ISO_CODE2["SX"] = "sx";
  ODS_COUNTRY_ISO_CODE2["SY"] = "sy";
  ODS_COUNTRY_ISO_CODE2["SZ"] = "sz";
  ODS_COUNTRY_ISO_CODE2["TC"] = "tc";
  ODS_COUNTRY_ISO_CODE2["TD"] = "td";
  ODS_COUNTRY_ISO_CODE2["TF"] = "tf";
  ODS_COUNTRY_ISO_CODE2["TG"] = "tg";
  ODS_COUNTRY_ISO_CODE2["TH"] = "th";
  ODS_COUNTRY_ISO_CODE2["TJ"] = "tj";
  ODS_COUNTRY_ISO_CODE2["TK"] = "tk";
  ODS_COUNTRY_ISO_CODE2["TL"] = "tl";
  ODS_COUNTRY_ISO_CODE2["TM"] = "tm";
  ODS_COUNTRY_ISO_CODE2["TN"] = "tn";
  ODS_COUNTRY_ISO_CODE2["TO"] = "to";
  ODS_COUNTRY_ISO_CODE2["TR"] = "tr";
  ODS_COUNTRY_ISO_CODE2["TT"] = "tt";
  ODS_COUNTRY_ISO_CODE2["TV"] = "tv";
  ODS_COUNTRY_ISO_CODE2["TW"] = "tw";
  ODS_COUNTRY_ISO_CODE2["TZ"] = "tz";
  ODS_COUNTRY_ISO_CODE2["UA"] = "ua";
  ODS_COUNTRY_ISO_CODE2["UG"] = "ug";
  ODS_COUNTRY_ISO_CODE2["UM"] = "um";
  ODS_COUNTRY_ISO_CODE2["UN"] = "un";
  ODS_COUNTRY_ISO_CODE2["UNIA"] = "unia";
  ODS_COUNTRY_ISO_CODE2["US"] = "us";
  ODS_COUNTRY_ISO_CODE2["UY"] = "uy";
  ODS_COUNTRY_ISO_CODE2["UZ"] = "uz";
  ODS_COUNTRY_ISO_CODE2["VA"] = "va";
  ODS_COUNTRY_ISO_CODE2["VC"] = "vc";
  ODS_COUNTRY_ISO_CODE2["VE"] = "ve";
  ODS_COUNTRY_ISO_CODE2["VG"] = "vg";
  ODS_COUNTRY_ISO_CODE2["VI"] = "vi";
  ODS_COUNTRY_ISO_CODE2["VN"] = "vn";
  ODS_COUNTRY_ISO_CODE2["VU"] = "vu";
  ODS_COUNTRY_ISO_CODE2["WF"] = "wf";
  ODS_COUNTRY_ISO_CODE2["WS"] = "ws";
  ODS_COUNTRY_ISO_CODE2["XK"] = "xk";
  ODS_COUNTRY_ISO_CODE2["YE"] = "ye";
  ODS_COUNTRY_ISO_CODE2["YT"] = "yt";
  ODS_COUNTRY_ISO_CODE2["ZA"] = "za";
  ODS_COUNTRY_ISO_CODE2["ZM"] = "zm";
})(ODS_COUNTRY_ISO_CODE || (ODS_COUNTRY_ISO_CODE = {}));
Object.keys(ODS_COUNTRY_ISO_CODE).map((key) => ODS_COUNTRY_ISO_CODE[key]);
function odsIsTermInEnum(term, set) {
  return Object.values(set).includes(term);
}
function OdsWarnComponentEnumAttribute(params) {
  if (!odsIsTermInEnum(params.attribute, params.attributeValues)) {
    params.logger.warn(`The ${params.attributeName} attribute must have a value from [${Object.values(params.attributeValues).join(", ")}]`);
  }
}
function OdsWarnComponentRangeAttribute(params) {
  if (params.attribute && (params.attribute > params.max || params.attribute < params.min)) {
    params.logger.warn(`The value attribute must be in bounds of [${[params.min, params.max].join(", ")}]`);
  }
}
function OdsWarnComponentAttribute(params, required = false) {
  if (required && !params.attribute) {
    return params.logger.warn(`Attribute ${params.attributeName} is required.`);
  }
  if (typeof params.attribute === "number") {
    return OdsWarnComponentRangeAttribute(params);
  }
  return OdsWarnComponentEnumAttribute(params);
}
var OlesIpsumGeneration;
(function(OlesIpsumGeneration2) {
  OlesIpsumGeneration2["paragraphs"] = "paragraphs";
  OlesIpsumGeneration2["sentences"] = "sentences";
  OlesIpsumGeneration2["words"] = "words";
})(OlesIpsumGeneration || (OlesIpsumGeneration = {}));
Object.keys(OlesIpsumGeneration).map((key) => OlesIpsumGeneration[key]);
var OdsHTMLAnchorElementRel;
(function(OdsHTMLAnchorElementRel2) {
  OdsHTMLAnchorElementRel2["alternate"] = "alternate";
  OdsHTMLAnchorElementRel2["author"] = "author";
  OdsHTMLAnchorElementRel2["bookmark"] = "bookmark";
  OdsHTMLAnchorElementRel2["external"] = "external";
  OdsHTMLAnchorElementRel2["help"] = "help";
  OdsHTMLAnchorElementRel2["license"] = "license";
  OdsHTMLAnchorElementRel2["me"] = "me";
  OdsHTMLAnchorElementRel2["next"] = "next";
  OdsHTMLAnchorElementRel2["nofollow"] = "nofollow";
  OdsHTMLAnchorElementRel2["noopener"] = "noopener";
  OdsHTMLAnchorElementRel2["noreferrer"] = "noreferrer";
  OdsHTMLAnchorElementRel2["opener"] = "opener";
  OdsHTMLAnchorElementRel2["prev"] = "prev";
  OdsHTMLAnchorElementRel2["search"] = "search";
  OdsHTMLAnchorElementRel2["tag"] = "tag";
})(OdsHTMLAnchorElementRel || (OdsHTMLAnchorElementRel = {}));
Object.keys(OdsHTMLAnchorElementRel).map((key) => OdsHTMLAnchorElementRel[key]);
var OdsHTMLAnchorElementTarget;
(function(OdsHTMLAnchorElementTarget2) {
  OdsHTMLAnchorElementTarget2["_blank"] = "_blank";
  OdsHTMLAnchorElementTarget2["_self"] = "_self";
  OdsHTMLAnchorElementTarget2["_parent"] = "_parent";
  OdsHTMLAnchorElementTarget2["_top"] = "_top";
})(OdsHTMLAnchorElementTarget || (OdsHTMLAnchorElementTarget = {}));
Object.keys(OdsHTMLAnchorElementTarget).map((key) => OdsHTMLAnchorElementTarget[key]);
var OdsLinkController = class {
  constructor(component) {
    this.logger = new OdsLogger("OdsLinkController");
    this.component = component;
  }
  /**
   * validating that the color and the target have correct values
   * and warn the user if not
   */
  validateAttributes() {
    const logger = this.logger;
    OdsWarnComponentAttribute({
      logger,
      attributeValues: ODS_THEME_COLOR_INTENT,
      attributeName: "color",
      attribute: this.component.color
    });
    if (this.component.href && !this.component.target) {
      this.component.target = OdsHTMLAnchorElementTarget._self;
    }
    this.component.href && OdsWarnComponentAttribute({
      logger,
      attributeValues: OdsHTMLAnchorElementTarget,
      attributeName: "target",
      attribute: this.component.target
    });
  }
};
var osdsLinkCss = ':host{display:inline-flex}:host .link{cursor:pointer;text-decoration:none;outline:none;-webkit-user-select:auto;-moz-user-select:auto;user-select:auto}:host .link__centered-text{background-position:0 100%;background-repeat:no-repeat;background-size:0 var(--ods-size-02);transition:background-size 0.2s ease-in, color ease-in-out 0.1s}::slotted([slot=start]),::slotted([slot=end]){display:inline-flex;align-self:center}:host(:not([href])) .link,:host([href=""]) .link{-webkit-appearance:none;-moz-appearance:none;appearance:none;border:none;padding:0;text-align:inherit}:host(:not([disabled]):hover) .link__centered-text,:host(:not([disabled]):focus) .link__centered-text{background-size:100% var(--ods-size-02);transition:background-size 0.2s ease-out}:host(:not([disabled]):focus){outline-style:dotted;outline-width:var(--ods-size-inset-02);outline-offset:var(--ods-size-inset-03)}:host(:not([disabled]):focus) .link__centered-text{outline:none}:active .link__centered-text{transition:color ease-in-out 0s}:host([disabled]){cursor:not-allowed;opacity:0.5}:host([disabled]) .link{pointer-events:none}:host .link__centered-text{background-image:linear-gradient(currentColor, currentColor)}:host(:not([href])) .link,:host([href=""]) .link{background-color:transparent}:host(:not([color])) .link{color:var(--ods-color-default-500)}:host([color^=default]) .link{color:var(--ods-color-default-500)}:host([color^=primary]) .link{color:var(--ods-color-primary-500)}:host([color^=text]) .link{color:var(--ods-color-text-500)}:host([color^=accent]) .link{color:var(--ods-color-accent-500)}:host([color^=error]) .link{color:var(--ods-color-error-500)}:host([color^=warning]) .link{color:var(--ods-color-warning-500)}:host([color^=success]) .link{color:var(--ods-color-success-500)}:host([color^=info]) .link{color:var(--ods-color-info-500)}:host([color^=promotion]) .link{color:var(--ods-color-promotion-500)}:host(:not([color]):hover) .link,:host(:not([color]):focus) .link{color:var(--ods-color-default-700)}:host([color^=default]:hover) .link,:host([color^=default]:focus) .link{color:var(--ods-color-default-700)}:host([color^=primary]:hover) .link,:host([color^=primary]:focus) .link{color:var(--ods-color-primary-700)}:host([color^=text]:hover) .link,:host([color^=text]:focus) .link{color:var(--ods-color-text-700)}:host([color^=accent]:hover) .link,:host([color^=accent]:focus) .link{color:var(--ods-color-accent-700)}:host([color^=error]:hover) .link,:host([color^=error]:focus) .link{color:var(--ods-color-error-700)}:host([color^=warning]:hover) .link,:host([color^=warning]:focus) .link{color:var(--ods-color-warning-700)}:host([color^=success]:hover) .link,:host([color^=success]:focus) .link{color:var(--ods-color-success-700)}:host([color^=info]:hover) .link,:host([color^=info]:focus) .link{color:var(--ods-color-info-700)}:host([color^=promotion]:hover) .link,:host([color^=promotion]:focus) .link{color:var(--ods-color-promotion-700)}:host(:not([color]):active) .link{color:var(--ods-color-default-800)}:host([color^=default]:active) .link{color:var(--ods-color-default-800)}:host([color^=primary]:active) .link{color:var(--ods-color-primary-800)}:host([color^=text]:active) .link{color:var(--ods-color-text-800)}:host([color^=accent]:active) .link{color:var(--ods-color-accent-800)}:host([color^=error]:active) .link{color:var(--ods-color-error-800)}:host([color^=warning]:active) .link{color:var(--ods-color-warning-800)}:host([color^=success]:active) .link{color:var(--ods-color-success-800)}:host([color^=info]:active) .link{color:var(--ods-color-info-800)}:host([color^=promotion]:active) .link{color:var(--ods-color-promotion-800)}:host([contrasted]:not([color])) .link{color:var(--ods-color-default-500-contrasted)}:host([contrasted][color^=default]) .link{color:var(--ods-color-default-500-contrasted)}:host([contrasted][color^=primary]) .link{color:var(--ods-color-primary-500-contrasted)}:host([contrasted][color^=text]) .link{color:var(--ods-color-text-500-contrasted)}:host([contrasted][color^=accent]) .link{color:var(--ods-color-accent-500-contrasted)}:host([contrasted][color^=error]) .link{color:var(--ods-color-error-500-contrasted)}:host([contrasted][color^=warning]) .link{color:var(--ods-color-warning-500-contrasted)}:host([contrasted][color^=success]) .link{color:var(--ods-color-success-500-contrasted)}:host([contrasted][color^=info]) .link{color:var(--ods-color-info-500-contrasted)}:host([contrasted][color^=promotion]) .link{color:var(--ods-color-promotion-500-contrasted)}:host .link__text-container{font-family:var(--ods-typography-body-500-font-family);font-size:var(--ods-typography-body-500-font-size);font-style:var(--ods-typography-body-500-font-style);font-weight:var(--ods-typography-body-500-font-weight);letter-spacing:var(--ods-typography-body-500-letter-spacing);line-height:var(--ods-typography-body-500-line-height)}:host .link__text-container{display:inline-flex;align-items:baseline}';
var OsdsLink$1 = proxyCustomElement(class extends H {
  constructor() {
    super();
    this.__registerHost();
    this.__attachShadow();
    this.controller = new OdsLinkController(this);
    this.color = DEFAULT_ATTRIBUTE.color;
    this.contrasted = DEFAULT_ATTRIBUTE.contrasted;
    this.disabled = DEFAULT_ATTRIBUTE.disabled;
    this.download = DEFAULT_ATTRIBUTE.download;
    this.href = DEFAULT_ATTRIBUTE.href;
    this.referrerpolicy = DEFAULT_ATTRIBUTE.referrerpolicy;
    this.rel = DEFAULT_ATTRIBUTE.rel;
    this.target = DEFAULT_ATTRIBUTE.target;
    this.type = DEFAULT_ATTRIBUTE.type;
  }
  /**
   * @see OdsLinkBehavior.beforeRender
   */
  beforeRender() {
    this.controller.validateAttributes();
  }
  componentWillRender() {
    this.beforeRender();
  }
  render() {
    const { download, href, referrerpolicy, rel, target, type } = this;
    const content = h("span", { class: "link__text-container" }, h("slot", { name: "start" }), h("span", { class: "link__centered-text" }, h("slot", null)), h("slot", { name: "end" }));
    let template;
    if (href) {
      template = h("a", Object.assign({}, {
        class: "link",
        part: "link",
        download,
        href,
        referrerpolicy,
        rel,
        tabindex: this.disabled ? -1 : 0,
        target,
        type
      }), content);
    } else {
      template = h("button", Object.assign({}, {
        class: "link",
        disabled: this.disabled,
        part: "link",
        tabindex: this.disabled ? -1 : 0
      }), content);
    }
    return h(Host, null, template);
  }
  get host() {
    return this;
  }
  static get style() {
    return osdsLinkCss;
  }
}, [1, "osds-link", {
  "color": [513],
  "contrasted": [516],
  "disabled": [516],
  "download": [1],
  "href": [513],
  "referrerpolicy": [513],
  "rel": [513],
  "target": [1537],
  "type": [513]
}]);
function defineCustomElement$1() {
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["osds-link"];
  components.forEach((tagName) => {
    switch (tagName) {
      case "osds-link":
        if (!customElements.get(tagName)) {
          customElements.define(tagName, OsdsLink$1);
        }
        break;
    }
  });
}
var defineCustomElement2 = defineCustomElement$1;

// ../../node_modules/@ovhcloud/ods-components/link/react/dist/esm/index.js
var OsdsLink = createReactComponent("osds-link", void 0, void 0, defineCustomElement2);
export {
  OsdsLink
};
/*! Bundled license information:

@ovhcloud/ods-components/link/react/dist/esm/react-component-lib/utils/attachProps.js:
  (**
   * Checks if an event is supported in the current execution environment.
   * @license Modernizr 3.0.0pre (Custom Build) | MIT
   *)
*/
//# sourceMappingURL=@ovhcloud_ods-components_link_react.js.map
