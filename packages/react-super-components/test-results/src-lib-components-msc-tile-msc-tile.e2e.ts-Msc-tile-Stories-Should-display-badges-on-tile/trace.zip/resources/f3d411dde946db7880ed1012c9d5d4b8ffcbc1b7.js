import {
  H,
  Host,
  h,
  proxyCustomElement
} from "/node_modules/.cache/sb-vite/deps/chunk-QZD7DNHB.js?v=25ee29f1";
import {
  __rest
} from "/node_modules/.cache/sb-vite/deps/chunk-OHK2DJ23.js?v=25ee29f1";
import {
  require_react_dom
} from "/node_modules/.cache/sb-vite/deps/chunk-ZHCUIEE5.js?v=25ee29f1";
import {
  require_react
} from "/node_modules/.cache/sb-vite/deps/chunk-UXJYJ7WW.js?v=25ee29f1";
import {
  __toESM
} from "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/@ovhcloud/ods-components/text/react/dist/esm/react-component-lib/createComponent.js
var import_react2 = __toESM(require_react());

// ../../node_modules/@ovhcloud/ods-components/text/react/dist/esm/react-component-lib/utils/index.js
var import_react = __toESM(require_react());

// ../../node_modules/@ovhcloud/ods-components/text/react/dist/esm/react-component-lib/utils/case.js
var dashToPascalCase = (str) => str.toLowerCase().split("-").map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1)).join("");
var camelToDashCase = (str) => str.replace(/([A-Z])/g, (m) => `-${m[0].toLowerCase()}`);

// ../../node_modules/@ovhcloud/ods-components/text/react/dist/esm/react-component-lib/utils/attachProps.js
var attachProps = (node, newProps, oldProps = {}) => {
  if (node instanceof Element) {
    const className = getClassName(node.classList, newProps, oldProps);
    if (className !== "") {
      node.className = className;
    }
    Object.keys(newProps).forEach((name) => {
      if (name === "children" || name === "style" || name === "ref" || name === "class" || name === "className" || name === "forwardedRef") {
        return;
      }
      if (name.indexOf("on") === 0 && name[2] === name[2].toUpperCase()) {
        const eventName = name.substring(2);
        const eventNameLc = eventName[0].toLowerCase() + eventName.substring(1);
        if (!isCoveredByReact(eventNameLc)) {
          syncEvent(node, eventNameLc, newProps[name]);
        }
      } else {
        node[name] = newProps[name];
        const propType = typeof newProps[name];
        if (propType === "string") {
          node.setAttribute(camelToDashCase(name), newProps[name]);
        }
      }
    });
  }
};
var getClassName = (classList, newProps, oldProps) => {
  const newClassProp = newProps.className || newProps.class;
  const oldClassProp = oldProps.className || oldProps.class;
  const currentClasses = arrayToMap(classList);
  const incomingPropClasses = arrayToMap(newClassProp ? newClassProp.split(" ") : []);
  const oldPropClasses = arrayToMap(oldClassProp ? oldClassProp.split(" ") : []);
  const finalClassNames = [];
  currentClasses.forEach((currentClass) => {
    if (incomingPropClasses.has(currentClass)) {
      finalClassNames.push(currentClass);
      incomingPropClasses.delete(currentClass);
    } else if (!oldPropClasses.has(currentClass)) {
      finalClassNames.push(currentClass);
    }
  });
  incomingPropClasses.forEach((s) => finalClassNames.push(s));
  return finalClassNames.join(" ");
};
var isCoveredByReact = (eventNameSuffix) => {
  if (typeof document === "undefined") {
    return true;
  } else {
    const eventName = "on" + eventNameSuffix;
    let isSupported = eventName in document;
    if (!isSupported) {
      const element = document.createElement("div");
      element.setAttribute(eventName, "return;");
      isSupported = typeof element[eventName] === "function";
    }
    return isSupported;
  }
};
var syncEvent = (node, eventName, newEventHandler) => {
  const eventStore = node.__events || (node.__events = {});
  const oldEventHandler = eventStore[eventName];
  if (oldEventHandler) {
    node.removeEventListener(eventName, oldEventHandler);
  }
  node.addEventListener(eventName, eventStore[eventName] = function handler(e) {
    if (newEventHandler) {
      newEventHandler.call(this, e);
    }
  });
};
var arrayToMap = (arr) => {
  const map = /* @__PURE__ */ new Map();
  arr.forEach((s) => map.set(s, s));
  return map;
};

// ../../node_modules/@ovhcloud/ods-components/text/react/dist/esm/react-component-lib/utils/index.js
var setRef = (ref, value) => {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref != null) {
    ref.current = value;
  }
};
var mergeRefs = (...refs) => {
  return (value) => {
    refs.forEach((ref) => {
      setRef(ref, value);
    });
  };
};
var createForwardRef = (ReactComponent, displayName) => {
  const forwardRef = (props, ref) => {
    return import_react.default.createElement(ReactComponent, Object.assign({}, props, { forwardedRef: ref }));
  };
  forwardRef.displayName = displayName;
  return import_react.default.forwardRef(forwardRef);
};

// ../../node_modules/@ovhcloud/ods-components/text/react/dist/esm/react-component-lib/createComponent.js
var createReactComponent = (tagName, ReactComponentContext, manipulatePropsFunction, defineCustomElement3) => {
  if (defineCustomElement3 !== void 0) {
    defineCustomElement3();
  }
  const displayName = dashToPascalCase(tagName);
  const ReactComponent = class extends import_react2.default.Component {
    constructor(props) {
      super(props);
      this.setComponentElRef = (element) => {
        this.componentEl = element;
      };
    }
    componentDidMount() {
      this.componentDidUpdate(this.props);
    }
    componentDidUpdate(prevProps) {
      attachProps(this.componentEl, this.props, prevProps);
    }
    render() {
      const _a = this.props, { children, forwardedRef, style, className, ref } = _a, cProps = __rest(_a, ["children", "forwardedRef", "style", "className", "ref"]);
      let propsToPass = Object.keys(cProps).reduce((acc, name) => {
        if (name.indexOf("on") === 0 && name[2] === name[2].toUpperCase()) {
          const eventName = name.substring(2).toLowerCase();
          if (typeof document !== "undefined" && isCoveredByReact(eventName)) {
            acc[name] = cProps[name];
          }
        } else {
          acc[name] = cProps[name];
        }
        return acc;
      }, {});
      if (manipulatePropsFunction) {
        propsToPass = manipulatePropsFunction(this.props, propsToPass);
      }
      const newProps = Object.assign(Object.assign({}, propsToPass), { ref: mergeRefs(forwardedRef, this.setComponentElRef), style });
      return (0, import_react2.createElement)(tagName, newProps, children);
    }
    static get displayName() {
      return displayName;
    }
  };
  if (ReactComponentContext) {
    ReactComponent.contextType = ReactComponentContext;
  }
  return createForwardRef(ReactComponent, displayName);
};

// ../../node_modules/@ovhcloud/ods-components/text/react/dist/esm/react-component-lib/createOverlayComponent.js
var import_react3 = __toESM(require_react());
var import_react_dom = __toESM(require_react_dom());

// ../../node_modules/@ovhcloud/ods-component-text/custom-elements/osds-text.js
var ODS_THEME_COLOR_HUE;
(function(ODS_THEME_COLOR_HUE2) {
  ODS_THEME_COLOR_HUE2["_000"] = "000";
  ODS_THEME_COLOR_HUE2["_050"] = "050";
  ODS_THEME_COLOR_HUE2["_075"] = "075";
  ODS_THEME_COLOR_HUE2["_100"] = "100";
  ODS_THEME_COLOR_HUE2["_200"] = "200";
  ODS_THEME_COLOR_HUE2["_300"] = "300";
  ODS_THEME_COLOR_HUE2["_400"] = "400";
  ODS_THEME_COLOR_HUE2["_500"] = "500";
  ODS_THEME_COLOR_HUE2["_600"] = "600";
  ODS_THEME_COLOR_HUE2["_700"] = "700";
  ODS_THEME_COLOR_HUE2["_800"] = "800";
  ODS_THEME_COLOR_HUE2["_900"] = "900";
  ODS_THEME_COLOR_HUE2["_1000"] = "1000";
})(ODS_THEME_COLOR_HUE || (ODS_THEME_COLOR_HUE = {}));
Object.freeze(Object.values(ODS_THEME_COLOR_HUE));
var ODS_THEME_COLOR_INTENT;
(function(ODS_THEME_COLOR_INTENT2) {
  ODS_THEME_COLOR_INTENT2["accent"] = "accent";
  ODS_THEME_COLOR_INTENT2["default"] = "default";
  ODS_THEME_COLOR_INTENT2["error"] = "error";
  ODS_THEME_COLOR_INTENT2["info"] = "info";
  ODS_THEME_COLOR_INTENT2["primary"] = "primary";
  ODS_THEME_COLOR_INTENT2["promotion"] = "promotion";
  ODS_THEME_COLOR_INTENT2["success"] = "success";
  ODS_THEME_COLOR_INTENT2["text"] = "text";
  ODS_THEME_COLOR_INTENT2["warning"] = "warning";
})(ODS_THEME_COLOR_INTENT || (ODS_THEME_COLOR_INTENT = {}));
Object.freeze(Object.values(ODS_THEME_COLOR_INTENT));
var ODS_THEME_SIZE;
(function(ODS_THEME_SIZE2) {
  ODS_THEME_SIZE2["_100"] = "100";
  ODS_THEME_SIZE2["_200"] = "200";
  ODS_THEME_SIZE2["_300"] = "300";
  ODS_THEME_SIZE2["_400"] = "400";
  ODS_THEME_SIZE2["_500"] = "500";
  ODS_THEME_SIZE2["_600"] = "600";
  ODS_THEME_SIZE2["_700"] = "700";
  ODS_THEME_SIZE2["_800"] = "800";
  ODS_THEME_SIZE2["_900"] = "900";
})(ODS_THEME_SIZE || (ODS_THEME_SIZE = {}));
Object.freeze(Object.values(ODS_THEME_SIZE));
var ODS_THEME_TYPOGRAPHY_LEVEL;
(function(ODS_THEME_TYPOGRAPHY_LEVEL2) {
  ODS_THEME_TYPOGRAPHY_LEVEL2["body"] = "body";
  ODS_THEME_TYPOGRAPHY_LEVEL2["button"] = "button";
  ODS_THEME_TYPOGRAPHY_LEVEL2["caption"] = "caption";
  ODS_THEME_TYPOGRAPHY_LEVEL2["heading"] = "heading";
  ODS_THEME_TYPOGRAPHY_LEVEL2["subheading"] = "subheading";
})(ODS_THEME_TYPOGRAPHY_LEVEL || (ODS_THEME_TYPOGRAPHY_LEVEL = {}));
var ODS_THEME_TYPOGRAPHY_LEVELS = Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_LEVEL));
var ODS_THEME_TYPOGRAPHY_SIZE;
(function(ODS_THEME_TYPOGRAPHY_SIZE2) {
  ODS_THEME_TYPOGRAPHY_SIZE2["_100"] = "100";
  ODS_THEME_TYPOGRAPHY_SIZE2["_200"] = "200";
  ODS_THEME_TYPOGRAPHY_SIZE2["_300"] = "300";
  ODS_THEME_TYPOGRAPHY_SIZE2["_400"] = "400";
  ODS_THEME_TYPOGRAPHY_SIZE2["_500"] = "500";
  ODS_THEME_TYPOGRAPHY_SIZE2["_600"] = "600";
  ODS_THEME_TYPOGRAPHY_SIZE2["_700"] = "700";
  ODS_THEME_TYPOGRAPHY_SIZE2["_800"] = "800";
})(ODS_THEME_TYPOGRAPHY_SIZE || (ODS_THEME_TYPOGRAPHY_SIZE = {}));
var ODS_THEME_TYPOGRAPHY_SIZES = Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_SIZE));
function odsGenerateColorVariable(intent, hue, contrasted = false) {
  return `--ods-color-${intent}-${hue}${contrasted ? "-contrasted" : ""}`;
}
var DEFAULT_ATTRIBUTE = Object.freeze({
  breakSpaces: false,
  color: ODS_THEME_COLOR_INTENT.default,
  contrasted: false,
  level: ODS_THEME_TYPOGRAPHY_LEVEL.body,
  size: ODS_THEME_TYPOGRAPHY_SIZE._100,
  hue: ODS_THEME_COLOR_HUE._500
});
var osdsTextCss = ':host([break-spaces]){white-space:break-spaces}:host(:not([color])){color:var(--ods-color-default-500)}:host([color^=default]){color:var(--ods-color-default-500)}:host([color^=primary]){color:var(--ods-color-primary-500)}:host([color^=text]){color:var(--ods-color-text-500)}:host([color^=accent]){color:var(--ods-color-accent-500)}:host([color^=error]){color:var(--ods-color-error-500)}:host([color^=warning]){color:var(--ods-color-warning-500)}:host([color^=success]){color:var(--ods-color-success-500)}:host([color^=info]){color:var(--ods-color-info-500)}:host([color^=promotion]){color:var(--ods-color-promotion-500)}:host([hue]:not([color])){color:var(--osds-text-color-specific-hue, var(--ods-color-default-500))}:host([hue][color^=default]){color:var(--osds-text-color-specific-hue, var(--ods-color-default-500))}:host([hue][color^=primary]){color:var(--osds-text-color-specific-hue, var(--ods-color-primary-500))}:host([hue][color^=text]){color:var(--osds-text-color-specific-hue, var(--ods-color-text-500))}:host([hue][color^=accent]){color:var(--osds-text-color-specific-hue, var(--ods-color-accent-500))}:host([hue][color^=error]){color:var(--osds-text-color-specific-hue, var(--ods-color-error-500))}:host([hue][color^=warning]){color:var(--osds-text-color-specific-hue, var(--ods-color-warning-500))}:host([hue][color^=success]){color:var(--osds-text-color-specific-hue, var(--ods-color-success-500))}:host([hue][color^=info]){color:var(--osds-text-color-specific-hue, var(--ods-color-info-500))}:host([hue][color^=promotion]){color:var(--osds-text-color-specific-hue, var(--ods-color-promotion-500))}:host([contrasted]:not([color])){color:var(--ods-color-default-500-contrasted)}:host([contrasted][color^=default]){color:var(--ods-color-default-500-contrasted)}:host([contrasted][color^=primary]){color:var(--ods-color-primary-500-contrasted)}:host([contrasted][color^=text]){color:var(--ods-color-text-500-contrasted)}:host([contrasted][color^=accent]){color:var(--ods-color-accent-500-contrasted)}:host([contrasted][color^=error]){color:var(--ods-color-error-500-contrasted)}:host([contrasted][color^=warning]){color:var(--ods-color-warning-500-contrasted)}:host([contrasted][color^=success]){color:var(--ods-color-success-500-contrasted)}:host([contrasted][color^=info]){color:var(--ods-color-info-500-contrasted)}:host([contrasted][color^=promotion]){color:var(--ods-color-promotion-500-contrasted)}:host([level=heading][size="100"]){font-size:var(--ods-typography-heading-100-font-size);font-weight:var(--ods-typography-heading-100-font-weight);font-family:var(--ods-typography-heading-100-font-family);font-style:var(--ods-typography-heading-100-font-style);letter-spacing:var(--ods-typography-heading-100-letter-spacing);line-height:var(--ods-typography-heading-100-line-height)}:host([level=heading][size="200"]){font-size:var(--ods-typography-heading-200-font-size);font-weight:var(--ods-typography-heading-200-font-weight);font-family:var(--ods-typography-heading-200-font-family);font-style:var(--ods-typography-heading-200-font-style);letter-spacing:var(--ods-typography-heading-200-letter-spacing);line-height:var(--ods-typography-heading-200-line-height)}:host([level=heading][size="300"]){font-size:var(--ods-typography-heading-300-font-size);font-weight:var(--ods-typography-heading-300-font-weight);font-family:var(--ods-typography-heading-300-font-family);font-style:var(--ods-typography-heading-300-font-style);letter-spacing:var(--ods-typography-heading-300-letter-spacing);line-height:var(--ods-typography-heading-300-line-height)}:host([level=heading][size="400"]){font-size:var(--ods-typography-heading-400-font-size);font-weight:var(--ods-typography-heading-400-font-weight);font-family:var(--ods-typography-heading-400-font-family);font-style:var(--ods-typography-heading-400-font-style);letter-spacing:var(--ods-typography-heading-400-letter-spacing);line-height:var(--ods-typography-heading-400-line-height)}:host([level=heading][size="500"]){font-size:var(--ods-typography-heading-500-font-size);font-weight:var(--ods-typography-heading-500-font-weight);font-family:var(--ods-typography-heading-500-font-family);font-style:var(--ods-typography-heading-500-font-style);letter-spacing:var(--ods-typography-heading-500-letter-spacing);line-height:var(--ods-typography-heading-500-line-height)}:host([level=heading][size="600"]){font-size:var(--ods-typography-heading-600-font-size);font-weight:var(--ods-typography-heading-600-font-weight);font-family:var(--ods-typography-heading-600-font-family);font-style:var(--ods-typography-heading-600-font-style);letter-spacing:var(--ods-typography-heading-600-letter-spacing);line-height:var(--ods-typography-heading-600-line-height)}:host([level=heading][size="700"]){font-size:var(--ods-typography-heading-700-font-size);font-weight:var(--ods-typography-heading-700-font-weight);font-family:var(--ods-typography-heading-700-font-family);font-style:var(--ods-typography-heading-700-font-style);letter-spacing:var(--ods-typography-heading-700-letter-spacing);line-height:var(--ods-typography-heading-700-line-height)}:host([level=heading][size="800"]){font-size:var(--ods-typography-heading-800-font-size);font-weight:var(--ods-typography-heading-800-font-weight);font-family:var(--ods-typography-heading-800-font-family);font-style:var(--ods-typography-heading-800-font-style);letter-spacing:var(--ods-typography-heading-800-letter-spacing);line-height:var(--ods-typography-heading-800-line-height)}:host([level=subheading][size="100"]){font-size:var(--ods-typography-subheading-100-font-size);font-weight:var(--ods-typography-subheading-100-font-weight);font-family:var(--ods-typography-subheading-100-font-family);font-style:var(--ods-typography-subheading-100-font-style);letter-spacing:var(--ods-typography-subheading-100-letter-spacing);line-height:var(--ods-typography-subheading-100-line-height)}:host([level=subheading][size="200"]){font-size:var(--ods-typography-subheading-200-font-size);font-weight:var(--ods-typography-subheading-200-font-weight);font-family:var(--ods-typography-subheading-200-font-family);font-style:var(--ods-typography-subheading-200-font-style);letter-spacing:var(--ods-typography-subheading-200-letter-spacing);line-height:var(--ods-typography-subheading-200-line-height)}:host([level=body][size="100"]){font-size:var(--ods-typography-body-100-font-size);font-weight:var(--ods-typography-body-100-font-weight);font-family:var(--ods-typography-body-100-font-family);font-style:var(--ods-typography-body-100-font-style);letter-spacing:var(--ods-typography-body-100-letter-spacing);line-height:var(--ods-typography-body-100-line-height)}:host([level=body][size="200"]){font-size:var(--ods-typography-body-200-font-size);font-weight:var(--ods-typography-body-200-font-weight);font-family:var(--ods-typography-body-200-font-family);font-style:var(--ods-typography-body-200-font-style);letter-spacing:var(--ods-typography-body-200-letter-spacing);line-height:var(--ods-typography-body-200-line-height)}:host([level=body][size="300"]){font-size:var(--ods-typography-body-300-font-size);font-weight:var(--ods-typography-body-300-font-weight);font-family:var(--ods-typography-body-300-font-family);font-style:var(--ods-typography-body-300-font-style);letter-spacing:var(--ods-typography-body-300-letter-spacing);line-height:var(--ods-typography-body-300-line-height)}:host([level=body][size="400"]){font-size:var(--ods-typography-body-400-font-size);font-weight:var(--ods-typography-body-400-font-weight);font-family:var(--ods-typography-body-400-font-family);font-style:var(--ods-typography-body-400-font-style);letter-spacing:var(--ods-typography-body-400-letter-spacing);line-height:var(--ods-typography-body-400-line-height)}:host([level=body][size="500"]){font-size:var(--ods-typography-body-500-font-size);font-weight:var(--ods-typography-body-500-font-weight);font-family:var(--ods-typography-body-500-font-family);font-style:var(--ods-typography-body-500-font-style);letter-spacing:var(--ods-typography-body-500-letter-spacing);line-height:var(--ods-typography-body-500-line-height)}:host([level=body][size="600"]){font-size:var(--ods-typography-body-600-font-size);font-weight:var(--ods-typography-body-600-font-weight);font-family:var(--ods-typography-body-600-font-family);font-style:var(--ods-typography-body-600-font-style);letter-spacing:var(--ods-typography-body-600-letter-spacing);line-height:var(--ods-typography-body-600-line-height)}:host([level=button][size="100"]){font-size:var(--ods-typography-button-100-font-size);font-weight:var(--ods-typography-button-100-font-weight);font-family:var(--ods-typography-button-100-font-family);font-style:var(--ods-typography-button-100-font-style);letter-spacing:var(--ods-typography-button-100-letter-spacing);line-height:var(--ods-typography-button-100-line-height)}:host([level=caption][size="100"]){font-size:var(--ods-typography-caption-100-font-size);font-weight:var(--ods-typography-caption-100-font-weight);font-family:var(--ods-typography-caption-100-font-family);font-style:var(--ods-typography-caption-100-font-style);letter-spacing:var(--ods-typography-caption-100-letter-spacing);line-height:var(--ods-typography-caption-100-line-height)}';
var OsdsText$1 = proxyCustomElement(class extends H {
  constructor() {
    super();
    this.__registerHost();
    this.__attachShadow();
    this.breakSpaces = DEFAULT_ATTRIBUTE.breakSpaces;
    this.color = DEFAULT_ATTRIBUTE.color;
    this.contrasted = DEFAULT_ATTRIBUTE.contrasted;
    this.size = DEFAULT_ATTRIBUTE.size;
    this.level = DEFAULT_ATTRIBUTE.level;
    this.hue = DEFAULT_ATTRIBUTE.hue;
  }
  render() {
    return h(Host, Object.assign({}, {
      style: {
        "--osds-text-color-specific-hue": this.color && this.hue ? `var(${odsGenerateColorVariable(this.color, this.hue)})` : ""
      }
    }), h("slot", null));
  }
  static get style() {
    return osdsTextCss;
  }
}, [1, "osds-text", {
  "breakSpaces": [516, "break-spaces"],
  "color": [513],
  "contrasted": [516],
  "size": [513],
  "level": [513],
  "hue": [513]
}]);
function defineCustomElement$1() {
  if (typeof customElements === "undefined") {
    return;
  }
  const components = ["osds-text"];
  components.forEach((tagName) => {
    switch (tagName) {
      case "osds-text":
        if (!customElements.get(tagName)) {
          customElements.define(tagName, OsdsText$1);
        }
        break;
    }
  });
}
var defineCustomElement2 = defineCustomElement$1;

// ../../node_modules/@ovhcloud/ods-components/text/react/dist/esm/index.js
var OsdsText = createReactComponent("osds-text", void 0, void 0, defineCustomElement2);
export {
  OsdsText
};
/*! Bundled license information:

@ovhcloud/ods-components/text/react/dist/esm/react-component-lib/utils/attachProps.js:
  (**
   * Checks if an event is supported in the current execution environment.
   * @license Modernizr 3.0.0pre (Custom Build) | MIT
   *)
*/
//# sourceMappingURL=@ovhcloud_ods-components_text_react.js.map
