import {
  a
} from "/node_modules/.cache/sb-vite/deps/chunk-V4OO36GZ.js?v=25ee29f1";
import "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";
export {
  a as default
};
//# sourceMappingURL=@storybook_addon-styling_preview.js.map
