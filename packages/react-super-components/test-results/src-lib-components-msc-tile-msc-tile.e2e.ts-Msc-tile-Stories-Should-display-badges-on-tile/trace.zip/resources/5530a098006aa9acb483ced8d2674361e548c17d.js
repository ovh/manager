import "/node_modules/.cache/sb-vite/deps/chunk-AUZ3RYOM.js?v=25ee29f1";

// ../../node_modules/@ovhcloud/ods-components/text/dist/esm/index-17ffbb6a.js
var queuePending = false;
var isComplexType = (o) => {
  o = typeof o;
  return o === "object" || o === "function";
};
var h = (nodeName, vnodeData, ...children) => {
  let child = null;
  let key = null;
  let simple = false;
  let lastSimple = false;
  const vNodeChildren = [];
  const walk = (c) => {
    for (let i = 0; i < c.length; i++) {
      child = c[i];
      if (Array.isArray(child)) {
        walk(child);
      } else if (child != null && typeof child !== "boolean") {
        if (simple = typeof nodeName !== "function" && !isComplexType(child)) {
          child = String(child);
        }
        if (simple && lastSimple) {
          vNodeChildren[vNodeChildren.length - 1].$text$ += child;
        } else {
          vNodeChildren.push(simple ? newVNode(null, child) : child);
        }
        lastSimple = simple;
      }
    }
  };
  walk(children);
  if (vnodeData) {
    if (vnodeData.key) {
      key = vnodeData.key;
    }
    {
      const classData = vnodeData.className || vnodeData.class;
      if (classData) {
        vnodeData.class = typeof classData !== "object" ? classData : Object.keys(classData).filter((k) => classData[k]).join(" ");
      }
    }
  }
  const vnode = newVNode(nodeName, null);
  vnode.$attrs$ = vnodeData;
  if (vNodeChildren.length > 0) {
    vnode.$children$ = vNodeChildren;
  }
  {
    vnode.$key$ = key;
  }
  return vnode;
};
var newVNode = (tag, text) => {
  const vnode = {
    $flags$: 0,
    $tag$: tag,
    $text$: text,
    $elm$: null,
    $children$: null
  };
  {
    vnode.$attrs$ = null;
  }
  {
    vnode.$key$ = null;
  }
  return vnode;
};
var Host = {};
var hostRefs = /* @__PURE__ */ new WeakMap();
var registerInstance = (lazyInstance, hostRef) => hostRefs.set(hostRef.$lazyInstance$ = lazyInstance, hostRef);
var consoleError = (e, el) => (0, console.error)(e, el);
var win = typeof window !== "undefined" ? window : {};
var doc = win.document || { head: {} };
var plt = {
  $flags$: 0,
  $resourcesUrl$: "",
  jmp: (h2) => h2(),
  raf: (h2) => requestAnimationFrame(h2),
  ael: (el, eventName, listener, opts) => el.addEventListener(eventName, listener, opts),
  rel: (el, eventName, listener, opts) => el.removeEventListener(eventName, listener, opts),
  ce: (eventName, opts) => new CustomEvent(eventName, opts)
};
var promiseResolve = (v) => Promise.resolve(v);
var supportsConstructableStylesheets = (() => {
  try {
    new CSSStyleSheet();
    return typeof new CSSStyleSheet().replaceSync === "function";
  } catch (e) {
  }
  return false;
})();
var queueDomReads = [];
var queueDomWrites = [];
var queueTask = (queue, write) => (cb) => {
  queue.push(cb);
  if (!queuePending) {
    queuePending = true;
    if (write && plt.$flags$ & 4) {
      nextTick(flush);
    } else {
      plt.raf(flush);
    }
  }
};
var consume = (queue) => {
  for (let i = 0; i < queue.length; i++) {
    try {
      queue[i](performance.now());
    } catch (e) {
      consoleError(e);
    }
  }
  queue.length = 0;
};
var flush = () => {
  consume(queueDomReads);
  {
    consume(queueDomWrites);
    if (queuePending = queueDomReads.length > 0) {
      plt.raf(flush);
    }
  }
};
var nextTick = (cb) => promiseResolve().then(cb);
var writeTask = queueTask(queueDomWrites, true);

// ../../node_modules/@ovhcloud/ods-components/text/dist/esm/osds-text-0253ce4b.js
var ODS_THEME_COLOR_HUE;
(function(ODS_THEME_COLOR_HUE2) {
  ODS_THEME_COLOR_HUE2["_000"] = "000";
  ODS_THEME_COLOR_HUE2["_050"] = "050";
  ODS_THEME_COLOR_HUE2["_075"] = "075";
  ODS_THEME_COLOR_HUE2["_100"] = "100";
  ODS_THEME_COLOR_HUE2["_200"] = "200";
  ODS_THEME_COLOR_HUE2["_300"] = "300";
  ODS_THEME_COLOR_HUE2["_400"] = "400";
  ODS_THEME_COLOR_HUE2["_500"] = "500";
  ODS_THEME_COLOR_HUE2["_600"] = "600";
  ODS_THEME_COLOR_HUE2["_700"] = "700";
  ODS_THEME_COLOR_HUE2["_800"] = "800";
  ODS_THEME_COLOR_HUE2["_900"] = "900";
  ODS_THEME_COLOR_HUE2["_1000"] = "1000";
})(ODS_THEME_COLOR_HUE || (ODS_THEME_COLOR_HUE = {}));
Object.freeze(Object.values(ODS_THEME_COLOR_HUE));
var ODS_THEME_COLOR_INTENT;
(function(ODS_THEME_COLOR_INTENT2) {
  ODS_THEME_COLOR_INTENT2["accent"] = "accent";
  ODS_THEME_COLOR_INTENT2["default"] = "default";
  ODS_THEME_COLOR_INTENT2["error"] = "error";
  ODS_THEME_COLOR_INTENT2["info"] = "info";
  ODS_THEME_COLOR_INTENT2["primary"] = "primary";
  ODS_THEME_COLOR_INTENT2["promotion"] = "promotion";
  ODS_THEME_COLOR_INTENT2["success"] = "success";
  ODS_THEME_COLOR_INTENT2["text"] = "text";
  ODS_THEME_COLOR_INTENT2["warning"] = "warning";
})(ODS_THEME_COLOR_INTENT || (ODS_THEME_COLOR_INTENT = {}));
Object.freeze(Object.values(ODS_THEME_COLOR_INTENT));
var ODS_THEME_SIZE;
(function(ODS_THEME_SIZE2) {
  ODS_THEME_SIZE2["_100"] = "100";
  ODS_THEME_SIZE2["_200"] = "200";
  ODS_THEME_SIZE2["_300"] = "300";
  ODS_THEME_SIZE2["_400"] = "400";
  ODS_THEME_SIZE2["_500"] = "500";
  ODS_THEME_SIZE2["_600"] = "600";
  ODS_THEME_SIZE2["_700"] = "700";
  ODS_THEME_SIZE2["_800"] = "800";
  ODS_THEME_SIZE2["_900"] = "900";
})(ODS_THEME_SIZE || (ODS_THEME_SIZE = {}));
Object.freeze(Object.values(ODS_THEME_SIZE));
var ODS_THEME_TYPOGRAPHY_LEVEL;
(function(ODS_THEME_TYPOGRAPHY_LEVEL2) {
  ODS_THEME_TYPOGRAPHY_LEVEL2["body"] = "body";
  ODS_THEME_TYPOGRAPHY_LEVEL2["button"] = "button";
  ODS_THEME_TYPOGRAPHY_LEVEL2["caption"] = "caption";
  ODS_THEME_TYPOGRAPHY_LEVEL2["heading"] = "heading";
  ODS_THEME_TYPOGRAPHY_LEVEL2["subheading"] = "subheading";
})(ODS_THEME_TYPOGRAPHY_LEVEL || (ODS_THEME_TYPOGRAPHY_LEVEL = {}));
var ODS_THEME_TYPOGRAPHY_LEVELS = Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_LEVEL));
var ODS_THEME_TYPOGRAPHY_SIZE;
(function(ODS_THEME_TYPOGRAPHY_SIZE2) {
  ODS_THEME_TYPOGRAPHY_SIZE2["_100"] = "100";
  ODS_THEME_TYPOGRAPHY_SIZE2["_200"] = "200";
  ODS_THEME_TYPOGRAPHY_SIZE2["_300"] = "300";
  ODS_THEME_TYPOGRAPHY_SIZE2["_400"] = "400";
  ODS_THEME_TYPOGRAPHY_SIZE2["_500"] = "500";
  ODS_THEME_TYPOGRAPHY_SIZE2["_600"] = "600";
  ODS_THEME_TYPOGRAPHY_SIZE2["_700"] = "700";
  ODS_THEME_TYPOGRAPHY_SIZE2["_800"] = "800";
})(ODS_THEME_TYPOGRAPHY_SIZE || (ODS_THEME_TYPOGRAPHY_SIZE = {}));
var ODS_THEME_TYPOGRAPHY_SIZES = Object.freeze(Object.values(ODS_THEME_TYPOGRAPHY_SIZE));
function odsGenerateColorVariable(intent, hue, contrasted = false) {
  return `--ods-color-${intent}-${hue}${contrasted ? "-contrasted" : ""}`;
}
var DEFAULT_ATTRIBUTE = Object.freeze({
  breakSpaces: false,
  color: ODS_THEME_COLOR_INTENT.default,
  contrasted: false,
  level: ODS_THEME_TYPOGRAPHY_LEVEL.body,
  size: ODS_THEME_TYPOGRAPHY_SIZE._100,
  hue: ODS_THEME_COLOR_HUE._500
});
var osdsTextCss = ':host([break-spaces]){white-space:break-spaces}:host(:not([color])){color:var(--ods-color-default-500)}:host([color^=default]){color:var(--ods-color-default-500)}:host([color^=primary]){color:var(--ods-color-primary-500)}:host([color^=text]){color:var(--ods-color-text-500)}:host([color^=accent]){color:var(--ods-color-accent-500)}:host([color^=error]){color:var(--ods-color-error-500)}:host([color^=warning]){color:var(--ods-color-warning-500)}:host([color^=success]){color:var(--ods-color-success-500)}:host([color^=info]){color:var(--ods-color-info-500)}:host([color^=promotion]){color:var(--ods-color-promotion-500)}:host([hue]:not([color])){color:var(--osds-text-color-specific-hue, var(--ods-color-default-500))}:host([hue][color^=default]){color:var(--osds-text-color-specific-hue, var(--ods-color-default-500))}:host([hue][color^=primary]){color:var(--osds-text-color-specific-hue, var(--ods-color-primary-500))}:host([hue][color^=text]){color:var(--osds-text-color-specific-hue, var(--ods-color-text-500))}:host([hue][color^=accent]){color:var(--osds-text-color-specific-hue, var(--ods-color-accent-500))}:host([hue][color^=error]){color:var(--osds-text-color-specific-hue, var(--ods-color-error-500))}:host([hue][color^=warning]){color:var(--osds-text-color-specific-hue, var(--ods-color-warning-500))}:host([hue][color^=success]){color:var(--osds-text-color-specific-hue, var(--ods-color-success-500))}:host([hue][color^=info]){color:var(--osds-text-color-specific-hue, var(--ods-color-info-500))}:host([hue][color^=promotion]){color:var(--osds-text-color-specific-hue, var(--ods-color-promotion-500))}:host([contrasted]:not([color])){color:var(--ods-color-default-500-contrasted)}:host([contrasted][color^=default]){color:var(--ods-color-default-500-contrasted)}:host([contrasted][color^=primary]){color:var(--ods-color-primary-500-contrasted)}:host([contrasted][color^=text]){color:var(--ods-color-text-500-contrasted)}:host([contrasted][color^=accent]){color:var(--ods-color-accent-500-contrasted)}:host([contrasted][color^=error]){color:var(--ods-color-error-500-contrasted)}:host([contrasted][color^=warning]){color:var(--ods-color-warning-500-contrasted)}:host([contrasted][color^=success]){color:var(--ods-color-success-500-contrasted)}:host([contrasted][color^=info]){color:var(--ods-color-info-500-contrasted)}:host([contrasted][color^=promotion]){color:var(--ods-color-promotion-500-contrasted)}:host([level=heading][size="100"]){font-size:var(--ods-typography-heading-100-font-size);font-weight:var(--ods-typography-heading-100-font-weight);font-family:var(--ods-typography-heading-100-font-family);font-style:var(--ods-typography-heading-100-font-style);letter-spacing:var(--ods-typography-heading-100-letter-spacing);line-height:var(--ods-typography-heading-100-line-height)}:host([level=heading][size="200"]){font-size:var(--ods-typography-heading-200-font-size);font-weight:var(--ods-typography-heading-200-font-weight);font-family:var(--ods-typography-heading-200-font-family);font-style:var(--ods-typography-heading-200-font-style);letter-spacing:var(--ods-typography-heading-200-letter-spacing);line-height:var(--ods-typography-heading-200-line-height)}:host([level=heading][size="300"]){font-size:var(--ods-typography-heading-300-font-size);font-weight:var(--ods-typography-heading-300-font-weight);font-family:var(--ods-typography-heading-300-font-family);font-style:var(--ods-typography-heading-300-font-style);letter-spacing:var(--ods-typography-heading-300-letter-spacing);line-height:var(--ods-typography-heading-300-line-height)}:host([level=heading][size="400"]){font-size:var(--ods-typography-heading-400-font-size);font-weight:var(--ods-typography-heading-400-font-weight);font-family:var(--ods-typography-heading-400-font-family);font-style:var(--ods-typography-heading-400-font-style);letter-spacing:var(--ods-typography-heading-400-letter-spacing);line-height:var(--ods-typography-heading-400-line-height)}:host([level=heading][size="500"]){font-size:var(--ods-typography-heading-500-font-size);font-weight:var(--ods-typography-heading-500-font-weight);font-family:var(--ods-typography-heading-500-font-family);font-style:var(--ods-typography-heading-500-font-style);letter-spacing:var(--ods-typography-heading-500-letter-spacing);line-height:var(--ods-typography-heading-500-line-height)}:host([level=heading][size="600"]){font-size:var(--ods-typography-heading-600-font-size);font-weight:var(--ods-typography-heading-600-font-weight);font-family:var(--ods-typography-heading-600-font-family);font-style:var(--ods-typography-heading-600-font-style);letter-spacing:var(--ods-typography-heading-600-letter-spacing);line-height:var(--ods-typography-heading-600-line-height)}:host([level=heading][size="700"]){font-size:var(--ods-typography-heading-700-font-size);font-weight:var(--ods-typography-heading-700-font-weight);font-family:var(--ods-typography-heading-700-font-family);font-style:var(--ods-typography-heading-700-font-style);letter-spacing:var(--ods-typography-heading-700-letter-spacing);line-height:var(--ods-typography-heading-700-line-height)}:host([level=heading][size="800"]){font-size:var(--ods-typography-heading-800-font-size);font-weight:var(--ods-typography-heading-800-font-weight);font-family:var(--ods-typography-heading-800-font-family);font-style:var(--ods-typography-heading-800-font-style);letter-spacing:var(--ods-typography-heading-800-letter-spacing);line-height:var(--ods-typography-heading-800-line-height)}:host([level=subheading][size="100"]){font-size:var(--ods-typography-subheading-100-font-size);font-weight:var(--ods-typography-subheading-100-font-weight);font-family:var(--ods-typography-subheading-100-font-family);font-style:var(--ods-typography-subheading-100-font-style);letter-spacing:var(--ods-typography-subheading-100-letter-spacing);line-height:var(--ods-typography-subheading-100-line-height)}:host([level=subheading][size="200"]){font-size:var(--ods-typography-subheading-200-font-size);font-weight:var(--ods-typography-subheading-200-font-weight);font-family:var(--ods-typography-subheading-200-font-family);font-style:var(--ods-typography-subheading-200-font-style);letter-spacing:var(--ods-typography-subheading-200-letter-spacing);line-height:var(--ods-typography-subheading-200-line-height)}:host([level=body][size="100"]){font-size:var(--ods-typography-body-100-font-size);font-weight:var(--ods-typography-body-100-font-weight);font-family:var(--ods-typography-body-100-font-family);font-style:var(--ods-typography-body-100-font-style);letter-spacing:var(--ods-typography-body-100-letter-spacing);line-height:var(--ods-typography-body-100-line-height)}:host([level=body][size="200"]){font-size:var(--ods-typography-body-200-font-size);font-weight:var(--ods-typography-body-200-font-weight);font-family:var(--ods-typography-body-200-font-family);font-style:var(--ods-typography-body-200-font-style);letter-spacing:var(--ods-typography-body-200-letter-spacing);line-height:var(--ods-typography-body-200-line-height)}:host([level=body][size="300"]){font-size:var(--ods-typography-body-300-font-size);font-weight:var(--ods-typography-body-300-font-weight);font-family:var(--ods-typography-body-300-font-family);font-style:var(--ods-typography-body-300-font-style);letter-spacing:var(--ods-typography-body-300-letter-spacing);line-height:var(--ods-typography-body-300-line-height)}:host([level=body][size="400"]){font-size:var(--ods-typography-body-400-font-size);font-weight:var(--ods-typography-body-400-font-weight);font-family:var(--ods-typography-body-400-font-family);font-style:var(--ods-typography-body-400-font-style);letter-spacing:var(--ods-typography-body-400-letter-spacing);line-height:var(--ods-typography-body-400-line-height)}:host([level=body][size="500"]){font-size:var(--ods-typography-body-500-font-size);font-weight:var(--ods-typography-body-500-font-weight);font-family:var(--ods-typography-body-500-font-family);font-style:var(--ods-typography-body-500-font-style);letter-spacing:var(--ods-typography-body-500-letter-spacing);line-height:var(--ods-typography-body-500-line-height)}:host([level=body][size="600"]){font-size:var(--ods-typography-body-600-font-size);font-weight:var(--ods-typography-body-600-font-weight);font-family:var(--ods-typography-body-600-font-family);font-style:var(--ods-typography-body-600-font-style);letter-spacing:var(--ods-typography-body-600-letter-spacing);line-height:var(--ods-typography-body-600-line-height)}:host([level=button][size="100"]){font-size:var(--ods-typography-button-100-font-size);font-weight:var(--ods-typography-button-100-font-weight);font-family:var(--ods-typography-button-100-font-family);font-style:var(--ods-typography-button-100-font-style);letter-spacing:var(--ods-typography-button-100-letter-spacing);line-height:var(--ods-typography-button-100-line-height)}:host([level=caption][size="100"]){font-size:var(--ods-typography-caption-100-font-size);font-weight:var(--ods-typography-caption-100-font-weight);font-family:var(--ods-typography-caption-100-font-family);font-style:var(--ods-typography-caption-100-font-style);letter-spacing:var(--ods-typography-caption-100-letter-spacing);line-height:var(--ods-typography-caption-100-line-height)}';
var OsdsText = class {
  constructor(hostRef) {
    registerInstance(this, hostRef);
    this.breakSpaces = DEFAULT_ATTRIBUTE.breakSpaces;
    this.color = DEFAULT_ATTRIBUTE.color;
    this.contrasted = DEFAULT_ATTRIBUTE.contrasted;
    this.size = DEFAULT_ATTRIBUTE.size;
    this.level = DEFAULT_ATTRIBUTE.level;
    this.hue = DEFAULT_ATTRIBUTE.hue;
  }
  render() {
    return h(Host, Object.assign({}, {
      style: {
        "--osds-text-color-specific-hue": this.color && this.hue ? `var(${odsGenerateColorVariable(this.color, this.hue)})` : ""
      }
    }), h("slot", null));
  }
};
OsdsText.style = osdsTextCss;
export {
  ODS_THEME_TYPOGRAPHY_LEVEL as ODS_TEXT_LEVEL,
  ODS_THEME_TYPOGRAPHY_LEVELS as ODS_TEXT_LEVELS,
  ODS_THEME_TYPOGRAPHY_SIZE as ODS_TEXT_SIZE,
  ODS_THEME_TYPOGRAPHY_SIZES as ODS_TEXT_SIZES,
  OsdsText
};
//# sourceMappingURL=@ovhcloud_ods-components_text.js.map
